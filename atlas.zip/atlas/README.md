# ATLAS – Passive OSINT Intelligence Agent

**ATLAS** is a standalone, modular Python agent for ethical, passive open-source intelligence (OSINT) research.

It accepts an IP address, domain, URL, organisation name, or publicly known individual and produces a structured intelligence report using from publicly accessible sources only.

```
    ___   ________  ___    ___   _____
   /   | /_  __/ / / / |  / / | / ___/
  / /| |  / / / / / /| | / /| | \__ \
 / ___ | / / / /_/ / | |/ / | |___/ /
/_/  |_|/_/  \____/  |___/  |_/____/
```

## Features

- **Automatic input classification** (IP / domain / URL / organisation / person)
- **IP investigation**: version, RDAP network registration, approximate geolocation, ISP/ASN, public reputation indicators
- **Domain investigation**: RDAP registration, DNS records, Certificate Transparency subdomains, basic web presence
- **Organisation investigation**: public search guidance + light official-site heuristics
- **Person investigation**: strictly limited to public professional information; no private data collection
- **Source attribution** and **confidence indicators** on every major finding
- **Legal & ethical assessment** section (UK GDPR, DPA 2018, Computer Misuse Act 1990 awareness)
- **Export** to JSON and plain-text reports
- **Modern terminal UI** (with optional `rich` support)
- **No mandatory paid APIs** – works with public endpoints and the standard library (plus a few optional packages)

## Security & Ethical Boundaries

ATLAS is a **passive** research tool. It will **not**:

- Attempt unauthorised access or exploit vulnerabilities
- Guess passwords or bypass authentication
- Access private databases or non-public systems
- Conduct denial-of-service activity
- Track live location of individuals
- Collect private personal information (home addresses, personal phones, private accounts, credentials)
- Circumvent website security controls

It applies reasonable rate limiting and identifies itself with a clear User-Agent.

## Installation

```bash
# Clone or copy the project
cd atlas

# (Recommended) create a virtual environment
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# Install optional but recommended dependencies
pip install -r requirements.txt
```

Minimum: Python 3.9+.  
The tool degrades gracefully if optional packages (`dnspython`, `requests`, `rich`, `beautifulsoup4`) are missing.

## Usage

### Interactive mode

```bash
python main.py
```

Then:

```
atlas> investigate 8.8.8.8
atlas> investigate example.com
atlas> investigate Microsoft
atlas> investigate "Tim Cook"
atlas> report
atlas> export
atlas> help
atlas> exit
```

### One-shot mode

```bash
python main.py investigate 8.8.8.8
python main.py -t example.com
python main.py Microsoft --no-report
```

Reports are written to the `reports/` directory (JSON + TXT) by default.

## Project Structure

```
atlas/
├── main.py                 # Entry point & CLI
├── requirements.txt
├── README.md
├── atlas/
│   ├── __init__.py
│   ├── agent.py            # Orchestration engine
│   ├── classifier.py       # Input type detection
│   ├── report.py           # Report rendering & export
│   ├── ui.py               # Terminal interface
│   ├── modules/
│   │   ├── ip_module.py
│   │   ├── domain_module.py
│   │   ├── org_module.py
│   │   └── person_module.py
│   ├── sources/
│   │   ├── rdap.py
│   │   ├── dns_lookup.py
│   │   ├── geoip.py
│   │   ├── cert_transparency.py
│   │   ├── reputation.py
│   │   └── web_presence.py
│   └── utils/
│       └── helpers.py
├── examples/
└── reports/                # Generated investigation outputs
```

## Adding Further OSINT Sources

1. Create a new module under `atlas/sources/` (e.g. `my_source.py`).
2. Implement a pure function that returns a structured `dict` with at least:
   - `queried_at`
   - `success` (bool)
   - `source` (attribution string)
   - `errors` (list)
   - relevant findings
3. Import and call it from the appropriate investigation module (`ip_module.py`, `domain_module.py`, etc.).
4. Update confidence scoring and the sources list in the report.
5. Respect rate limits, robots policies, and terms of service. Prefer official public APIs or well-known public datasets.

Keep new sources **passive**. Do not add functionality that attempts unauthorised access, credential testing, or private data collection.

## Legal & Compliance Notes

- This tool is intended for **legitimate research, defensive security, education, and journalistic purposes** using publicly available information.
- Legal conclusions depend on jurisdiction, purpose, data type, and collection method.
- The built-in legal assessment section is **not formal legal advice**.
- Key UK instruments considered in design:
  - UK GDPR / Data Protection Act 2018
  - Computer Misuse Act 1990
  - Privacy and Electronic Communications Regulations
- Always ensure you have a lawful basis when processing personal data, even if that data is public.

## Limitations

- Free public endpoints can be rate-limited, incomplete, or temporarily unavailable. ATLAS reports failures honestly.
- Organisation and person modules intentionally stay light-touch and provide curated search starting points rather than automated dossiers.
- Geolocation is approximate (city/region at best) and must never be treated as precise personal location.
- No tool can guarantee completeness of open-source information.

## Licence

Provided for legitimate security research, education, and defensive purposes. Use responsibly and in accordance with applicable law.
