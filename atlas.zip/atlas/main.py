#!/usr/bin/env python3
"""
ATLAS – Passive OSINT Intelligence Agent
Entry point and interactive terminal interface.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

# Ensure package is importable when run as script
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from atlas.agent import AtlasAgent
from atlas import ui


def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    # Quieten noisy libraries
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)


def run_interactive(agent: AtlasAgent) -> None:
    ui.print_banner()
    ui.print_help()

    while True:
        try:
            if ui.RICH_AVAILABLE:
                user_input = ui.console.input("[bold cyan]atlas>[/bold cyan] ").strip()
            else:
                user_input = input("atlas> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting ATLAS.")
            break

        if not user_input:
            continue

        lower = user_input.lower()
        if lower in ("exit", "quit", "q"):
            print("Goodbye.")
            break
        if lower in ("help", "?"):
            ui.print_help()
            continue
        if lower == "report":
            text = agent.render_last_report()
            ui.print_report_text(text)
            continue
        if lower == "export":
            if agent.last_report:
                from atlas.report import export_json, export_txt
                j = export_json(agent.last_report, agent.output_dir)
                t = export_txt(agent.last_report, agent.output_dir)
                ui.print_info(f"Exported:\n  {j}\n  {t}")
            else:
                ui.print_error("No report to export.")
            continue

        # investigate command
        if lower.startswith("investigate "):
            target = user_input[12:].strip()
            if not target:
                ui.print_error("Please provide a target after 'investigate'.")
                continue
        else:
            # Allow bare target as shortcut
            target = user_input

        try:
            report = agent.investigate(target, progress_callback=ui.progress_printer)
            if "classification" in report:
                ui.show_classification(report["classification"])
            ui.show_summary(report)
        except Exception as e:
            ui.print_error(str(e))
            logging.exception("Investigation failed")


def run_single(agent: AtlasAgent, target: str, show_report: bool = True) -> int:
    ui.print_banner()
    try:
        report = agent.investigate(target, progress_callback=ui.progress_printer)
        if "classification" in report:
            ui.show_classification(report["classification"])
        ui.show_summary(report)
        if show_report:
            text = agent.render_last_report()
            ui.print_report_text(text)
        return 0
    except Exception as e:
        ui.print_error(str(e))
        logging.exception("Investigation failed")
        return 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description="ATLAS – Passive OSINT Intelligence Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py
  python main.py investigate 8.8.8.8
  python main.py investigate example.com
  python main.py investigate Microsoft
  python main.py -t 1.1.1.1 --no-report
        """,
    )
    parser.add_argument(
        "command",
        nargs="?",
        help="Optional: 'investigate' followed by target, or just the target",
    )
    parser.add_argument(
        "target",
        nargs="?",
        help="Target to investigate (IP, domain, organisation, person)",
    )
    parser.add_argument(
        "-t", "--target",
        dest="target_opt",
        help="Target to investigate (alternative form)",
    )
    parser.add_argument(
        "-o", "--output-dir",
        default="reports",
        help="Directory for exported reports (default: reports)",
    )
    parser.add_argument(
        "--no-report",
        action="store_true",
        help="Do not print full text report to console (still exports files)",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable debug logging",
    )

    args = parser.parse_args()
    setup_logging(args.verbose)

    agent = AtlasAgent(output_dir=args.output_dir)

    # Determine target
    target = args.target_opt or args.target
    if args.command and args.command.lower() != "investigate":
        # Treat first positional as target if not the word "investigate"
        if not target:
            target = args.command

    if target:
        return run_single(agent, target, show_report=not args.no_report)
    else:
        run_interactive(agent)
        return 0


if __name__ == "__main__":
    sys.exit(main())