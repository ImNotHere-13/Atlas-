# Example Investigations

The `reports/` directory (created at runtime) contains real outputs from the tool.

Sample commands that were successfully executed during development:

```bash
# IP address (Google Public DNS)
python main.py -t 8.8.8.8

# Domain
python main.py -t example.com

# Organisation
python main.py -t Microsoft

# Person (public figure – produces search guidance only)
python main.py -t "Tim Cook"
```

Each run produces:

- A JSON file with the full structured report (including raw source data where available)
- A human-readable TXT report with confidence indicators, source list, limitations, and legal notes

Open the TXT files for a readable view; use the JSON files for further automated processing.
