# ATLAS – Security Restrictions & Legal Limitations

## Operational Security Restrictions

ATLAS is designed as a **passive OSINT research tool**. The following activities are intentionally out of scope and are not implemented:

| Prohibited activity | Reason |
|---------------------|--------|
| Unauthorised access to systems | Computer Misuse Act 1990 (UK) and equivalent laws |
| Exploitation of vulnerabilities | Same |
| Password guessing / credential stuffing | Same + ethical boundary |
| Bypassing authentication or access controls | Same |
| Access to private / non-public databases | Legal and ethical |
| Denial-of-service or resource exhaustion | Illegal and unethical |
| Live location tracking of individuals | Privacy / data protection |
| Collection of private personal data (home addresses, personal phones, private accounts, credentials) | UK GDPR / DPA 2018 and ethical design |
| Circumventing website security or robots restrictions | Terms of service + good practice |

The agent identifies itself with a clear User-Agent and applies simple per-host rate limiting.

## Legal Classification Guidance (Not Formal Advice)

ATLAS includes a structured legal assessment section in every report. Classifications used:

- **Generally permitted public research** – e.g. public RDAP, DNS, Certificate Transparency, passive observation of publicly reachable web pages, public DNS-based blocklist queries.
- **Generally permitted public research (with caveats)** – e.g. approximate geolocation of a public IP (an IP can be personal data in context).
- **Potentially restricted or regulated** – bulk/automated scraping of registries or social platforms, large-scale personal data collection.
- **Requires additional authorisation / careful assessment** – research focused on living individuals (personal data).
- **Not permitted by the system** – unauthorised access, private data collection, credential testing.

**Important**: These classifications are for transparency and awareness only. They are **not formal legal advice**. The actual legal position depends on:

- Jurisdiction
- Purpose of the research
- Whether personal data is involved
- Lawful basis for processing (UK GDPR)
- Specific collection methods and volume
- Applicable sectoral rules

Key UK instruments considered in the design of ATLAS:

- UK General Data Protection Regulation (UK GDPR)
- Data Protection Act 2018
- Computer Misuse Act 1990
- Privacy and Electronic Communications Regulations (PECR)

If you process personal data (including in some cases IP addresses or information about identifiable individuals), you must ensure you have a lawful basis and comply with data protection principles.

## Responsible Use

ATLAS is intended for:

- Defensive security research
- Educational and training purposes
- Legitimate open-source intelligence work
- Journalistic and academic research using public sources

Users are responsible for ensuring their use complies with applicable law and the terms of any services they query.

## Reporting Issues

If you discover a way in which ATLAS could be misused to perform non-passive or non-public research, please treat it as a design issue and avoid using that path. The codebase deliberately avoids implementing such capabilities.