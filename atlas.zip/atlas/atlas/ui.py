"""
Terminal user interface for ATLAS.
Uses rich if available, otherwise plain text.
"""

from __future__ import annotations

import sys
from typing import Optional

# Try rich for a nicer experience
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.markdown import Markdown
    from rich import box
    RICH_AVAILABLE = True
    console = Console()
except ImportError:
    RICH_AVAILABLE = False
    console = None


BANNER = r"""
    ___   ________  ___    ___   _____
   /   | /_  __/ / / / |  / / | / ___/
  / /| |  / / / / / /| | / /| | \__ \
 / ___ | / / / /_/ / | |/ / | |___/ /
/_/  |_|/_/  \____/  |___/  |_/____/

  ATLAS – Passive OSINT Intelligence Agent
  Ethical • Transparent • Source-aware
"""


def print_banner() -> None:
    if RICH_AVAILABLE:
        console.print(BANNER, style="bold cyan")
        console.print(
            "Passive research only. No unauthorised access. No private data collection.\n",
            style="dim",
        )
    else:
        print(BANNER)
        print("Passive research only. No unauthorised access. No private data collection.\n")


def print_help() -> None:
    help_text = """
Commands
--------
  investigate <target>   Run a full investigation
                         Examples:
                           investigate 8.8.8.8
                           investigate example.com
                           investigate Microsoft
                           investigate "Tim Cook"

  report                 Show the last report again
  export                 Re-export last report (JSON + TXT)
  help                   Show this help
  exit / quit            Leave ATLAS

Notes
-----
• Only public, passive sources are used.
• IP geolocation is approximate – never treats an IP as a specific person.
• Person investigations are limited to public professional information.
• All findings include source attribution and confidence indicators.
"""
    if RICH_AVAILABLE:
        console.print(Panel(help_text, title="ATLAS Help", border_style="cyan"))
    else:
        print(help_text)


def progress_printer(message: str) -> None:
    if RICH_AVAILABLE:
        console.print(f"  [cyan]→[/cyan] {message}")
    else:
        print(f"  → {message}")


def show_classification(classification: dict) -> None:
    if RICH_AVAILABLE:
        table = Table(title="Input Classification", box=box.ROUNDED, show_header=False)
        table.add_column("Field", style="bold")
        table.add_column("Value")
        table.add_row("Original", str(classification.get("original_input")))
        table.add_row("Normalised", str(classification.get("normalised")))
        table.add_row("Type", str(classification.get("type")))
        table.add_row("Confidence", f"{classification.get('confidence', 0):.2f}")
        table.add_row("Notes", str(classification.get("notes", "")))
        console.print(table)
    else:
        print("\n--- Classification ---")
        for k, v in classification.items():
            print(f"  {k}: {v}")


def show_summary(report: dict) -> None:
    """Show a concise dashboard after investigation."""
    if RICH_AVAILABLE:
        console.print()
        console.rule("[bold cyan]Investigation Complete")
        conf = report.get("confidence_summary") or {}
        if conf:
            table = Table(title="Confidence Dashboard", box=box.SIMPLE)
            table.add_column("Aspect")
            table.add_column("Level")
            table.add_column("Note")
            for k, v in conf.items():
                if isinstance(v, dict):
                    table.add_row(k, str(v.get("level")), str(v.get("note", ""))[:60])
            console.print(table)

        sources = report.get("sources_used") or []
        if sources:
            console.print("\n[bold]Sources consulted:[/bold]")
            for s in sources:
                console.print(f"  • {s}")

        export = report.get("export") or {}
        if export:
            console.print(f"\n[green]JSON report:[/green] {export.get('json')}")
            console.print(f"[green]TXT report:[/green]  {export.get('txt')}")

        console.print(
            "\n[dim]Full details are in the exported report files. "
            "Type 'report' to view the text version here.[/dim]\n"
        )
    else:
        print("\n=== Investigation Complete ===")
        conf = report.get("confidence_summary") or {}
        for k, v in conf.items():
            if isinstance(v, dict):
                print(f"  {k}: {v.get('level')} – {v.get('note')}")
        export = report.get("export") or {}
        if export:
            print(f"JSON: {export.get('json')}")
            print(f"TXT:  {export.get('txt')}")


def print_report_text(text: str) -> None:
    if RICH_AVAILABLE:
        console.print(Panel(text, title="ATLAS Report", border_style="blue", expand=False))
    else:
        print(text)


def print_error(msg: str) -> None:
    if RICH_AVAILABLE:
        console.print(f"[bold red]Error:[/bold red] {msg}")
    else:
        print(f"Error: {msg}")


def print_info(msg: str) -> None:
    if RICH_AVAILABLE:
        console.print(f"[bold]{msg}[/bold]")
    else:
        print(msg)