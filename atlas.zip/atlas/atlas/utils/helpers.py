"""
Utility helpers for ATLAS.
All network activity is passive and rate-limited.
"""

from __future__ import annotations

import ipaddress
import re
import socket
import time
import logging
from datetime import datetime, timezone
from typing import Any, Optional, Dict, Tuple
from urllib.parse import urlparse

logger = logging.getLogger("atlas.utils")

# Simple in-process rate limiter (per host)
_last_request: Dict[str, float] = {}
DEFAULT_DELAY = 1.2  # seconds between requests to the same host


def timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def confidence_label(score: float) -> str:
    """Map 0.0–1.0 score to human label."""
    if score >= 0.85:
        return "HIGH"
    if score >= 0.60:
        return "MEDIUM"
    if score >= 0.35:
        return "LOW"
    return "VERY LOW / UNVERIFIED"


def is_valid_ipv4(value: str) -> bool:
    try:
        return isinstance(ipaddress.ip_address(value.strip()), ipaddress.IPv4Address)
    except ValueError:
        return False


def is_valid_ipv6(value: str) -> bool:
    try:
        return isinstance(ipaddress.ip_address(value.strip()), ipaddress.IPv6Address)
    except ValueError:
        return False


def is_valid_domain(value: str) -> bool:
    """Basic domain validation (not exhaustive)."""
    value = value.strip().lower()
    if value.startswith("http://") or value.startswith("https://"):
        return False
    # Remove trailing dot
    value = value.rstrip(".")
    if len(value) > 253 or len(value) < 1:
        return False
    # Simple regex for domain-like strings
    pattern = re.compile(
        r"^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$",
        re.IGNORECASE,
    )
    return bool(pattern.match(value))


def is_valid_url(value: str) -> bool:
    try:
        result = urlparse(value.strip())
        return result.scheme in ("http", "https") and bool(result.netloc)
    except Exception:
        return False


def rate_limit(host: str, delay: float = DEFAULT_DELAY) -> None:
    """Simple per-host rate limiting."""
    now = time.time()
    last = _last_request.get(host, 0.0)
    wait = delay - (now - last)
    if wait > 0:
        time.sleep(wait)
    _last_request[host] = time.time()


def safe_request(
    url: str,
    timeout: float = 12.0,
    headers: Optional[Dict[str, str]] = None,
    method: str = "GET",
    allow_redirects: bool = True,
) -> Tuple[Optional[Any], Optional[str]]:
    """
    Perform a polite HTTP request.
    Returns (response_object_or_None, error_message_or_None).
    Prefers 'requests' if available, otherwise falls back to urllib.
    """
    parsed = urlparse(url)
    host = parsed.netloc
    rate_limit(host)

    default_headers = {
        "User-Agent": "ATLAS-OSINT/1.0 (Passive Research Agent; +https://github.com/example/atlas)",
        "Accept": "application/json, text/html, */*",
        "Accept-Language": "en-US,en;q=0.9",
    }
    if headers:
        default_headers.update(headers)

    try:
        import requests

        resp = requests.request(
            method=method,
            url=url,
            headers=default_headers,
            timeout=timeout,
            allow_redirects=allow_redirects,
        )
        return resp, None
    except ImportError:
        # Fallback to urllib
        import urllib.request
        import urllib.error

        req = urllib.request.Request(url, headers=default_headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                # Minimal response-like object
                class SimpleResponse:
                    def __init__(self, raw):
                        self.status_code = raw.status
                        self.text = raw.read().decode("utf-8", errors="replace")
                        self.content = self.text.encode("utf-8")
                        self.headers = dict(raw.headers)
                        self.url = raw.geturl()

                    def json(self):
                        import json
                        return json.loads(self.text)

                return SimpleResponse(resp), None
        except Exception as e:
            return None, str(e)
    except Exception as e:
        logger.debug("Request failed for %s: %s", url, e)
        return None, str(e)


def resolve_hostname(hostname: str) -> list[str]:
    """Resolve hostname to IP addresses using standard library."""
    results = []
    try:
        infos = socket.getaddrinfo(hostname, None)
        for info in infos:
            ip = info[4][0]
            if ip not in results:
                results.append(ip)
    except socket.gaierror:
        pass
    return results