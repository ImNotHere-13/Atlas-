"""
ATLAS – Python OSINT Intelligence Agent
Passive, ethical, modular open-source intelligence research tool.
"""

__version__ = "1.0.0"
__author__ = "ATLAS Project"
__description__ = "Standalone passive OSINT intelligence research agent"