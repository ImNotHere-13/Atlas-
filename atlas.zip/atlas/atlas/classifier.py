"""
Input classification for ATLAS.
Determines whether the target is an IP, domain, URL, organisation, or person.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional

from .utils.helpers import (
    is_valid_ipv4,
    is_valid_ipv6,
    is_valid_domain,
    is_valid_url,
)


class TargetType(Enum):
    IP = auto()
    DOMAIN = auto()
    URL = auto()
    ORGANISATION = auto()
    PERSON = auto()
    UNKNOWN = auto()


@dataclass
class ClassificationResult:
    original: str
    target_type: TargetType
    normalised: str
    confidence: float
    notes: str = ""


def classify(user_input: str) -> ClassificationResult:
    """
    Automatically classify the user input.
    Returns a ClassificationResult with type and normalised form.
    """
    raw = user_input.strip()
    if not raw:
        return ClassificationResult(raw, TargetType.UNKNOWN, "", 0.0, "Empty input")

    # 1. URL
    if is_valid_url(raw):
        from urllib.parse import urlparse
        parsed = urlparse(raw)
        host = parsed.netloc.lower()
        # Strip port if present
        if ":" in host and not host.startswith("["):
            host = host.split(":")[0]
        return ClassificationResult(
            original=raw,
            target_type=TargetType.URL,
            normalised=host,
            confidence=0.95,
            notes="Treated as URL; investigation focuses on host/domain",
        )

    # 2. IPv4 / IPv6
    if is_valid_ipv4(raw):
        return ClassificationResult(raw, TargetType.IP, raw, 0.99, "IPv4 address")
    if is_valid_ipv6(raw):
        return ClassificationResult(raw, TargetType.IP, raw, 0.99, "IPv6 address")

    # 3. Domain
    # Clean common prefixes
    candidate = raw.lower()
    for prefix in ("www.", "http://", "https://"):
        if candidate.startswith(prefix):
            candidate = candidate[len(prefix):]
    candidate = candidate.split("/")[0].split("?")[0].rstrip(".")

    if is_valid_domain(candidate):
        return ClassificationResult(
            original=raw,
            target_type=TargetType.DOMAIN,
            normalised=candidate,
            confidence=0.90,
            notes="Looks like a domain name",
        )

    # 4. Heuristic: person vs organisation
    # Very simple heuristics – these are intentionally conservative
    words = re.findall(r"[A-Za-z0-9&]+", raw)
    if len(words) >= 2 and all(w[0].isupper() or w.isupper() for w in words if w):
        # Could be a person name (e.g. "Tim Cook") or company
        # Prefer organisation if contains common company indicators
        lower = raw.lower()
        org_indicators = [
            "inc", "ltd", "llc", "corp", "corporation", "company", "group",
            "holdings", "technologies", "systems", "solutions", "services",
            "foundation", "university", "institute", "agency", "ministry",
        ]
        if any(ind in lower for ind in org_indicators):
            return ClassificationResult(
                original=raw,
                target_type=TargetType.ORGANISATION,
                normalised=raw.strip(),
                confidence=0.70,
                notes="Contains organisation indicators",
            )
        # Otherwise treat multi-word capitalised as possible person
        return ClassificationResult(
            original=raw,
            target_type=TargetType.PERSON,
            normalised=raw.strip(),
            confidence=0.55,
            notes="Multi-word capitalised name – treated as public figure / person (low confidence)",
        )

    # Single word or mixed – default to organisation
    return ClassificationResult(
        original=raw,
        target_type=TargetType.ORGANISATION,
        normalised=raw.strip(),
        confidence=0.50,
        notes="Treated as organisation / entity name (heuristic)",
    )