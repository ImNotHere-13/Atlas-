"""
ATLAS Investigation Engine – core orchestration.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional

from .classifier import classify, TargetType, ClassificationResult
from .modules.ip_module import investigate_ip
from .modules.domain_module import investigate_domain
from .modules.org_module import investigate_organisation
from .modules.person_module import investigate_person
from .report import export_json, export_txt, render_text_report

logger = logging.getLogger("atlas.agent")


class AtlasAgent:
    """
    Main intelligence research agent.
    Accepts a target, classifies it, runs the appropriate modules,
    and produces a structured report.
    """

    def __init__(self, output_dir: str = "reports"):
        self.output_dir = output_dir
        self.last_report: Optional[Dict[str, Any]] = None

    def investigate(
        self,
        user_input: str,
        progress_callback: Optional[Callable[[str], None]] = None,
        export: bool = True,
    ) -> Dict[str, Any]:
        """
        Run a full investigation on the given input.
        """
        def progress(msg: str):
            if progress_callback:
                progress_callback(msg)
            logger.info(msg)

        progress(f"Received target: {user_input}")
        classification = classify(user_input)
        progress(
            f"Classified as {classification.target_type.name} "
            f"(confidence {classification.confidence:.2f}) – {classification.notes}"
        )

        report: Dict[str, Any]

        if classification.target_type == TargetType.IP:
            report = investigate_ip(classification.normalised, progress_callback=progress)
        elif classification.target_type in (TargetType.DOMAIN, TargetType.URL):
            report = investigate_domain(classification.normalised, progress_callback=progress)
        elif classification.target_type == TargetType.ORGANISATION:
            report = investigate_organisation(classification.normalised, progress_callback=progress)
        elif classification.target_type == TargetType.PERSON:
            report = investigate_person(classification.normalised, progress_callback=progress)
        else:
            report = {
                "target": user_input,
                "target_type": "UNKNOWN",
                "error": "Could not classify input with sufficient confidence",
                "classification": {
                    "type": classification.target_type.name,
                    "confidence": classification.confidence,
                    "notes": classification.notes,
                },
                "suggestion": (
                    "Try a clearer IP address, domain name, organisation name, "
                    "or publicly known person's name."
                ),
            }

        # Attach classification metadata
        report["classification"] = {
            "original_input": classification.original,
            "normalised": classification.normalised,
            "type": classification.target_type.name,
            "confidence": classification.confidence,
            "notes": classification.notes,
        }

        # Legal assessment block (always present)
        report["legal_assessment"] = self._legal_assessment(classification.target_type)

        self.last_report = report

        if export and "error" not in report:
            try:
                json_path = export_json(report, self.output_dir)
                txt_path = export_txt(report, self.output_dir)
                report["export"] = {"json": json_path, "txt": txt_path}
                progress(f"Report exported → {json_path}")
                progress(f"Report exported → {txt_path}")
            except Exception as e:
                logger.warning("Export failed: %s", e)
                report["export_error"] = str(e)

        return report

    def _legal_assessment(self, target_type: TargetType) -> Dict[str, Any]:
        """
        Produce a structured legal / ethical classification of the research activity.
        This is guidance only, not formal legal advice.
        """
        base = {
            "disclaimer": (
                "This assessment is provided for transparency and awareness only. "
                "It is not formal legal advice. Actual legal position depends on "
                "jurisdiction, purpose of processing, data types involved, and "
                "specific collection methods. Seek qualified legal counsel for "
                "your particular use case."
            ),
            "primary_frameworks_considered": [
                "UK GDPR",
                "Data Protection Act 2018",
                "Computer Misuse Act 1990",
                "Privacy and Electronic Communications Regulations (PECR)",
            ],
            "activity_classification": {},
        }

        # Common classifications
        base["activity_classification"] = {
            "public_rdap_dns_ct_lookups": {
                "classification": "Generally permitted public research",
                "notes": "RDAP, DNS, and Certificate Transparency are designed as public data sources.",
            },
            "passive_http_observation": {
                "classification": "Generally permitted public research",
                "notes": "Requesting a publicly reachable web page and reading response headers/title is normally passive.",
            },
            "geolocation_of_public_ip": {
                "classification": "Generally permitted public research (with caveats)",
                "notes": (
                    "Approximate geolocation of a public IP is widely available. "
                    "However an IP address can constitute personal data under UK GDPR "
                    "in some contexts. Purpose and lawful basis matter."
                ),
            },
            "blocklist_reputation_checks": {
                "classification": "Generally permitted public research",
                "notes": "Querying public DNS-based blocklists is a standard passive technique.",
            },
            "automated_scraping_of_registries_or_social": {
                "classification": "Potentially restricted or regulated",
                "notes": (
                    "Bulk or automated collection from government registries or social platforms "
                    "may breach terms of service or data protection rules. ATLAS avoids this."
                ),
            },
            "unauthorised_access_or_credential_testing": {
                "classification": "Not permitted by the system",
                "notes": "Prohibited under the Computer Misuse Act 1990 and equivalent laws.",
            },
            "collection_of_private_personal_data": {
                "classification": "Not permitted by the system",
                "notes": "ATLAS deliberately does not seek private addresses, personal phones, passwords, or non-public accounts.",
            },
        }

        if target_type == TargetType.PERSON:
            base["activity_classification"]["person_focused_research"] = {
                "classification": "Requires careful assessment / additional authorisation may be needed",
                "notes": (
                    "Even public information about a living individual is personal data. "
                    "A lawful basis under UK GDPR is required for processing. "
                    "Special category data has further restrictions."
                ),
            }

        return base

    def render_last_report(self) -> str:
        if not self.last_report:
            return "No report available."
        return render_text_report(self.last_report)