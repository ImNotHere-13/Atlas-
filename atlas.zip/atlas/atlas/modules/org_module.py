"""
Organisation / company investigation module.
Focuses on public, official information only.
"""

from __future__ import annotations

import logging
from typing import Any, Dict
from urllib.parse import quote_plus

from ..sources.web_presence import basic_web_info
from ..utils.helpers import safe_request, timestamp, confidence_label

logger = logging.getLogger("atlas.modules.org")


def investigate_organisation(name: str, progress_callback=None) -> Dict[str, Any]:
    def progress(msg: str):
        if progress_callback:
            progress_callback(msg)
        logger.info(msg)

    report = {
        "target": name,
        "target_type": "ORGANISATION",
        "started_at": timestamp(),
        "completed_at": None,
        "sections": {},
        "confidence_summary": {},
        "sources_used": [],
        "limitations": [],
        "legal_notes": [],
        "search_hints": [],
    }

    progress("Performing passive public discovery for organisation...")

    # 1. Try to find an official website via simple heuristics + DuckDuckGo HTML (lightweight)
    # We avoid heavy scraping. Provide clear search URLs for the analyst.
    encoded = quote_plus(name)
    report["search_hints"] = [
        {
            "description": "General web search",
            "url": f"https://duckduckgo.com/?q={encoded}",
        },
        {
            "description": "Official site heuristic search",
            "url": f"https://duckduckgo.com/?q={encoded}+official+website",
        },
        {
            "description": "UK Companies House (if UK entity)",
            "url": f"https://find-and-update.company-information.service.gov.uk/search?q={encoded}",
        },
        {
            "description": "OpenCorporates (multi-jurisdiction)",
            "url": f"https://opencorporates.com/companies?q={encoded}",
        },
        {
            "description": "News coverage",
            "url": f"https://news.google.com/search?q={encoded}",
        },
    ]

    # 2. Attempt a few common official domains (very light heuristic)
    progress("Testing common official domain patterns (passive HEAD/GET)...")
    candidates = [
        f"{name.lower().replace(' ', '')}.com",
        f"{name.lower().replace(' ', '-')}.com",
        f"{name.lower().replace(' ', '')}.org",
        f"{name.lower().replace(' ', '')}.co.uk",
    ]
    # Clean candidates
    import re
    cleaned = []
    for c in candidates:
        c = re.sub(r"[^a-z0-9.-]", "", c)
        if c and c not in cleaned:
            cleaned.append(c)

    found_sites = []
    for cand in cleaned[:4]:
        web = basic_web_info(cand)
        if web.get("success") and web.get("status_code") and web["status_code"] < 400:
            found_sites.append({
                "domain": cand,
                "title": web.get("title"),
                "final_url": web.get("final_url"),
                "server": web.get("server"),
            })
            report["sources_used"].append(web.get("final_url") or cand)

    report["sections"]["possible_official_sites"] = {
        "candidates_tested": cleaned,
        "responsive_sites": found_sites,
        "note": "These are heuristic guesses only. Verify manually.",
    }

    if found_sites:
        report["confidence_summary"]["web_presence"] = {
            "level": confidence_label(0.45),
            "score": 0.45,
            "note": "One or more candidate domains responded – requires human verification",
        }
    else:
        report["confidence_summary"]["web_presence"] = {
            "level": confidence_label(0.15),
            "score": 0.15,
            "note": "No candidate domains responded; use the search hints below",
        }

    # 3. Placeholder for registry data – we point the user to official sources
    report["sections"]["business_registries"] = {
        "note": (
            "ATLAS does not scrape government registries automatically in order to "
            "respect terms of service and rate limits. Use the official search links provided."
        ),
        "recommended": [
            "UK: Companies House – https://find-and-update.company-information.service.gov.uk/",
            "US: SEC EDGAR, state business search portals",
            "Multi-jurisdiction: OpenCorporates, GLEIF (for LEIs)",
        ],
    }

    report["sections"]["social_and_news"] = {
        "note": "Search the provided news and general web links. Official social accounts are best confirmed from the organisation's own website.",
        "caution": "Do not treat unofficial social profiles as verified without cross-checking.",
    }

    report["limitations"].extend([
        "Organisation investigations are inherently less automated than IP/domain lookups.",
        "Many official registries require interactive use or have strict ToS against bulk scraping.",
        "Always verify any candidate website or registration data manually.",
    ])

    report["legal_notes"] = [
        "Collecting publicly available information about companies is generally permitted.",
        "Do not attempt to access non-public internal systems or employee personal data.",
        "If the organisation is a sole trader or the data includes living individuals, UK GDPR / DPA 2018 may apply.",
        "Respect robots.txt and website terms when performing any further manual research.",
    ]

    report["completed_at"] = timestamp()
    return report