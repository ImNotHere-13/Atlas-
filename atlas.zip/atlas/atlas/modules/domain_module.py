"""
Domain / website investigation module.
"""

from __future__ import annotations

import logging
from typing import Any, Dict

from ..sources.rdap import query_rdap_domain
from ..sources.dns_lookup import get_dns_records
from ..sources.cert_transparency import search_crtsh
from ..sources.web_presence import basic_web_info
from ..sources.geoip import lookup_ip_geo
from ..utils.helpers import timestamp, confidence_label, resolve_hostname

logger = logging.getLogger("atlas.modules.domain")


def investigate_domain(domain: str, progress_callback=None) -> Dict[str, Any]:
    def progress(msg: str):
        if progress_callback:
            progress_callback(msg)
        logger.info(msg)

    report = {
        "target": domain,
        "target_type": "DOMAIN",
        "started_at": timestamp(),
        "completed_at": None,
        "sections": {},
        "confidence_summary": {},
        "sources_used": [],
        "limitations": [],
        "legal_notes": [],
    }

    # RDAP / WHOIS-like
    progress("Querying public RDAP for domain registration data...")
    rdap = query_rdap_domain(domain)
    report["sections"]["registration"] = rdap
    if rdap.get("success"):
        report["sources_used"].append(rdap.get("source") or "RDAP")
        report["confidence_summary"]["registration"] = {
            "level": confidence_label(0.80),
            "score": 0.80,
            "note": "RDAP registration data",
        }
    else:
        report["confidence_summary"]["registration"] = {
            "level": confidence_label(0.25),
            "score": 0.25,
            "note": "RDAP failed – domain may be new, restricted, or service unavailable",
        }
        report["limitations"].append("Domain registration (RDAP) data incomplete.")

    # DNS
    progress("Collecting public DNS records...")
    dns = get_dns_records(domain)
    report["sections"]["dns"] = dns
    if dns.get("success"):
        report["sources_used"].append(f"DNS ({dns.get('method')})")
        report["confidence_summary"]["dns"] = {
            "level": confidence_label(0.90),
            "score": 0.90,
            "note": "Live DNS resolution",
        }
    else:
        report["confidence_summary"]["dns"] = {
            "level": confidence_label(0.2),
            "score": 0.2,
            "note": "DNS lookup failed",
        }

    # Resolve to IP(s) and light geo on primary
    progress("Resolving domain to IP addresses...")
    ips = resolve_hostname(domain)
    report["sections"]["resolved_ips"] = {
        "ips": ips,
        "count": len(ips),
    }
    if ips:
        primary = ips[0]
        progress(f"Looking up approximate location for primary IP {primary}...")
        geo = lookup_ip_geo(primary)
        report["sections"]["primary_ip_geo"] = geo
        if geo.get("success"):
            report["sources_used"].append(geo.get("source") or "GeoIP")

    # Certificate Transparency
    progress("Searching Certificate Transparency logs (crt.sh) for related names...")
    ct = search_crtsh(domain)
    report["sections"]["certificate_transparency"] = ct
    if ct.get("success"):
        report["sources_used"].append("crt.sh")
        report["confidence_summary"]["subdomains_ct"] = {
            "level": confidence_label(0.75),
            "score": 0.75,
            "note": f"Found {len(ct.get('unique_names', []))} unique names in CT logs",
        }
    else:
        report["confidence_summary"]["subdomains_ct"] = {
            "level": confidence_label(0.2),
            "score": 0.2,
            "note": "CT search failed or returned no data",
        }

    # Basic web presence
    progress("Fetching public HTTP headers and basic page information...")
    web = basic_web_info(domain)
    report["sections"]["web_presence"] = web
    if web.get("success"):
        report["sources_used"].append(web.get("final_url") or domain)
        report["confidence_summary"]["web"] = {
            "level": confidence_label(0.70),
            "score": 0.70,
            "note": "Public HTTP response observed",
        }

    report["legal_notes"] = [
        "Domain RDAP, DNS, and Certificate Transparency data are public by design.",
        "Observing a public website's headers and title is generally permitted passive research.",
        "Do not attempt to bypass authentication, scrape behind logins, or test for vulnerabilities without authorisation.",
        "UK Computer Misuse Act 1990 prohibits unauthorised access. This tool only requests publicly reachable resources.",
        "If the domain relates to an individual (e.g. personal site), treat any personal data under UK GDPR / DPA 2018 principles.",
    ]

    report["completed_at"] = timestamp()
    return report