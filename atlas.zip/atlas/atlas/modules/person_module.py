"""
Public figure / person investigation module.
Strictly limited to publicly available professional / public information.
Never attempts to locate private addresses, phone numbers, or non-public accounts.
"""

from __future__ import annotations

import logging
from typing import Any, Dict
from urllib.parse import quote_plus

from ..utils.helpers import timestamp, confidence_label

logger = logging.getLogger("atlas.modules.person")


def investigate_person(name: str, progress_callback=None) -> Dict[str, Any]:
    def progress(msg: str):
        if progress_callback:
            progress_callback(msg)
        logger.info(msg)

    report = {
        "target": name,
        "target_type": "PERSON",
        "started_at": timestamp(),
        "completed_at": None,
        "sections": {},
        "confidence_summary": {},
        "sources_used": [],
        "limitations": [],
        "legal_notes": [],
        "search_hints": [],
        "strict_boundary": (
            "ATLAS only assists with publicly available information relevant to a "
            "person's professional or public identity. It will not search for or "
            "report private addresses, personal phone numbers, private email accounts, "
            "passwords, or non-public social media."
        ),
    }

    progress("Preparing public-information search guidance for named individual...")

    encoded = quote_plus(name)

    report["search_hints"] = [
        {
            "description": "Professional / public web presence",
            "url": f"https://duckduckgo.com/?q={encoded}",
        },
        {
            "description": "News coverage",
            "url": f"https://news.google.com/search?q={encoded}",
        },
        {
            "description": "Possible professional profiles (LinkedIn public search)",
            "url": f"https://www.linkedin.com/search/results/all/?keywords={encoded}",
        },
        {
            "description": "Academic / publication search (if applicable)",
            "url": f"https://scholar.google.com/scholar?q={encoded}",
        },
        {
            "description": "Official or personal website heuristic",
            "url": f"https://duckduckgo.com/?q={encoded}+official+website+OR+biography",
        },
    ]

    report["sections"]["scope"] = {
        "permitted": [
            "Public professional profiles and biographies",
            "Published interviews and articles",
            "Public professional achievements and roles",
            "Official websites or organisational pages that mention the person",
            "Public news coverage",
        ],
        "not_permitted_by_atlas": [
            "Private residential addresses",
            "Personal telephone numbers",
            "Private email addresses or account credentials",
            "Non-public social media or private messages",
            "Live location tracking",
            "Any attempt to bypass access controls",
        ],
    }

    report["confidence_summary"]["overall"] = {
        "level": confidence_label(0.30),
        "score": 0.30,
        "note": (
            "Person investigations are deliberately low-automation. "
            "ATLAS provides curated public search starting points only. "
            "All findings must be manually verified and assessed for relevance and lawfulness."
        ),
    }

    report["limitations"] = [
        "No automated scraping of social networks or people-search sites.",
        "Results are search guidance, not a dossier.",
        "Public figures still have privacy rights; context and purpose matter.",
    ]

    report["legal_notes"] = [
        "Under UK GDPR and the Data Protection Act 2018, information relating to an identified or identifiable living individual is personal data.",
        "Even information that is public may still be personal data and require a lawful basis for processing.",
        "Special category data (health, politics, religion, etc.) has additional protections.",
        "The Computer Misuse Act 1990 prohibits unauthorised access to computer material.",
        "This module intentionally avoids collecting or surfacing private personal information.",
        "The assessment above is not formal legal advice. Legal conclusions depend on jurisdiction, purpose, and specific facts.",
    ]

    report["completed_at"] = timestamp()
    return report