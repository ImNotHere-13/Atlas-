"""
IP address investigation module.
Passive only.
"""

from __future__ import annotations

import ipaddress
import logging
from typing import Any, Dict

from ..sources.rdap import query_rdap_ip
from ..sources.geoip import lookup_ip_geo
from ..sources.reputation import check_ip_reputation
from ..utils.helpers import timestamp, confidence_label

logger = logging.getLogger("atlas.modules.ip")


def investigate_ip(ip: str, progress_callback=None) -> Dict[str, Any]:
    """
    Full passive investigation of a public IP address.
    """
    def progress(msg: str):
        if progress_callback:
            progress_callback(msg)
        logger.info(msg)

    report = {
        "target": ip,
        "target_type": "IP",
        "started_at": timestamp(),
        "completed_at": None,
        "sections": {},
        "confidence_summary": {},
        "sources_used": [],
        "limitations": [],
        "legal_notes": [],
    }

    # Basic validation / version
    progress("Determining IP version and basic properties...")
    try:
        addr = ipaddress.ip_address(ip)
        version = addr.version
        is_private = addr.is_private
        is_loopback = addr.is_loopback
        is_reserved = addr.is_reserved
        is_multicast = addr.is_multicast
        is_link_local = addr.is_link_local
        report["sections"]["basic"] = {
            "ip_version": f"IPv{version}",
            "is_private": is_private,
            "is_loopback": is_loopback,
            "is_reserved": is_reserved,
            "is_multicast": is_multicast,
            "is_link_local": is_link_local,
            "notes": [],
        }
        if is_private or is_loopback or is_reserved:
            report["sections"]["basic"]["notes"].append(
                "This address is not globally routable / is special-use. "
                "Public reputation and geolocation data will be limited or meaningless."
            )
            report["limitations"].append("Special-use or private IP – many public sources do not apply.")
    except ValueError:
        report["sections"]["basic"] = {"error": "Invalid IP address"}
        report["completed_at"] = timestamp()
        return report

    # RDAP / network registration
    progress("Querying public RDAP registries for network registration...")
    rdap = query_rdap_ip(ip)
    report["sections"]["rdap"] = rdap
    if rdap.get("success"):
        report["sources_used"].append(rdap.get("source") or "RDAP")
        summary = rdap.get("raw_summary", {})
        report["confidence_summary"]["network_registration"] = {
            "level": confidence_label(0.85),
            "score": 0.85,
            "note": "RDAP data from regional internet registry",
        }
    else:
        report["confidence_summary"]["network_registration"] = {
            "level": confidence_label(0.2),
            "score": 0.2,
            "note": "RDAP lookup failed or incomplete",
        }
        report["limitations"].append("Could not retrieve RDAP registration data.")

    # Geolocation (approximate)
    progress("Looking up approximate geolocation and ISP information...")
    geo = lookup_ip_geo(ip)
    report["sections"]["geolocation"] = geo
    if geo.get("success"):
        report["sources_used"].append(geo.get("source") or "GeoIP")
        report["confidence_summary"]["geolocation"] = {
            "level": confidence_label(0.65),
            "score": 0.65,
            "note": "Approximate only – city/region level at best. Never street-level or personal identification.",
        }
    else:
        report["confidence_summary"]["geolocation"] = {
            "level": confidence_label(0.1),
            "score": 0.1,
            "note": "Geolocation lookup failed",
        }

    # Reputation
    progress("Checking selected public reputation / blocklist sources...")
    rep = check_ip_reputation(ip)
    report["sections"]["reputation"] = rep
    if rep.get("success"):
        report["sources_used"].extend(rep.get("sources_checked", []))
        listed = [f for f in rep.get("findings", []) if f.get("listed") is True]
        score = 0.7 if listed else 0.55
        report["confidence_summary"]["reputation"] = {
            "level": confidence_label(score),
            "score": score,
            "note": f"{len(listed)} positive listing(s) among checked sources" if listed else "No listings among checked public RBLs",
        }

    # Legal / ethical notes specific to IP research
    report["legal_notes"] = [
        "Querying public RDAP, DNS, and free geolocation services for an IP address is generally considered passive public research.",
        "Do not attempt to map an IP to a specific individual or private residence without lawful authority.",
        "Geolocation data is approximate and must not be treated as precise personal location information.",
        "Under UK GDPR / DPA 2018, IP addresses can be personal data in certain contexts. Processing must have a lawful basis if personal data is involved.",
        "This tool performs only passive lookups and does not attempt unauthorised access (Computer Misuse Act 1990).",
    ]

    report["completed_at"] = timestamp()
    return report