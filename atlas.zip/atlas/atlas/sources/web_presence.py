"""
Lightweight public web presence checks.
Only retrieves publicly available information (headers, title, basic tech hints).
Does not crawl deeply or bypass protections.
"""

from __future__ import annotations

import logging
import re
from typing import Any, Dict, Optional
from urllib.parse import urljoin, urlparse

from ..utils.helpers import safe_request, timestamp

logger = logging.getLogger("atlas.sources.web")


def basic_web_info(host_or_url: str) -> Dict[str, Any]:
    """
    Fetch basic public information about a website:
    - Final URL after redirects
    - HTTP status
    - Server header
    - Page title (if HTML)
    - Simple technology hints from headers
    """
    result = {
        "queried_at": timestamp(),
        "target": host_or_url,
        "success": False,
        "url_tried": None,
        "final_url": None,
        "status_code": None,
        "headers": {},
        "title": None,
        "server": None,
        "technology_hints": [],
        "errors": [],
    }

    # Normalise to URL
    if not host_or_url.startswith(("http://", "https://")):
        candidates = [f"https://{host_or_url}", f"http://{host_or_url}"]
    else:
        candidates = [host_or_url]

    for url in candidates:
        result["url_tried"] = url
        resp, err = safe_request(url, timeout=12, allow_redirects=True)
        if err or resp is None:
            result["errors"].append(f"{url}: {err}")
            continue

        status = getattr(resp, "status_code", None)
        result["status_code"] = status
        result["final_url"] = getattr(resp, "url", url)

        headers = getattr(resp, "headers", {}) or {}
        # Normalise header keys to lower for convenience
        headers_lower = {k.lower(): v for k, v in headers.items()}
        result["headers"] = dict(list(headers_lower.items())[:20])  # limit size
        result["server"] = headers_lower.get("server")

        # Simple tech hints
        hints = []
        if "x-powered-by" in headers_lower:
            hints.append(f"X-Powered-By: {headers_lower['x-powered-by']}")
        if "server" in headers_lower:
            hints.append(f"Server: {headers_lower['server']}")
        if "cf-ray" in headers_lower or "cf-cache-status" in headers_lower:
            hints.append("Cloudflare detected")
        if "x-shopify" in str(headers_lower).lower() or "shopify" in headers_lower.get("server", "").lower():
            hints.append("Possible Shopify")
        if "x-generator" in headers_lower:
            hints.append(f"Generator: {headers_lower['x-generator']}")
        result["technology_hints"] = hints

        # Try to extract <title>
        try:
            text = getattr(resp, "text", "") or ""
            match = re.search(r"<title[^>]*>([^<]+)</title>", text, re.IGNORECASE | re.DOTALL)
            if match:
                result["title"] = match.group(1).strip()[:200]
        except Exception:
            pass

        result["success"] = True
        break

    return result