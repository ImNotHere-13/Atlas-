"""
DNS record collection using dnspython (preferred) or stdlib fallback.
"""

from __future__ import annotations

import logging
import socket
from typing import Any, Dict, List

from ..utils.helpers import timestamp

logger = logging.getLogger("atlas.sources.dns")


def get_dns_records(domain: str) -> Dict[str, Any]:
    """
    Collect common DNS records for a domain.
    Returns structured results with source indication.
    """
    result = {
        "queried_at": timestamp(),
        "domain": domain,
        "success": False,
        "records": {},
        "errors": [],
        "method": None,
    }

    # Prefer dnspython
    try:
        import dns.resolver
        import dns.exception

        resolver = dns.resolver.Resolver()
        resolver.lifetime = 8.0
        resolver.timeout = 5.0

        record_types = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"]

        for rtype in record_types:
            try:
                answers = resolver.resolve(domain, rtype)
                values = []
                for rdata in answers:
                    values.append(str(rdata).strip())
                if values:
                    result["records"][rtype] = values
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.resolver.NoNameservers):
                continue
            except dns.exception.Timeout:
                result["errors"].append(f"{rtype}: timeout")
            except Exception as e:
                result["errors"].append(f"{rtype}: {e}")

        if result["records"]:
            result["success"] = True
            result["method"] = "dnspython"
            return result

    except ImportError:
        result["errors"].append("dnspython not installed – falling back to stdlib")

    # Stdlib fallback (A / AAAA mainly)
    try:
        infos = socket.getaddrinfo(domain, None)
        a_records = []
        aaaa_records = []
        for info in infos:
            ip = info[4][0]
            if ":" in ip:
                if ip not in aaaa_records:
                    aaaa_records.append(ip)
            else:
                if ip not in a_records:
                    a_records.append(ip)
        if a_records:
            result["records"]["A"] = a_records
        if aaaa_records:
            result["records"]["AAAA"] = aaaa_records
        if result["records"]:
            result["success"] = True
            result["method"] = "socket.getaddrinfo"
    except Exception as e:
        result["errors"].append(f"stdlib resolve: {e}")

    return result