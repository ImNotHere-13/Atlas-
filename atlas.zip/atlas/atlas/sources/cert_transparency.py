"""
Certificate Transparency log search via crt.sh (public).
Useful for discovering subdomains and certificate history.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from ..utils.helpers import safe_request, timestamp

logger = logging.getLogger("atlas.sources.ct")


def search_crtsh(domain: str, max_results: int = 50) -> Dict[str, Any]:
    """
    Query crt.sh for certificates related to a domain.
    Returns unique names found in certificates.
    """
    result = {
        "queried_at": timestamp(),
        "domain": domain,
        "success": False,
        "source": "https://crt.sh",
        "certificates_found": 0,
        "unique_names": [],
        "sample_entries": [],
        "errors": [],
    }

    # crt.sh JSON endpoint
    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    resp, err = safe_request(url, timeout=20)
    if err or resp is None:
        result["errors"].append(str(err))
        return result

    if getattr(resp, "status_code", 0) != 200:
        result["errors"].append(f"HTTP {getattr(resp, 'status_code', '?')}")
        return result

    try:
        data = resp.json()
    except Exception as e:
        # crt.sh sometimes returns HTML on error / overload
        result["errors"].append(f"JSON parse failed (possible rate limit or empty result): {e}")
        return result

    if not isinstance(data, list):
        result["errors"].append("Unexpected response format")
        return result

    names = set()
    samples = []
    for entry in data[:max_results * 3]:  # allow some headroom
        name_value = entry.get("name_value") or entry.get("common_name") or ""
        for part in name_value.replace("\n", " ").split():
            part = part.strip().lower().lstrip("*.")
            if part.endswith(domain) or part == domain:
                names.add(part)
        if len(samples) < 8:
            samples.append({
                "id": entry.get("id"),
                "logged_at": entry.get("entry_timestamp"),
                "not_before": entry.get("not_before"),
                "not_after": entry.get("not_after"),
                "issuer": entry.get("issuer_name"),
                "name_value": name_value[:200],
            })

    result["success"] = True
    result["certificates_found"] = len(data)
    result["unique_names"] = sorted(names)[:max_results]
    result["sample_entries"] = samples
    return result