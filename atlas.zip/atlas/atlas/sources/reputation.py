"""
Public reputation / blocklist checks (passive).
Uses only publicly documented free endpoints.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from ..utils.helpers import safe_request, timestamp

logger = logging.getLogger("atlas.sources.reputation")


def check_ip_reputation(ip: str) -> Dict[str, Any]:
    """
    Check a few public, free reputation sources.
    These are indicators only – not definitive proof of malicious activity.
    """
    result = {
        "queried_at": timestamp(),
        "ip": ip,
        "success": False,
        "sources_checked": [],
        "findings": [],
        "errors": [],
        "disclaimer": (
            "Reputation data is incomplete and can contain false positives. "
            "Presence on a list does not automatically mean the IP is malicious. "
            "Always corroborate with multiple sources and context."
        ),
    }

    # 1. AbuseIPDB – public check is limited without key; we use a very light public view if available
    # We intentionally avoid requiring API keys. Instead we note the source for the user.

    # 2. Simple DNS-based blocklist checks (common public RBLs) – passive DNS queries only
    # These are standard and widely used.
    rbls = [
        ("zen.spamhaus.org", "Spamhaus ZEN"),
        ("bl.spamcop.net", "SpamCop"),
        ("dnsbl.sorbs.net", "SORBS"),
    ]

    reversed_ip = ".".join(reversed(ip.split("."))) if "." in ip else None

    if reversed_ip:
        import socket
        for zone, name in rbls:
            query = f"{reversed_ip}.{zone}"
            try:
                socket.gethostbyname(query)
                # If it resolves, it is listed
                result["findings"].append({
                    "source": name,
                    "listed": True,
                    "detail": f"Resolved via {query}",
                    "confidence": 0.7,
                })
            except socket.gaierror:
                result["findings"].append({
                    "source": name,
                    "listed": False,
                    "detail": "Not listed (NXDOMAIN / no answer)",
                    "confidence": 0.6,
                })
            except Exception as e:
                result["errors"].append(f"{name}: {e}")
            result["sources_checked"].append(name)

    # 3. Optional: public VirusTotal-like note (no key = limited)
    # We simply record that a manual check is recommended.
    result["findings"].append({
        "source": "Manual recommendation",
        "listed": None,
        "detail": (
            "For deeper reputation data consider checking "
            "https://www.abuseipdb.com/ , https://virustotal.com/ , "
            "or https://www.greynoise.io/ (respect their terms)."
        ),
        "confidence": 0.0,
    })

    result["success"] = True
    return result