"""
RDAP (Registration Data Access Protocol) lookups.
Uses public RDAP bootstrap and endpoints. No authentication required.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

from ..utils.helpers import safe_request, timestamp

logger = logging.getLogger("atlas.sources.rdap")

# Public RDAP bootstrap services
RDAP_BOOTSTRAP_IP = "https://data.iana.org/rdap/ipv4.json"
RDAP_BOOTSTRAP_DOMAIN = "https://rdap.org/domain/{domain}"
# Common public RDAP servers
IP_RDAP_SERVERS = [
    "https://rdap.arin.net/registry/ip/{ip}",
    "https://rdap.db.ripe.net/ip/{ip}",
    "https://rdap.apnic.net/ip/{ip}",
    "https://rdap.lacnic.net/rdap/ip/{ip}",
    "https://rdap.afrinic.net/rdap/ip/{ip}",
]


def _extract_entity_name(entity: Dict) -> Optional[str]:
    """Try to pull a human-readable name from an RDAP entity."""
    if "vcardArray" in entity:
        try:
            vcard = entity["vcardArray"][1]
            for item in vcard:
                if item[0] == "fn":
                    return item[3]
        except (IndexError, TypeError, KeyError):
            pass
    return entity.get("handle") or entity.get("name")


def query_rdap_ip(ip: str) -> Dict[str, Any]:
    """
    Query public RDAP services for an IP address.
    Returns a structured dict with findings and source metadata.
    """
    result = {
        "queried_at": timestamp(),
        "ip": ip,
        "success": False,
        "source": None,
        "data": {},
        "raw_summary": {},
        "errors": [],
    }

    for template in IP_RDAP_SERVERS:
        url = template.format(ip=ip)
        resp, err = safe_request(url, timeout=10)
        if err or resp is None:
            result["errors"].append(f"{url}: {err}")
            continue

        if getattr(resp, "status_code", 0) != 200:
            result["errors"].append(f"{url}: HTTP {getattr(resp, 'status_code', '?')}")
            continue

        try:
            data = resp.json()
        except Exception as e:
            result["errors"].append(f"{url}: JSON parse error – {e}")
            continue

        # Success
        result["success"] = True
        result["source"] = url
        result["data"] = data

        # Extract useful fields
        summary = {
            "handle": data.get("handle"),
            "name": data.get("name"),
            "type": data.get("type"),
            "country": data.get("country"),
            "start_address": data.get("startAddress"),
            "end_address": data.get("endAddress"),
            "ip_version": data.get("ipVersion"),
            "status": data.get("status"),
            "entities": [],
            "remarks": [],
            "links": [],
        }

        for ent in data.get("entities", []) or []:
            roles = ent.get("roles", [])
            name = _extract_entity_name(ent)
            summary["entities"].append({"roles": roles, "name": name, "handle": ent.get("handle")})

        for rem in data.get("remarks", []) or []:
            summary["remarks"].append({
                "title": rem.get("title"),
                "description": rem.get("description"),
            })

        for link in data.get("links", []) or []:
            summary["links"].append({"rel": link.get("rel"), "href": link.get("href")})

        result["raw_summary"] = summary
        break  # First successful response is enough

    return result


def query_rdap_domain(domain: str) -> Dict[str, Any]:
    """
    Query public RDAP for a domain name.
    """
    result = {
        "queried_at": timestamp(),
        "domain": domain,
        "success": False,
        "source": None,
        "data": {},
        "raw_summary": {},
        "errors": [],
    }

    # Primary public RDAP aggregator
    urls = [
        f"https://rdap.org/domain/{domain}",
        f"https://rdap.verisign.com/com/v1/domain/{domain}",
        f"https://rdap.nic.uk/domain/{domain}",
    ]

    for url in urls:
        resp, err = safe_request(url, timeout=12)
        if err or resp is None:
            result["errors"].append(f"{url}: {err}")
            continue
        if getattr(resp, "status_code", 0) != 200:
            result["errors"].append(f"{url}: HTTP {getattr(resp, 'status_code', '?')}")
            continue

        try:
            data = resp.json()
        except Exception as e:
            result["errors"].append(f"{url}: JSON error – {e}")
            continue

        result["success"] = True
        result["source"] = url
        result["data"] = data

        summary = {
            "ldhName": data.get("ldhName"),
            "unicodeName": data.get("unicodeName"),
            "status": data.get("status"),
            "port43": data.get("port43"),
            "events": data.get("events", []),
            "nameservers": [],
            "entities": [],
            "secureDNS": data.get("secureDNS"),
        }

        for ns in data.get("nameservers", []) or []:
            summary["nameservers"].append(ns.get("ldhName") or ns.get("unicodeName"))

        for ent in data.get("entities", []) or []:
            summary["entities"].append({
                "roles": ent.get("roles"),
                "handle": ent.get("handle"),
                "name": _extract_entity_name(ent),
            })

        result["raw_summary"] = summary
        break

    return result