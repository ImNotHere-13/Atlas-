"""
Approximate geolocation for public IP addresses.
Uses free public endpoints with clear attribution.
Never claims street-level accuracy.
"""

from __future__ import annotations

import logging
from typing import Any, Dict

from ..utils.helpers import safe_request, timestamp

logger = logging.getLogger("atlas.sources.geoip")


def lookup_ip_geo(ip: str) -> Dict[str, Any]:
    """
    Look up approximate location and network information for an IP.
    Primary source: ip-api.com (free, non-commercial, rate-limited).
    Fallback: ipinfo.io (limited free tier).
    """
    result = {
        "queried_at": timestamp(),
        "ip": ip,
        "success": False,
        "source": None,
        "data": {},
        "errors": [],
        "disclaimer": (
            "Geolocation is approximate (city/region level at best). "
            "It does not identify a specific person or exact address. "
            "Accuracy varies by provider and IP type (residential vs hosting)."
        ),
    }

    # 1. ip-api.com (HTTP, free for non-commercial)
    url = f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,asname,query,mobile,proxy,hosting"
    resp, err = safe_request(url, timeout=8)
    if resp is not None and getattr(resp, "status_code", 0) == 200:
        try:
            data = resp.json()
            if data.get("status") == "success":
                result["success"] = True
                result["source"] = "ip-api.com"
                result["data"] = {
                    "country": data.get("country"),
                    "country_code": data.get("countryCode"),
                    "region": data.get("regionName"),
                    "city": data.get("city"),
                    "postal": data.get("zip"),
                    "latitude": data.get("lat"),
                    "longitude": data.get("lon"),
                    "timezone": data.get("timezone"),
                    "isp": data.get("isp"),
                    "organisation": data.get("org"),
                    "as": data.get("as"),
                    "as_name": data.get("asname"),
                    "is_mobile": data.get("mobile"),
                    "is_proxy": data.get("proxy"),
                    "is_hosting": data.get("hosting"),
                }
                return result
            else:
                result["errors"].append(f"ip-api.com: {data.get('message')}")
        except Exception as e:
            result["errors"].append(f"ip-api.com parse: {e}")
    else:
        result["errors"].append(f"ip-api.com: {err or 'no response'}")

    # 2. Fallback – ipinfo.io (public, limited)
    url2 = f"https://ipinfo.io/{ip}/json"
    resp2, err2 = safe_request(url2, timeout=8)
    if resp2 is not None and getattr(resp2, "status_code", 0) == 200:
        try:
            data = resp2.json()
            result["success"] = True
            result["source"] = "ipinfo.io"
            loc = data.get("loc", "").split(",")
            result["data"] = {
                "country": data.get("country"),
                "region": data.get("region"),
                "city": data.get("city"),
                "postal": data.get("postal"),
                "latitude": float(loc[0]) if len(loc) == 2 else None,
                "longitude": float(loc[1]) if len(loc) == 2 else None,
                "timezone": data.get("timezone"),
                "organisation": data.get("org"),
                "hostname": data.get("hostname"),
            }
            return result
        except Exception as e:
            result["errors"].append(f"ipinfo.io parse: {e}")
    else:
        result["errors"].append(f"ipinfo.io: {err2 or 'no response'}")

    return result