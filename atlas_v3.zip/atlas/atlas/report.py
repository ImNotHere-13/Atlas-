"""
Report generation and export for ATLAS.

One document model (12 consistent sections) is rendered to plain text and to a
script-free, escaped HTML page. JSON is the full structured record. Exports are
written with owner-only permissions; precise-location keys are scrubbed.
"""

from __future__ import annotations

import copy
import json
import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from . import __version__
from .utils import html_safe as hg
from .utils.source_reliability import rate_source

SECTION_TITLES = [
    "Investigation overview", "Target classification", "Main findings", "Network information",
    "Professional information", "Sources consulted", "Source reliability",
    "Confidence assessments", "Limitations", "Privacy and legal considerations",
]

_PRECISE_KEYS = {"latitude", "longitude", "lat", "lon", "lng", "postal", "postcode", "zip", "zip_code"}
HANDLING_NOTE = (
    "This report may contain personal data. It is stored locally with owner-only permissions. "
    "Delete it when no longer needed (`reports delete <name>`, `reports purge <days>`), keep it only for the "
    "stated purpose, and do not share it without a lawful basis."
)


# ---------------------------------------------------------------------------
# Preparation / export
# ---------------------------------------------------------------------------

def _scrub_precise(node: Any) -> Any:
    if isinstance(node, dict):
        return {k: _scrub_precise(v) for k, v in node.items() if k.lower() not in _PRECISE_KEYS}
    if isinstance(node, list):
        return [_scrub_precise(v) for v in node]
    return node


def _strip_raw(report: Dict[str, Any]) -> Dict[str, Any]:
    for section in (report.get("sections") or {}).values():
        if isinstance(section, dict) and isinstance(section.get("data"), dict) and section.get("raw_summary"):
            section["data"] = {"_omitted": "raw payload omitted; re-run with --raw to include (contacts are always redacted)"}
    return report


def prepare_for_export(report: Dict[str, Any], include_raw: bool = False) -> Dict[str, Any]:
    out = _scrub_precise(copy.deepcopy(report))
    out.pop("export", None)
    return out if include_raw else _strip_raw(out)


def _safe_basename(target: str) -> str:
    cleaned = re.sub(r"[^\w.\-]+", "_", target.strip()).strip("._")[:80] or "unknown"
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"atlas_{cleaned}_{ts}"


def export_reports(report: Dict[str, Any], output_dir: str = "reports", include_raw: bool = False,
                   html: bool = False) -> Dict[str, str]:
    """Write JSON + TXT (and optionally HTML) sharing one base name. Returns {kind: path}."""
    os.makedirs(output_dir, mode=0o700, exist_ok=True)
    base = _safe_basename(str(report.get("target", "unknown")))
    data = prepare_for_export(report, include_raw)
    paths = {"json": os.path.join(output_dir, f"{base}.json"), "txt": os.path.join(output_dir, f"{base}.txt")}
    hg.write_private(paths["json"], json.dumps(data, indent=2, ensure_ascii=False, default=str))
    hg.write_private(paths["txt"], render_text_report(data))
    if html:
        paths["html"] = os.path.join(output_dir, f"{base}.html")
        hg.write_private(paths["html"], render_html_report(data))
    return paths


def export_json(report: Dict[str, Any], output_dir: str = "reports") -> str:
    return export_reports(report, output_dir)["json"]


def export_txt(report: Dict[str, Any], output_dir: str = "reports") -> str:
    return export_reports(report, output_dir)["txt"]


# ---------------------------------------------------------------------------
# Document model
# ---------------------------------------------------------------------------

def _source_reliability(report: Dict[str, Any]) -> List[Tuple[str, str, str]]:
    rows, seen = [], set()
    srcs = list(report.get("sources_used") or [])
    for s in (report.get("professional") or {}).get("sources", []):
        srcs.append(s.get("url") or "")
    for s in srcs:
        s = str(s)
        if s and s not in seen:
            seen.add(s)
            rating, why = rate_source(s)
            rows.append((s, rating, why))
    return rows


def _conf_line(label: str, v: Any) -> str:
    if isinstance(v, dict):
        note = f" — {v['note']}" if v.get("note") else ""
        return f"{label}: {v.get('level')} (score {v.get('score')}){note}"
    return f"{label}: {v}"


def build_document(report: Dict[str, Any]) -> List[Tuple[str, List[tuple]]]:
    report = _scrub_precise(report)          # defence in depth: never render coordinates/postcodes
    cls = report.get("classification") or {}
    sections: Dict[str, List[tuple]] = {t: [] for t in SECTION_TITLES}

    # 1 overview
    sections[SECTION_TITLES[0]].append(("kv", [
        ("Target", report.get("target")), ("Type", report.get("target_type")),
        ("Started", report.get("started_at")), ("Completed", report.get("completed_at")),
        ("ATLAS version", __version__),
        ("Mode", "OFFLINE (no network lookups)" if report.get("offline") else "online"),
        ("Scope", f"partial ({report['partial']} only)" if report.get("partial") else "full investigation"),
    ]))
    if report.get("error"):
        sections[SECTION_TITLES[0]].append(("warn", f"Error: {report['error']}"))
        if report.get("suggestion"):
            sections[SECTION_TITLES[0]].append(("p", report["suggestion"]))

    # 2 classification
    if cls:
        sections[SECTION_TITLES[1]].append(("kv", [
            ("Original input", cls.get("original_input")), ("Normalised", cls.get("normalised")),
            ("Type", cls.get("type")), ("Classifier confidence", cls.get("confidence")),
            ("Notes", cls.get("notes"))]))
    else:
        sections[SECTION_TITLES[1]].append(("p", "No classification recorded."))

    # 3 main findings
    kf = report.get("key_findings") or []
    sections[SECTION_TITLES[2]].append(("ul", [
        f"{f.get('finding')}  [confidence: {f.get('confidence', 'n/a')}; source: {f.get('source', 'n/a')}]" for f in kf
    ] or ["No findings were recorded."]))

    acc = report.get("accounts")
    if acc is not None:
        summ = (report.get("sections") or {}).get("scan_summary") or {}
        lines = []
        for a in acc.get("found", []):
            lines.append(f"MATCH – {a['platform']} ({a['category']}): {a['profile_url']}  "
                         f"[existence: {a['existence_confidence']}; identity: {a['identity_confidence']}]")
        if acc.get("status") == "offline":
            lines.append("Offline mode – no platforms were queried, so nothing can be said about this username.")
        elif not acc.get("found"):
            lines.append("No matches were found on the platforms ATLAS could check.")
        if summ:
            lines.append("Scan summary: " + ", ".join(f"{k.replace('_', ' ')}: {v}" for k, v in summ.items()))
        sections[SECTION_TITLES[2]].append(("p", "Accounts with the exact username (existence only; not proof of the same person):"))
        sections[SECTION_TITLES[2]].append(("ul", lines))

    # 4 network info
    net = {k: v for k, v in (report.get("sections") or {}).items() if k not in ("scope", "scan_summary")}
    sections[SECTION_TITLES[3]].append(("tree", net) if net else ("p", "Not applicable to this target type."))

    # 5 professional
    prof = report.get("professional")
    if prof:
        ident = prof.get("identity") or {}
        sections[SECTION_TITLES[4]].append(("kv", [("Identity assessment", str(ident.get("status", "")).replace("_", " ")),
                                                   ("Explanation", ident.get("explanation"))]))
        bio = prof.get("biography")
        if bio:
            sections[SECTION_TITLES[4]].append(("kv", [
                ("Biography (summary)", bio.get("text")), ("Description", bio.get("description")),
                ("Source", bio.get("source")), ("Reliability", bio.get("reliability")), ("Licence", bio.get("licence"))]))
        for title, key, label in (("Employment", "employment", None), ("Affiliations", "affiliations", "organisation"),
                                  ("Education", "education", "institution"), ("Achievements", "achievements", "achievement")):
            rows = prof.get(key) or []
            if rows:
                if key == "employment":
                    lines = [f"{', '.join(x for x in (r.get('job_title'), ', '.join(r.get('employer') or [])) if x)} "
                             f"(source: {r['source']}, reliability {r['source_reliability']})" for r in rows]
                else:
                    lines = [f"{r[label]} (source: {r['source']}, reliability {r['source_reliability']})" for r in rows]
                sections[SECTION_TITLES[4]].append(("p", title + ":"))
                sections[SECTION_TITLES[4]].append(("ul", lines))
        for s in prof.get("sources") or []:
            sections[SECTION_TITLES[4]].append(("kv", [("Source page", s.get("url")), ("Reliability", s.get("reliability")),
                                                       ("Name match", str(s.get("name_match")).replace("_", " ")),
                                                       ("Note", s.get("note") or "; ".join(s.get("errors") or []) or None)]))
        pi = prof.get("published_interviews") or {}
        sections[SECTION_TITLES[4]].append(("p", "Published interviews: " + str(pi.get("note", ""))))
    else:
        sections[SECTION_TITLES[4]].append(("p", "Not applicable to this target type."))

    # 6 sources
    srcs = list(dict.fromkeys(str(s) for s in (report.get("sources_used") or [])))
    sections[SECTION_TITLES[5]].append(("ul", srcs or ["No external sources returned data."]))
    hints = report.get("search_hints") or []
    if hints:
        sections[SECTION_TITLES[5]].append(("p", "Recommended public search starting points (manual use):"))
        sections[SECTION_TITLES[5]].append(("ul", [f"{h.get('description')}: {h.get('url')}" for h in hints]))

    # 7 reliability
    rel = report.get("source_reliability")
    rows = [(r["source"], r["rating"], r["rationale"]) for r in rel] if rel else _source_reliability(report)
    sections[SECTION_TITLES[6]].append(("ul", [f"{s} — {r}: {w}" for s, r, w in rows] or ["No sources to rate."]))

    # 8 confidence
    conf = report.get("confidence_summary") or {}
    sections[SECTION_TITLES[7]].append(("ul", [_conf_line(k, v) for k, v in conf.items()] or ["No confidence assessments recorded."]))

    # 9 limitations
    sections[SECTION_TITLES[8]].append(("ul", list(report.get("limitations") or []) or ["None recorded."]))

    # 10 privacy and legal
    legal = list(report.get("legal_notes") or [])
    sections[SECTION_TITLES[9]].append(("ul", legal or ["See SECURITY_AND_LEGAL.md."]))
    if report.get("strict_boundary"):
        sections[SECTION_TITLES[9]].append(("p", "Operational boundary: " + report["strict_boundary"]))
    la = report.get("legal_assessment") or {}
    if la.get("activity_classification"):
        sections[SECTION_TITLES[9]].append(("kv", [(k.replace("_", " "), f"{v['classification']} — {v['notes']}")
                                                    for k, v in la["activity_classification"].items()]))
    sections[SECTION_TITLES[9]].append(("p", HANDLING_NOTE))
    sections[SECTION_TITLES[9]].append(("p", la.get("disclaimer", "Not formal legal advice. Lawfulness depends on purpose, information, processing and circumstances.")))
    return [(t, sections[t]) for t in SECTION_TITLES]


# ---------------------------------------------------------------------------
# Text renderer
# ---------------------------------------------------------------------------

def _render_tree(lines: list, data: Any, indent: int = 0) -> None:
    prefix = " " * indent
    if isinstance(data, dict):
        for k, v in data.items():
            if k in ("data", "raw_summary") and isinstance(v, dict) and len(str(v)) > 400:
                lines.append(f"{prefix}{k}: <structured data – see JSON export for full content>")
                for sk, sv in list(v.items())[:12]:
                    lines.append(f"{prefix}  {sk}: {sv}")
                if len(v) > 12:
                    lines.append(f"{prefix}  ... ({len(v) - 12} more keys)")
            elif isinstance(v, (dict, list)) and len(str(v)) > 300:
                lines.append(f"{prefix}{k}:")
                _render_tree(lines, v, indent + 2)
            else:
                lines.append(f"{prefix}{k}: {v}")
    elif isinstance(data, list):
        for i, item in enumerate(data[:25]):
            if isinstance(item, dict):
                lines.append(f"{prefix}- item {i + 1}:")
                _render_tree(lines, item, indent + 2)
            else:
                lines.append(f"{prefix}- {item}")
        if len(data) > 25:
            lines.append(f"{prefix}... ({len(data) - 25} more items)")
    else:
        lines.append(f"{prefix}{data}")


def render_text_report(report: Dict[str, Any]) -> str:
    lines = ["=" * 72, "ATLAS INTELLIGENCE REPORT", "=" * 72]
    for n, (title, blocks) in enumerate(build_document(report), 1):
        lines += ["", "-" * 72, f"{n}. {title.upper()}", "-" * 72]
        for kind, payload in blocks:
            if kind == "kv":
                for k, v in payload:
                    if v not in (None, "", []):
                        lines.append(f"  {k:<22}: {v}")
                lines.append("")
            elif kind == "ul":
                lines += [f"  • {x}" for x in payload]
            elif kind in ("p", "warn"):
                if payload:
                    lines.append(f"  {payload}")
            elif kind == "tree":
                _render_tree(lines, payload, 2)
    lines += ["", "=" * 72, "END OF REPORT – Generated by ATLAS (passive OSINT agent)", "=" * 72]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# HTML renderer
# ---------------------------------------------------------------------------

def render_html_report(report: Dict[str, Any]) -> str:
    out = [f"<h1>ATLAS intelligence report</h1><p class='muted'>Generated {esc_now()} by ATLAS {hg.esc(__version__)}"
           " (passive OSINT). Contains no scripts; all values are escaped.</p>"]
    for n, (title, blocks) in enumerate(build_document(report), 1):
        out.append(f"<h2>{n}. {hg.esc(title)}</h2>")
        for kind, payload in blocks:
            if kind == "kv":
                rows = "".join(f"<tr><th>{hg.esc(k)}</th><td>{_linkify(v)}</td></tr>"
                               for k, v in payload if v not in (None, "", []))
                out.append(f"<table>{rows}</table>")
            elif kind == "ul":
                out.append("<ul>" + "".join(f"<li>{_linkify(x)}</li>" for x in payload) + "</ul>")
            elif kind == "p":
                out.append(f"<p>{_linkify(payload)}</p>")
            elif kind == "warn":
                out.append(f"<div class='notice'>{hg.esc(payload)}</div>")
            elif kind == "tree":
                lines: list = []
                _render_tree(lines, payload, 0)
                out.append(f"<pre>{hg.esc(chr(10).join(lines))}</pre>")
    return hg.page(f"ATLAS report – {report.get('target')}", "".join(out))


_URL_RE = re.compile(r"(https?://[^\s<>\"']+)")


def _linkify(text: Any) -> str:
    """Escape text and turn http(s) URLs into safe links."""
    text = "" if text is None else str(text)
    parts, last = [], 0
    for m in _URL_RE.finditer(text):
        parts.append(hg.esc(text[last:m.start()]))
        url = m.group(1).rstrip(".,;)]")
        parts.append(hg.safe_link(url))
        last = m.start() + len(url)
    parts.append(hg.esc(text[last:]))
    return "".join(parts)


def esc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
