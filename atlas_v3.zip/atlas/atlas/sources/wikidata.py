"""
Wikidata lookups (public, keyless MediaWiki API) for named public figures and organisations.

Purpose: (1) tell people/organisations with the same name apart (disambiguation) and
(2) obtain a community-recorded official website, occupation and employer.
Only professional/public facts are read: label, description, official website, occupation,
employer and the Wikipedia link. Birth dates, family, residence and other personal
properties are deliberately never requested or returned.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional
from urllib.parse import quote

from ..utils.helpers import safe_request, timestamp
from ..utils.network_safety import validate_url

API = "https://www.wikidata.org/w/api.php"
HUMAN = "Q5"
MAX_CANDIDATES = 5


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _get(url: str, result: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    resp, err = safe_request(url, timeout=12, retries=1)
    if resp is None:
        result["errors"].append(err or "no response")
        return None
    if resp.status_code != 200:
        result["errors"].append(f"HTTP {resp.status_code}")
        return None
    try:
        data = resp.json()
    except ValueError:
        result["errors"].append("invalid JSON")
        return None
    return data if isinstance(data, dict) else None


def _claim_values(entity: Dict[str, Any], prop: str) -> List[Any]:
    out = []
    for c in (entity.get("claims") or {}).get(prop, [])[:6]:
        try:
            out.append(c["mainsnak"]["datavalue"]["value"])
        except (KeyError, TypeError):
            continue
    return out


def _qids(values: List[Any]) -> List[str]:
    return [v["id"] for v in values if isinstance(v, dict) and isinstance(v.get("id"), str)]


def lookup(name: str, kind: str = "person") -> Dict[str, Any]:
    """
    kind: 'person' or 'org'. Returns {found, ambiguous, selected, candidates, errors, ...}.
    `selected` is set ONLY when exactly one exact-label candidate of the right kind exists.
    """
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "source": "Wikidata (public API)", "kind": kind,
        "found": False, "ambiguous": False, "selected": None, "candidates": [], "errors": [],
    }
    q = quote(name.strip(), safe="")
    data = _get(f"{API}?action=wbsearchentities&search={q}&language=en&uselang=en&type=item&limit=10&format=json", result)
    if not data:
        return result
    hits = [h for h in data.get("search", []) if isinstance(h, dict) and h.get("id")]
    exact = [h for h in hits if _norm(h.get("label", "")) == _norm(name) or
             _norm((h.get("match") or {}).get("text", "")) == _norm(name)]
    chosen = (exact or hits)[:MAX_CANDIDATES]
    if not chosen:
        return result

    ids = "|".join(h["id"] for h in chosen)
    ent = _get(f"{API}?action=wbgetentities&ids={ids}&props=labels|descriptions|claims|sitelinks"
               f"&languages=en&sitefilter=enwiki&format=json", result)
    entities = (ent or {}).get("entities", {})
    # second call: human-readable labels for occupation / employer items
    label_ids = set()
    for h in chosen:
        e = entities.get(h["id"], {})
        label_ids.update(_qids(_claim_values(e, "P106")) + _qids(_claim_values(e, "P108")))
    labels: Dict[str, str] = {}
    if label_ids:
        lab = _get(f"{API}?action=wbgetentities&ids={'|'.join(sorted(label_ids)[:40])}&props=labels&languages=en&format=json", result)
        for qid, e in ((lab or {}).get("entities") or {}).items():
            labels[qid] = ((e.get("labels") or {}).get("en") or {}).get("value", "")

    for h in chosen:
        e = entities.get(h["id"], {})
        is_human = HUMAN in _qids(_claim_values(e, "P31"))
        site = next((v for v in _claim_values(e, "P856") if isinstance(v, str) and validate_url(v)[0]), None)
        title = ((e.get("sitelinks") or {}).get("enwiki") or {}).get("title")
        result["candidates"].append({
            "qid": h["id"], "label": (h.get("label") or "")[:120], "description": (h.get("description") or "")[:200],
            "exact_label": h in exact, "is_human": is_human, "official_website": site,
            "occupations": [labels[q] for q in _qids(_claim_values(e, "P106")) if labels.get(q)][:5],
            "employers": [labels[q] for q in _qids(_claim_values(e, "P108")) if labels.get(q)][:5],
            "wikipedia_url": f"https://en.wikipedia.org/wiki/{quote(title.replace(' ', '_'))}" if title else None,
            "url": f"https://www.wikidata.org/wiki/{h['id']}",
        })

    pool = [c for c in result["candidates"] if c["exact_label"] and (c["is_human"] if kind == "person" else not c["is_human"])]
    result["found"] = bool(pool)
    if len(pool) == 1:
        result["selected"] = pool[0]
    elif len(pool) > 1:
        result["ambiguous"] = True
    return result
