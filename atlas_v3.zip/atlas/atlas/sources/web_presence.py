"""
Lightweight public web presence checks.
Only retrieves publicly available information (headers, title, basic tech
hints). Single request, size-capped, no crawling, public hosts only.
"""

from __future__ import annotations

import html
import logging
import re
from typing import Any, Dict

from . import page_metadata as pm

from ..utils.helpers import safe_request, timestamp

logger = logging.getLogger("atlas.sources.web")

_TITLE_RE = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)


def basic_web_info(host_or_url: str) -> Dict[str, Any]:
    """
    Fetch basic public information about a website: final URL, status code,
    Server header, page title and simple technology hints from headers.
    """
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "target": host_or_url, "success": False,
        "url_tried": None, "final_url": None, "status_code": None,
        "headers": {}, "title": None, "server": None,
        "technology_hints": [], "security_headers": {}, "errors": [],
        "site_name": None, "h1": None,
    }

    if host_or_url.startswith(("http://", "https://")):
        candidates = [host_or_url]
    else:
        candidates = [f"https://{host_or_url}", f"http://{host_or_url}"]

    for url in candidates:
        result["url_tried"] = url
        resp, err = safe_request(url, timeout=12, respect_robots=True)
        if err or resp is None:
            result["errors"].append(f"{url}: {err}")
            continue

        result["status_code"] = resp.status_code
        result["final_url"] = resp.url or url

        h = {k.lower(): v for k, v in (resp.headers or {}).items()}
        result["headers"] = dict(list(h.items())[:20])
        result["server"] = h.get("server")

        hints = []
        if "x-powered-by" in h:
            hints.append(f"X-Powered-By: {h['x-powered-by']}")
        if "server" in h:
            hints.append(f"Server: {h['server']}")
        if "cf-ray" in h or "cf-cache-status" in h:
            hints.append("Cloudflare detected")
        if any(k.startswith("x-shopify") for k in h) or "shopify" in h.get("server", "").lower():
            hints.append("Possible Shopify")
        if "x-generator" in h:
            hints.append(f"Generator: {h['x-generator']}")
        result["technology_hints"] = hints

        # Presence of common hardening headers (observation only).
        result["security_headers"] = {
            name: (name in h)
            for name in (
                "strict-transport-security", "content-security-policy",
                "x-content-type-options", "x-frame-options", "referrer-policy",
            )
        }

        content_type = h.get("content-type", "")
        if "html" in content_type.lower() or not content_type:
            m = _TITLE_RE.search(resp.text)
            if m:
                title = " ".join(html.unescape(m.group(1)).split())
                result["title"] = title[:200] or None
            doc = pm.extract(resp.text, result["final_url"])        # names used to verify what the site is
            result["site_name"] = (pm.meta_first(doc["meta"], "og:site_name", "application-name") or None)
            result["h1"] = (doc["h1"][0] if doc["h1"] else None)
            if result["site_name"]:
                result["site_name"] = result["site_name"][:120]

        result["success"] = True
        break

    return result
