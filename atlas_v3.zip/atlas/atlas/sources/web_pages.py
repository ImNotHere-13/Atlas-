"""
Fetch + parse ONE public web page (robots.txt honoured, SSRF-safe, size-capped).
Returns metadata only (title, headings, meta tags, JSON-LD); results are cached per investigation.
"""

from __future__ import annotations

from typing import Any, Dict

from ..utils.helpers import safe_request, timestamp
from . import page_metadata as pm

_cache: Dict[str, Dict[str, Any]] = {}


def clear_cache() -> None:
    _cache.clear()


def fetch_page(url: str) -> Dict[str, Any]:
    if url not in _cache:
        _cache[url] = _fetch(url)
    return _cache[url]


def _fetch(url: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {"page_url": url, "accessed_at": timestamp(), "ok": False, "page_title": None,
                           "site_name": None, "jsonld": [], "doc": {}, "errors": []}
    resp, err = safe_request(url, timeout=12, respect_robots=True)
    if resp is None:
        out["errors"].append(err or "no response")
        return out
    out["final_url"] = resp.url or url
    if resp.status_code != 200:
        out["errors"].append(f"HTTP {resp.status_code}")
        return out
    ctype = resp.header("Content-Type").split(";")[0].strip().lower()
    if "html" not in ctype:
        out["errors"].append(f"content type {ctype or 'unknown'!r} is not HTML")
        return out
    doc = pm.extract(resp.text, out["final_url"])
    out["ok"] = True
    out["page_title"] = pm.meta_first(doc["meta"], "og:title", "twitter:title") or doc["title"] or None
    out["site_name"] = pm.meta_first(doc["meta"], "og:site_name") or None
    out["jsonld"] = doc["jsonld"]
    out["doc"] = {"title": doc["title"], "h1": doc["h1"],
                  "meta": {k: v for k, v in doc["meta"].items() if k.startswith(("og:", "twitter:", "description"))}}
    return out
