"""
Certificate Transparency log search via crt.sh (public).
Useful for discovering subdomains and certificate history.
"""

from __future__ import annotations

import logging
from typing import Any, Dict

from ..utils.helpers import safe_request, timestamp

logger = logging.getLogger("atlas.sources.ct")


_MULTI_TLDS = {"co.uk", "org.uk", "ac.uk", "gov.uk", "me.uk", "ltd.uk", "plc.uk", "com.au", "net.au", "org.au",
               "co.nz", "co.jp", "co.in", "com.br", "com.cn", "co.za", "com.mx", "com.tr", "com.sg", "com.hk"}
MULTI_TENANT_SAN_LIMIT = 20       # certificates listing more names than this are shared (CDN) certs: ignored


def registrable(host: str) -> str:
    """Approximate registrable domain (handles common multi-part public suffixes)."""
    parts = host.lower().strip(".").split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in _MULTI_TLDS:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def _belongs_to(name: str, domain: str) -> bool:
    """True for the domain itself or a true subdomain (not 'evilexample.com')."""
    return name == domain or name.endswith("." + domain)


def search_crtsh(domain: str, max_results: int = 50, retries: int = 1) -> Dict[str, Any]:
    """Query crt.sh for certificates related to a domain."""
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "domain": domain, "success": False,
        "source": "https://crt.sh", "certificates_found": 0,
        "unique_names": [], "sample_entries": [], "errors": [], "related_domains": [],
    }

    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    data = None
    for attempt in range(retries + 1):
        resp, err = safe_request(url, timeout=25)
        if err or resp is None:
            result["errors"].append(f"attempt {attempt + 1}: {err}")
            continue
        if resp.status_code != 200:
            result["errors"].append(f"attempt {attempt + 1}: HTTP {resp.status_code}")
            continue
        try:
            data = resp.json()
            break
        except Exception as e:
            # crt.sh sometimes returns HTML on error / overload
            result["errors"].append(f"attempt {attempt + 1}: JSON parse failed ({e})")

    if data is None:
        return result
    if not isinstance(data, list):
        result["errors"].append("Unexpected response format")
        return result

    names = set()
    samples = []
    related: Dict[str, int] = {}
    own = registrable(domain)
    for entry in data[: max_results * 3]:
        name_value = entry.get("name_value") or entry.get("common_name") or ""
        parts = [x.strip().lower().lstrip("*.") for x in name_value.replace("\n", " ").split()]
        for part in parts:
            if _belongs_to(part, domain):
                names.add(part)
        if len(set(parts)) <= MULTI_TENANT_SAN_LIMIT:               # skip shared CDN certificates
            for part in set(parts):
                reg = registrable(part)
                if "." in part and reg != own and not part.startswith("sni"):
                    related[reg] = related.get(reg, 0) + 1
        if len(samples) < 8:
            samples.append({
                "id": entry.get("id"),
                "logged_at": entry.get("entry_timestamp"),
                "not_before": entry.get("not_before"),
                "not_after": entry.get("not_after"),
                "issuer": entry.get("issuer_name"),
                "name_value": name_value[:200],
            })

    result["success"] = True
    result["errors"] = []  # a retry succeeded; earlier attempts are noise
    result["certificates_found"] = len(data)
    result["unique_names"] = sorted(names)[:max_results]
    result["related_domains"] = [{"domain": d, "certificates": n} for d, n in
                                 sorted(related.items(), key=lambda kv: (-kv[1], kv[0]))[:25]]
    result["related_domains_note"] = ("Domains that appear on the same certificates as this one. Often the same owner, "
                                      "but also CDNs/hosting platforms and partners – verify before relying on them.")
    result["sample_entries"] = samples
    return result


def search_crtsh_org(org_name: str, max_results: int = 25) -> Dict[str, Any]:
    """
    Domains appearing on certificates issued to a subject organisation (OV/EV certificates only).
    crt.sh does not return the subject name in results, so matches cannot be verified here:
    treat every domain as a LOW-confidence lead.
    """
    from urllib.parse import quote
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "organisation": org_name, "success": False, "source": "https://crt.sh (O= search)",
        "domains": [], "errors": [],
        "note": "Leads only: crt.sh does not confirm the subject organisation in its results; verify each domain.",
    }
    resp, err = safe_request(f"https://crt.sh/?O={quote(org_name, safe='')}&output=json", timeout=25, retries=1)
    if resp is None or resp.status_code != 200:
        result["errors"].append(err or f"HTTP {getattr(resp, 'status_code', '?')}")
        return result
    try:
        data = resp.json()
    except ValueError:
        result["errors"].append("JSON parse failed")
        return result
    if not isinstance(data, list):
        result["errors"].append("Unexpected response format")
        return result
    counts: Dict[str, int] = {}
    for entry in data[:3000]:
        parts = [x.strip().lower().lstrip("*.") for x in (entry.get("name_value") or "").replace("\n", " ").split()]
        if len(set(parts)) > MULTI_TENANT_SAN_LIMIT:
            continue
        for part in set(parts):
            if "." in part and not part.startswith("sni"):
                counts[registrable(part)] = counts.get(registrable(part), 0) + 1
    result["success"] = True
    result["domains"] = [{"domain": d, "certificates": n} for d, n in
                         sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:max_results]]
    return result
