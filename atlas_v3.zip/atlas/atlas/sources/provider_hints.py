"""Infer hosting / email / DNS providers from DNS records already collected (no extra requests)."""

from __future__ import annotations

from typing import Any, Dict, List

_MX = {"google.com": "Google Workspace / Gmail", "googlemail.com": "Google Workspace / Gmail",
       "outlook.com": "Microsoft 365 / Exchange Online", "protection.outlook.com": "Microsoft 365 / Exchange Online",
       "mimecast.com": "Mimecast (email security)", "pphosted.com": "Proofpoint (email security)",
       "zoho.com": "Zoho Mail", "protonmail.ch": "Proton Mail", "messagingengine.com": "Fastmail",
       "mailgun.org": "Mailgun", "icloud.com": "Apple iCloud Mail", "yahoodns.net": "Yahoo Mail"}
_NS = {"cloudflare.com": "Cloudflare DNS", "awsdns": "Amazon Route 53", "azure-dns": "Microsoft Azure DNS",
       "googledomains.com": "Google Domains / Cloud DNS", "domaincontrol.com": "GoDaddy DNS",
       "registrar-servers.com": "Namecheap DNS", "nsone.net": "NS1", "dnsimple.com": "DNSimple",
       "ultradns": "UltraDNS", "akam.net": "Akamai DNS", "digitalocean.com": "DigitalOcean DNS"}
_SPF = {"_spf.google.com": "Google Workspace", "spf.protection.outlook.com": "Microsoft 365",
        "sendgrid.net": "SendGrid", "mailgun.org": "Mailgun", "amazonses.com": "Amazon SES",
        "servers.mcsv.net": "Mailchimp", "mandrillapp.com": "Mailchimp Transactional", "zoho.com": "Zoho",
        "salesforce.com": "Salesforce", "hubspot": "HubSpot", "zendesk": "Zendesk", "freshdesk": "Freshdesk"}


def _match(value: str, table: Dict[str, str]) -> List[str]:
    v = value.lower().rstrip(".")
    return [label for key, label in table.items() if key in v]


def infer_providers(records: Dict[str, List[str]]) -> Dict[str, Any]:
    out: Dict[str, Any] = {"email": [], "dns": [], "sending_services": [], "caveat":
                           "Inferred from public DNS records; indicates services configured, not who operates the domain."}
    for mx in records.get("MX", []):
        host = mx.split()[-1]
        for label in _match(host, _MX):
            if label not in out["email"]:
                out["email"].append(label)
    for ns in records.get("NS", []):
        for label in _match(ns, _NS):
            if label not in out["dns"]:
                out["dns"].append(label)
    for txt in records.get("TXT", []):
        if txt.lower().startswith("v=spf1"):
            for label in _match(txt, _SPF):
                if label not in out["sending_services"]:
                    out["sending_services"].append(label)
    return out
