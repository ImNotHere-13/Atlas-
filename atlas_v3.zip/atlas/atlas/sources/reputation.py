"""
Public reputation / blocklist checks (passive DNS-based blocklist queries).
"""

from __future__ import annotations

import ipaddress
import logging
import socket
from typing import Any, Dict, List, Optional, Tuple

from ..utils.helpers import is_offline, is_public_ip, timestamp

logger = logging.getLogger("atlas.sources.reputation")

# (zone, display name). Edit this list to add or remove sources.
RBLS: List[Tuple[str, str]] = [
    ("zen.spamhaus.org", "Spamhaus ZEN"),
    ("bl.spamcop.net", "SpamCop"),
]


def _rbl_query_name(ip: str, zone: str) -> str:
    """Reverse-notation query name for IPv4 *and* IPv6 addresses."""
    pointer = ipaddress.ip_address(ip).reverse_pointer
    for suffix in (".in-addr.arpa", ".ip6.arpa"):
        if pointer.endswith(suffix):
            pointer = pointer[: -len(suffix)]
    return f"{pointer}.{zone}"


def interpret_rbl_answer(answer: Optional[str]) -> Tuple[Optional[bool], str]:
    """
    Turn a DNSBL answer into (listed, detail).

    * NXDOMAIN (None)       -> not listed
    * 127.255.255.x         -> Spamhaus-style "query refused" (public resolver,
                               rate limit, etc.) -> UNKNOWN, *not* a listing
    * any other 127.x.x.x   -> listed
    * anything else         -> unknown (possible DNS hijack / wildcard)
    """
    if answer is None:
        return False, "Not listed (NXDOMAIN)"
    if answer.startswith("127.255.255."):
        return None, (
            f"Query refused by blocklist ({answer}) – typically a public/open resolver "
            "or rate limit; result is UNKNOWN, not a listing"
        )
    if answer.startswith("127."):
        return True, f"Listed (return code {answer})"
    return None, f"Unexpected answer {answer}; ignoring"


def check_ip_reputation(ip: str) -> Dict[str, Any]:
    """
    Check a few public, free DNS blocklists.
    Indicators only – not definitive proof of malicious activity.
    """
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "ip": ip, "success": False,
        "sources_checked": [], "findings": [], "errors": [],
        "disclaimer": (
            "Reputation data is incomplete and can contain false positives. "
            "Presence on a list does not automatically mean the IP is malicious. "
            "Always corroborate with multiple sources and context."
        ),
    }

    if is_offline():
        result["errors"].append("offline mode: blocklist checks skipped.")
        return result
    if not is_public_ip(ip):
        result["errors"].append("Not a public IP address; blocklist checks skipped.")
        return result

    for zone, name in RBLS:
        query = _rbl_query_name(ip, zone)
        try:
            answer: Optional[str] = socket.gethostbyname(query)
        except socket.gaierror:
            answer = None
        except Exception as e:
            result["errors"].append(f"{name}: {e}")
            continue
        listed, detail = interpret_rbl_answer(answer)
        result["findings"].append({
            "source": name,
            "listed": listed,
            "detail": detail,
            "confidence": 0.0 if listed is None else (0.7 if listed else 0.6),
        })
        result["sources_checked"].append(name)

    result["findings"].append({
        "source": "Manual recommendation",
        "listed": None,
        "detail": (
            "For deeper reputation data consider https://www.abuseipdb.com/ , "
            "https://virustotal.com/ or https://www.greynoise.io/ (respect their terms)."
        ),
        "confidence": 0.0,
    })
    result["success"] = bool(result["sources_checked"])
    return result
