"""
RDAP (Registration Data Access Protocol) lookups.
Uses the public rdap.org bootstrap redirector first, then well-known
registry endpoints as fallbacks. No authentication required.
"""

from __future__ import annotations

import copy
import logging
from typing import Any, Dict, List, Optional

from ..utils.helpers import safe_request, timestamp

logger = logging.getLogger("atlas.sources.rdap")

IP_RDAP_SERVERS = [
    "https://rdap.org/ip/{ip}",                      # bootstrap: redirects to the right RIR
    "https://rdap.arin.net/registry/ip/{ip}",
    "https://rdap.db.ripe.net/ip/{ip}",
    "https://rdap.apnic.net/ip/{ip}",
    "https://rdap.lacnic.net/rdap/ip/{ip}",
    "https://rdap.afrinic.net/rdap/ip/{ip}",
]

# TLD-specific registry endpoints, used only when the TLD actually matches.
TLD_RDAP_SERVERS = {
    "com": "https://rdap.verisign.com/com/v1/domain/{domain}",
    "net": "https://rdap.verisign.com/net/v1/domain/{domain}",
    "uk": "https://rdap.nic.uk/domain/{domain}",
}

_PERSONAL_VCARD_FIELDS = {"tel", "email", "adr", "geo", "impp"}


def redact_personal_contacts(data: Any) -> Any:
    """
    Return a deep copy of RDAP data with vCard phone / email / postal-address
    fields replaced by a marker. ATLAS's stated policy is not to collect
    personal contact details, so raw exports drop them by default.
    """
    data = copy.deepcopy(data)

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            vcard = node.get("vcardArray")
            if isinstance(vcard, list) and len(vcard) == 2 and isinstance(vcard[1], list):
                for item in vcard[1]:
                    if isinstance(item, list) and item and item[0] in _PERSONAL_VCARD_FIELDS:
                        item[1:] = [{}, "text", "[redacted by ATLAS]"]
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    walk(data)
    return data


def _extract_entity_name(entity: Dict) -> Optional[str]:
    """Try to pull a human-readable name from an RDAP entity."""
    vcard = entity.get("vcardArray")
    if isinstance(vcard, list) and len(vcard) == 2:
        try:
            for item in vcard[1]:
                if item[0] == "fn":
                    return item[3]
        except (IndexError, TypeError, KeyError):
            pass
    return entity.get("handle") or entity.get("name")


def _fetch_first(urls: List[str], result: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Try each URL in turn; record errors; return parsed JSON of the first success."""
    for url in urls:
        resp, err = safe_request(url, timeout=12)
        if err or resp is None:
            result["errors"].append(f"{url}: {err}")
            continue
        if resp.status_code != 200:
            result["errors"].append(f"{url}: HTTP {resp.status_code}")
            continue
        try:
            data = resp.json()
        except Exception as e:
            result["errors"].append(f"{url}: JSON parse error – {e}")
            continue
        result["source"] = resp.url or url
        return data
    return None


def query_rdap_ip(ip: str) -> Dict[str, Any]:
    """Query public RDAP services for an IP address."""
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "ip": ip, "success": False,
        "source": None, "data": {}, "raw_summary": {}, "errors": [],
    }
    data = _fetch_first([t.format(ip=ip) for t in IP_RDAP_SERVERS], result)
    if data is None:
        return result

    result["success"] = True
    result["data"] = redact_personal_contacts(data)
    result["raw_summary"] = {
        "handle": data.get("handle"),
        "name": data.get("name"),
        "type": data.get("type"),
        "country": data.get("country"),
        "start_address": data.get("startAddress"),
        "end_address": data.get("endAddress"),
        "ip_version": data.get("ipVersion"),
        "status": data.get("status"),
        "entities": [
            {"roles": e.get("roles"), "name": _extract_entity_name(e), "handle": e.get("handle")}
            for e in data.get("entities", []) or []
        ],
        "remarks": [
            {"title": r.get("title"), "description": r.get("description")}
            for r in data.get("remarks", []) or []
        ],
        "links": [
            {"rel": l.get("rel"), "href": l.get("href")} for l in data.get("links", []) or []
        ],
    }
    return result


def query_rdap_domain(domain: str) -> Dict[str, Any]:
    """Query public RDAP for a domain name."""
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "domain": domain, "success": False,
        "source": None, "data": {}, "raw_summary": {}, "errors": [],
    }
    urls = [f"https://rdap.org/domain/{domain}"]
    tld = domain.rsplit(".", 1)[-1].lower()
    if tld in TLD_RDAP_SERVERS:
        urls.append(TLD_RDAP_SERVERS[tld].format(domain=domain))

    data = _fetch_first(urls, result)
    if data is None:
        return result

    result["success"] = True
    result["data"] = redact_personal_contacts(data)
    result["raw_summary"] = {
        "ldhName": data.get("ldhName"),
        "unicodeName": data.get("unicodeName"),
        "status": data.get("status"),
        "port43": data.get("port43"),
        "events": data.get("events", []),
        "nameservers": [
            ns.get("ldhName") or ns.get("unicodeName") for ns in data.get("nameservers", []) or []
        ],
        "entities": [
            {"roles": e.get("roles"), "handle": e.get("handle"), "name": _extract_entity_name(e)}
            for e in data.get("entities", []) or []
        ],
        "secureDNS": data.get("secureDNS"),
    }
    return result
