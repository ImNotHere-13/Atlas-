"""
DNS record collection using only the standard library.

A small, strict DNS client (RFC 1035) is implemented here: UDP with TCP
fallback, name-compression handling with loop protection, and validation of
the transaction id and question section. It queries the system's configured
resolvers (/etc/resolv.conf). Where those cannot be determined (e.g. Windows),
only A/AAAA records are collected via the operating system's resolver.
"""

from __future__ import annotations

import logging
import os
import random
import socket
import struct
from typing import Any, Dict, List, Optional, Tuple

from ..utils.network_safety import OFFLINE_MESSAGE, is_offline
from ..utils.helpers import timestamp

logger = logging.getLogger("atlas.sources.dns")

QTYPES = {"A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "MX": 15, "TXT": 16, "AAAA": 28, "CAA": 257}
_TYPE_NAMES = {v: k for k, v in QTYPES.items()}
RECORD_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "CAA"]


class DNSError(Exception):
    pass


def get_system_nameservers(path: str = "/etc/resolv.conf") -> List[str]:
    servers: List[str] = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2 and parts[0] == "nameserver":
                    ns = parts[1].split("%")[0]
                    if ns not in servers:
                        servers.append(ns)
    except OSError:
        pass
    return servers[:3]


def build_query(name: str, qtype: int, txid: Optional[int] = None) -> Tuple[int, bytes]:
    txid = random.randint(0, 0xFFFF) if txid is None else txid
    header = struct.pack(">HHHHHH", txid, 0x0100, 1, 0, 0, 0)
    qname = b""
    for label in name.rstrip(".").split("."):
        try:
            raw = label.encode("idna")
        except UnicodeError:
            raise DNSError("invalid label")
        if not 1 <= len(raw) <= 63:
            raise DNSError("invalid label length")
        qname += bytes([len(raw)]) + raw
    return txid, header + qname + b"\x00" + struct.pack(">HH", qtype, 1)


def read_name(msg: bytes, offset: int) -> Tuple[str, int]:
    """Decode a (possibly compressed) name. Returns (name, offset_after_name)."""
    labels: List[str] = []
    end: Optional[int] = None
    jumps = 0
    while True:
        if offset >= len(msg):
            raise DNSError("name runs past end of message")
        length = msg[offset]
        if length == 0:
            offset += 1
            break
        if length & 0xC0 == 0xC0:
            if offset + 1 >= len(msg):
                raise DNSError("truncated compression pointer")
            if end is None:
                end = offset + 2
            offset = ((length & 0x3F) << 8) | msg[offset + 1]
            jumps += 1
            if jumps > 20:
                raise DNSError("compression loop")
            continue
        if length & 0xC0:
            raise DNSError("unsupported label type")
        offset += 1
        if offset + length > len(msg):
            raise DNSError("label runs past end of message")
        labels.append(msg[offset:offset + length].decode("ascii", errors="replace"))
        offset += length
    return ".".join(labels), (end if end is not None else offset)


def parse_response(data: bytes, txid: int) -> Tuple[int, bool, List[Tuple[str, str]]]:
    """Return (rcode, truncated, [(type_name, value), ...]). Raises DNSError on malformed data."""
    if len(data) < 12:
        raise DNSError("short response")
    rid, flags, qd, an, _ns, _ar = struct.unpack(">HHHHHH", data[:12])
    if rid != txid:
        raise DNSError("transaction id mismatch")
    if not flags & 0x8000:
        raise DNSError("not a response")
    rcode, truncated = flags & 0xF, bool(flags & 0x0200)
    off = 12
    for _ in range(qd):
        _, off = read_name(data, off)
        off += 4
    out: List[Tuple[str, str]] = []
    for _ in range(min(an, 64)):
        _, off = read_name(data, off)
        if off + 10 > len(data):
            raise DNSError("truncated record header")
        rtype, _cls, _ttl, rdlen = struct.unpack(">HHIH", data[off:off + 10])
        off += 10
        rdata_end = off + rdlen
        if rdata_end > len(data):
            raise DNSError("record data runs past end of message")
        tname = _TYPE_NAMES.get(rtype)
        if tname:
            out.append((tname, _decode_rdata(data, off, rdlen, tname)))
        off = rdata_end
    return rcode, truncated, out


def _decode_rdata(msg: bytes, off: int, rdlen: int, tname: str) -> str:
    raw = msg[off:off + rdlen]
    if tname == "A" and rdlen == 4:
        return socket.inet_ntop(socket.AF_INET, raw)
    if tname == "AAAA" and rdlen == 16:
        return socket.inet_ntop(socket.AF_INET6, raw)
    if tname in ("NS", "CNAME"):
        return read_name(msg, off)[0]
    if tname == "MX":
        pref = struct.unpack(">H", raw[:2])[0]
        return f"{pref} {read_name(msg, off + 2)[0]}"
    if tname == "TXT":
        parts, i = [], 0
        while i < len(raw):
            n = raw[i]
            parts.append(raw[i + 1:i + 1 + n].decode("utf-8", errors="replace"))
            i += 1 + n
        return "".join(parts)
    if tname == "SOA":
        mname, o = read_name(msg, off)
        rname, o = read_name(msg, o)
        serial, refresh, retry, expire, minimum = struct.unpack(">IIIII", msg[o:o + 20])
        return f"{mname} {rname} {serial} {refresh} {retry} {expire} {minimum}"
    if tname == "CAA" and rdlen >= 2:
        flags, tag_len = raw[0], raw[1]
        tag = raw[2:2 + tag_len].decode("ascii", errors="replace")
        return f'{flags} {tag} "{raw[2 + tag_len:].decode("utf-8", errors="replace")}"'
    return raw.hex()


def query(name: str, rtype: str, server: str, timeout: float = 4.0) -> Tuple[int, List[Tuple[str, str]]]:
    txid, packet = build_query(name, QTYPES[rtype])
    family = socket.AF_INET6 if ":" in server else socket.AF_INET
    with socket.socket(family, socket.SOCK_DGRAM) as s:
        s.settimeout(timeout)
        s.sendto(packet, (server, 53))
        data, _ = s.recvfrom(4096)
    rcode, truncated, answers = parse_response(data, txid)
    if truncated:
        with socket.socket(family, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            s.connect((server, 53))
            s.sendall(struct.pack(">H", len(packet)) + packet)
            hdr = s.recv(2)
            if len(hdr) < 2:
                raise DNSError("short TCP response")
            need, buf = struct.unpack(">H", hdr)[0], b""
            while len(buf) < need and len(buf) < 65535:
                chunk = s.recv(need - len(buf))
                if not chunk:
                    break
                buf += chunk
        rcode, _, answers = parse_response(buf, txid)
    return rcode, answers


def get_dns_records(domain: str) -> Dict[str, Any]:
    """Collect common DNS records for a domain."""
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "domain": domain, "success": False,
        "records": {}, "errors": [], "method": None,
    }
    if is_offline():
        result["errors"].append(OFFLINE_MESSAGE)
        return result

    servers = get_system_nameservers()
    if servers:
        result["method"] = f"stdlib DNS client via {servers[0]}"
        for rtype in RECORD_TYPES:
            for server in servers:
                try:
                    rcode, answers = query(domain, rtype, server)
                except (OSError, DNSError, UnicodeError) as e:
                    result["errors"].append(f"{rtype}@{server}: {e}")
                    continue
                values = [v for t, v in answers if t == rtype]
                if values:
                    result["records"][rtype] = values
                break                       # got a definite answer (even if empty)
        if result["records"]:
            result["success"] = True
            return result

    # Fallback: OS resolver, A/AAAA only
    try:
        a, aaaa = [], []
        for info in socket.getaddrinfo(domain, None, type=socket.SOCK_STREAM):
            ip = info[4][0]
            bucket = aaaa if ":" in ip else a
            if ip not in bucket:
                bucket.append(ip)
        if a:
            result["records"]["A"] = a
        if aaaa:
            result["records"]["AAAA"] = aaaa
        if result["records"]:
            result["success"] = True
            result["method"] = "socket.getaddrinfo (A/AAAA only)"
    except (OSError, UnicodeError) as e:
        result["errors"].append(f"stdlib resolve: {e}")
    return result
