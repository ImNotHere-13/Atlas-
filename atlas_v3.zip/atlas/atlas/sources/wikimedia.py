"""
Wikipedia / Wikimedia Commons lookups (public, keyless, community-edited).

Used only for named public figures. Returns a short summary and the page URL.
This is a public MediaWiki endpoint, not a paid or key-based API.
"""

from __future__ import annotations

import html
import re
from typing import Any, Dict, Optional
from urllib.parse import quote, unquote, urlparse

from ..utils.helpers import safe_request, timestamp
from .page_metadata import tokens

SUMMARY_URL = "https://en.wikipedia.org/api/rest_v1/page/summary/{title}"
_TAG_RE = re.compile(r"<[^>]+>")


def _clean(value: Any, limit: int = 300) -> str:
    if not isinstance(value, str):
        return ""
    return " ".join(html.unescape(_TAG_RE.sub(" ", value)).split())[:limit]


def _title_matches(requested: str, returned: str) -> bool:
    returned = re.sub(r"\s*\(.*?\)\s*", " ", returned or "")
    return tokens(requested) == tokens(returned)


def lookup_person(name: str, with_licence: bool = False) -> Dict[str, Any]:
    """
    Look up a Wikipedia summary for *name*.
    Result keys: found, ambiguous, name_match, title, description, extract, page_url,
    image {url, thumbnail, licence...}, errors, queried_at.
    """
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "source": "Wikipedia (en) public REST API",
        "found": False, "ambiguous": False, "name_match": False, "errors": [],
    }
    title = quote(name.strip().replace(" ", "_"), safe="")
    resp, err = safe_request(SUMMARY_URL.format(title=title), timeout=10)
    if resp is None:
        result["errors"].append(err or "no response")
        return result
    if resp.status_code == 404:
        result["errors"].append("No Wikipedia article with this exact title.")
        return result
    if resp.status_code != 200:
        result["errors"].append(f"HTTP {resp.status_code}")
        return result
    try:
        data = resp.json()
    except ValueError as e:
        result["errors"].append(f"JSON error: {e}")
        return result

    if data.get("type") == "disambiguation":
        result["ambiguous"] = True
        result["page_url"] = ((data.get("content_urls") or {}).get("desktop") or {}).get("page")
        return result

    result["found"] = True
    result["title"] = _clean(data.get("title"), 150)
    result["name_match"] = _title_matches(name, data.get("title", ""))
    result["description"] = _clean(data.get("description"), 200)
    result["extract"] = _clean(data.get("extract"), 900)
    result["page_url"] = ((data.get("content_urls") or {}).get("desktop") or {}).get("page")

    if not result["name_match"]:
        return result      # redirected to a differently-named article: do not use its image

    return result
