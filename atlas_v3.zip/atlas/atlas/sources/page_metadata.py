"""
Metadata extraction from public HTML pages using html.parser (stdlib).
Never executes or renders page content; output is plain data.
"""

from __future__ import annotations

import html
import json
import re
from html.parser import HTMLParser
from typing import Any, Dict, Iterator, List
from urllib.parse import urljoin

MAX_JSONLD_BLOCKS = 10
MAX_JSONLD_CHARS = 200_000


class _Parser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.title = ""
        self.meta: Dict[str, List[str]] = {}
        self.links: Dict[str, List[str]] = {}
        self.jsonld: List[str] = []
        self.h1: List[str] = []
        self._in_title = False
        self._in_jsonld = False
        self._in_h1 = False
        self._buf: List[str] = []

    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        if tag == "title" and not self.title:
            self._in_title, self._buf = True, []
        elif tag == "meta":
            key = (a.get("property") or a.get("name") or a.get("itemprop") or "").lower()
            if key and "content" in a:
                self.meta.setdefault(key, []).append(a["content"].strip())
        elif tag == "link" and a.get("href"):
            for rel in a.get("rel", "").lower().split():
                self.links.setdefault(rel, []).append(a["href"].strip())
        elif tag == "script" and "ld+json" in a.get("type", "").lower():
            if len(self.jsonld) < MAX_JSONLD_BLOCKS:
                self._in_jsonld, self._buf = True, []
        elif tag == "h1" and len(self.h1) < 3:
            self._in_h1, self._buf = True, []

    def handle_data(self, data):
        if self._in_title or self._in_jsonld or self._in_h1:
            self._buf.append(data)

    def handle_endtag(self, tag):
        if tag == "title" and self._in_title:
            self.title = " ".join("".join(self._buf).split())[:300]
            self._in_title = False
        elif tag == "script" and self._in_jsonld:
            self.jsonld.append("".join(self._buf)[:MAX_JSONLD_CHARS])
            self._in_jsonld = False
        elif tag == "h1" and self._in_h1:
            self.h1.append(" ".join("".join(self._buf).split())[:200])
            self._in_h1 = False


def extract(html_text: str, base_url: str = "") -> Dict[str, Any]:
    p = _Parser()
    try:
        p.feed(html_text)
        p.close()
    except Exception:       # malformed HTML must never crash a report
        pass
    nodes: List[Dict[str, Any]] = []
    for block in p.jsonld:
        try:
            nodes.extend(iter_jsonld_nodes(json.loads(block)))
        except (ValueError, RecursionError):
            continue
    return {
        "title": p.title, "meta": p.meta, "links": p.links, "h1": p.h1,
        "jsonld": nodes, "base_url": base_url,
    }


def meta_first(meta: Dict[str, List[str]], *keys: str) -> str:
    for k in keys:
        vals = meta.get(k.lower())
        if vals and vals[0]:
            return vals[0]
    return ""


def iter_jsonld_nodes(data: Any, depth: int = 0) -> Iterator[Dict[str, Any]]:
    """Flatten JSON-LD (@graph, lists, nested objects) into typed dict nodes."""
    if depth > 6:
        return
    if isinstance(data, list):
        for item in data[:50]:
            yield from iter_jsonld_nodes(item, depth + 1)
    elif isinstance(data, dict):
        if "@type" in data:
            yield data
        if "@graph" in data:
            yield from iter_jsonld_nodes(data["@graph"], depth + 1)


def node_types(node: Dict[str, Any]) -> List[str]:
    t = node.get("@type")
    if isinstance(t, str):
        return [t]
    if isinstance(t, list):
        return [x for x in t if isinstance(x, str)]
    return []


def text_of(value: Any, limit: int = 200) -> str:
    """Coerce a JSON-LD value (str / {name:..} / list) to a short clean string."""
    if isinstance(value, dict):
        value = value.get("name") or value.get("@id") or ""
    elif isinstance(value, list):
        value = value[0] if value else ""
        if isinstance(value, dict):
            value = value.get("name") or ""
    if not isinstance(value, str):
        return ""
    return " ".join(html.unescape(value).split())[:limit]


def image_urls_from_jsonld_value(value: Any, base_url: str) -> List[Dict[str, str]]:
    """Return [{url, caption, license, credit}] from a JSON-LD image/logo property."""
    out: List[Dict[str, str]] = []
    items = value if isinstance(value, list) else [value]
    for item in items[:5]:
        if isinstance(item, str):
            out.append({"url": urljoin(base_url, item), "caption": "", "license": "", "credit": ""})
        elif isinstance(item, dict):
            u = item.get("contentUrl") or item.get("url") or item.get("@id")
            if isinstance(u, str):
                out.append({
                    "url": urljoin(base_url, u),
                    "caption": text_of(item.get("caption") or item.get("description") or item.get("name")),
                    "license": text_of(item.get("license")),
                    "credit": text_of(item.get("creditText") or item.get("creator")
                                      or item.get("copyrightHolder")),
                })
    return out


def tokens(name: str) -> List[str]:
    return [t for t in re.findall(r"[^\W_]+", name.lower()) if len(t) > 1]


def name_in_text(name: str, text: str) -> bool:
    """True if every significant token of *name* appears as a whole word in *text*."""
    toks = tokens(name)
    hay = set(re.findall(r"[^\W_]+", (text or "").lower()))
    return bool(toks) and all(t in hay for t in toks)
