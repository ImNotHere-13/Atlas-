"""
Internet Archive (Wayback Machine) capture history via its public CDX API (keyless).
Gives a domain's age/continuity signal: first capture, latest capture, months with captures.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from ..utils.helpers import safe_request, timestamp

CDX = "https://web.archive.org/cdx/search/cdx"
_TS = re.compile(r"^\d{14}$")


def _rows(url: str, result: Dict[str, Any]) -> Optional[List[List[str]]]:
    resp, err = safe_request(url, timeout=20, retries=1)
    if resp is None:
        result["errors"].append(err or "no response")
        return None
    if resp.status_code != 200:
        result["errors"].append(f"HTTP {resp.status_code}")
        return None
    text = resp.text.strip()
    if not text:
        return []
    try:
        data = resp.json()
    except ValueError:
        result["errors"].append("invalid JSON")
        return None
    return [r for r in data[1:] if isinstance(r, list) and r] if isinstance(data, list) else None


def _fmt(ts: str) -> str:
    return f"{ts[:4]}-{ts[4:6]}-{ts[6:8]}"


def _snap(ts: str, domain: str) -> str:
    return f"https://web.archive.org/web/{ts}/https://{domain}/"


def query_wayback(domain: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "domain": domain, "success": False, "source": "web.archive.org (CDX API)",
        "captures_found": False, "first_capture": None, "last_capture": None, "months_with_captures": 0,
        "first_snapshot_url": None, "last_snapshot_url": None, "errors": [],
        "note": "Archive captures show that a site existed at a time; they do not show who operated it.",
    }
    base = f"{CDX}?url={domain}&output=json&fl=timestamp"
    first = _rows(base + "&limit=1", result)
    if first is None:
        return result
    result["success"] = True
    if not first or not _TS.match(str(first[0][0])):
        return result                                          # reachable, but nothing archived
    last = _rows(base + "&limit=-1", result)
    monthly = _rows(base + "&collapse=timestamp:6&limit=3000", result)
    f_ts = str(first[0][0])
    l_ts = str(last[0][0]) if last and _TS.match(str(last[0][0])) else f_ts
    result.update(captures_found=True, first_capture=_fmt(f_ts), last_capture=_fmt(l_ts),
                  months_with_captures=len(monthly) if monthly else 0,
                  first_snapshot_url=_snap(f_ts, domain), last_snapshot_url=_snap(l_ts, domain))
    return result
