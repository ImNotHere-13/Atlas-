"""
Username presence checks on public platforms (passive, existence only).

For each platform ATLAS requests ONE public profile/API URL for the exact username and
interprets the HTTP response. It never stores profile content (bio, photos, followers, location),
never logs in, never tries variants, and never links accounts to a person.

Accuracy protections (important with a large platform list):
* robots.txt is honoured (platforms that disallow automated access are reported as skipped)
* usernames are validated against each platform's own format before any request is made
* soft-404 detection: a 200 page whose title/heading says "not found" is treated as absent
* TWO CONTROL CHECKS: when a name looks "found", two random names that cannot exist are tested on
  the same platform; if either also looks "found" the platform is marked unreliable
* transient failures (429/502/503/504, connection errors) are retried once; long Retry-After is respected
* graded confidence: HIGH (controls passed AND the username appears in the page title/URL),
  MEDIUM (controls passed), LOW (controls inconclusive)
* `selftest` health-checks every rule with a negative control and, where available, a known-good account

Page text is read transiently (first 100 KB) only to compute two booleans (soft-404, username-in-title);
nothing from it is stored.

The platform list lives in atlas/data/platforms.json and can be replaced with your own file (--platforms).
Policy: mainstream developer / community / creative / gaming platforms only. No dating, adult, messaging,
health or finance services. Platforms that block bots are never queried; manual links are printed instead.
"""

from __future__ import annotations

import json
import logging
import pathlib
import re
import secrets
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote, urlparse

from ..utils.helpers import safe_request, timestamp
from . import page_metadata as pm

logger = logging.getLogger("atlas.sources.username")

USERNAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,38}$")
BODY_CAP = 100_000
MAX_PLATFORMS = 300
DATA_FILE = pathlib.Path(__file__).resolve().parent.parent / "data" / "platforms.json"
EXCLUDED_CATEGORIES = ("dating", "adult", "messaging", "health", "finance")
KINDS = ("status", "message", "json")

SOFT_404 = re.compile(
    r"\b(404|not found|page not found|doesn'?t exist|does not exist|no such (user|page|profile|account)|"
    r"(profile|user|account|page) (is )?(unavailable|not available)|couldn'?t find|could not find|"
    r"can'?t be found|isn'?t available|no longer available)\b", re.IGNORECASE)


@dataclass(frozen=True)
class Platform:
    name: str
    category: str
    url: str                                   # URL requested ("{}" = username)
    kind: str = "status"                       # status | message | json
    profile_url: Optional[str] = None          # human-facing URL if different from `url`
    pattern: Optional[str] = None              # username format accepted by this platform
    absent_text: Optional[str] = None          # kind=message: text shown when the user does not exist
    exists_path: Tuple[Any, ...] = ()          # kind=json: path that exists when the user exists
    absent_path: Tuple[Any, ...] = ()          # kind=json: path that exists when the user is absent
    absent_if_empty: bool = False              # kind=json: an empty list/object means "no such user"
    absent_codes: Tuple[int, ...] = (404, 410)  # HTTP codes that mean "no such user"
    known_good: Optional[str] = None           # an account expected to exist (used by selftest only)


# Platforms that restrict automated access: never queried, links are printed for manual use only.
MANUAL_LINKS: List[Tuple[str, str]] = [
    ("Instagram", "https://www.instagram.com/{}/"),
    ("X (Twitter)", "https://x.com/{}"),
    ("TikTok", "https://www.tiktok.com/@{}"),
    ("Facebook", "https://www.facebook.com/{}"),
    ("LinkedIn", "https://www.linkedin.com/in/{}"),
    ("Reddit", "https://www.reddit.com/user/{}"),
    ("YouTube", "https://www.youtube.com/@{}"),
    ("Threads", "https://www.threads.net/@{}"),
    ("Pinterest", "https://www.pinterest.com/{}/"),
]


# --------------------------------------------------------------------------- loading
def _as_path(v: Any) -> Tuple[Any, ...]:
    return tuple(v) if isinstance(v, (list, tuple)) else ()


def parse_platform(d: Dict[str, Any]) -> Platform:
    """Validate one platform entry. Raises ValueError with a clear message."""
    if not isinstance(d, dict):
        raise ValueError("entry is not an object")
    name, cat, url = d.get("name"), d.get("category"), d.get("url")
    if not all(isinstance(x, str) and x.strip() for x in (name, cat, url)):
        raise ValueError("name, category and url are required text fields")
    if str(cat).lower() in EXCLUDED_CATEGORIES:
        raise ValueError(f"category {cat!r} is not supported by ATLAS (dating/adult/messaging/health/finance are excluded)")
    if not url.startswith("https://") or url.count("{}") != 1:
        raise ValueError("url must start with https:// and contain exactly one {} placeholder")
    host = urlparse(url.replace("{}", "x")).hostname or ""
    if not host or re.fullmatch(r"[\d.:]+", host):
        raise ValueError("url must use a host name, not an IP address")
    kind = d.get("kind", "status")
    if kind not in KINDS:
        raise ValueError(f"kind must be one of {KINDS}")
    if kind == "message" and not d.get("absent_text"):
        raise ValueError("kind 'message' needs absent_text")
    if kind == "json" and not (d.get("exists_path") or d.get("absent_path") or d.get("absent_if_empty")):
        raise ValueError("kind 'json' needs exists_path, absent_path or absent_if_empty")
    pattern = d.get("pattern")
    if pattern:
        re.compile(pattern)
    pu = d.get("profile_url")
    if pu and (not pu.startswith("https://") or pu.count("{}") != 1):
        raise ValueError("profile_url must start with https:// and contain one {}")
    codes = d.get("absent_codes") or [404, 410]
    if not all(isinstance(c, int) and 300 <= c < 600 for c in codes):
        raise ValueError("absent_codes must be HTTP status codes")
    return Platform(name=name.strip(), category=str(cat).lower(), url=url, kind=kind, profile_url=pu or None,
                    pattern=pattern or None, absent_text=d.get("absent_text"),
                    exists_path=_as_path(d.get("exists_path")), absent_path=_as_path(d.get("absent_path")),
                    absent_if_empty=bool(d.get("absent_if_empty")), absent_codes=tuple(codes),
                    known_good=d.get("known_good") or None)


def load_platforms(path: Optional[str] = None) -> Tuple[List[Platform], List[str]]:
    """Load the built-in list or a user file. Returns (platforms, warnings); invalid entries are skipped."""
    warnings: List[str] = []
    src = pathlib.Path(path) if path else DATA_FILE
    try:
        if not src.is_file():
            raise ValueError("file not found")
        if src.stat().st_size > 1_000_000:
            raise ValueError("file is larger than 1 MB")
        data = json.loads(src.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        return [], [f"could not read platform list {src}: {e}"]
    rows = data.get("platforms") if isinstance(data, dict) else data
    if not isinstance(rows, list):
        return [], [f"{src}: expected a list of platforms"]
    out: List[Platform] = []
    seen = set()
    for i, row in enumerate(rows[:MAX_PLATFORMS]):
        try:
            p = parse_platform(row)
        except (ValueError, re.error) as e:
            warnings.append(f"entry {i + 1} ({row.get('name') if isinstance(row, dict) else '?'}) skipped: {e}")
            continue
        if p.name in seen:
            warnings.append(f"duplicate platform {p.name!r} skipped")
            continue
        seen.add(p.name)
        out.append(p)
    if len(rows) > MAX_PLATFORMS:
        warnings.append(f"only the first {MAX_PLATFORMS} platforms were used")
    return out, warnings


PLATFORMS, _BUILTIN_WARNINGS = load_platforms()


# --------------------------------------------------------------------------- helpers
def validate_username(name: str) -> Tuple[bool, str]:
    if not isinstance(name, str) or not name:
        return False, "empty username"
    if not USERNAME_RE.match(name):
        return False, ("usernames may contain letters, digits, '.', '_' and '-' (1-39 characters, "
                       "starting with a letter or digit)")
    return True, ""


def _fill(template: str, username: str) -> str:
    return template.replace("{}", quote(username, safe=""))


def _dig(data: Any, path: Tuple[Any, ...]) -> bool:
    cur = data
    for key in path:
        try:
            cur = cur[key]
        except (KeyError, IndexError, TypeError):
            return False
    return True


def _same_page(requested: str, final: str) -> bool:
    a, b = urlparse(requested), urlparse(final)
    norm = lambda p: (p.path.rstrip("/").lower(), p.query.lower())
    return a.hostname == b.hostname and norm(a) == norm(b)


def control_name(p: Optional[Platform] = None) -> str:
    """A random name that cannot reasonably exist, sized to fit the platform's length limit."""
    maxlen = 18
    if p is not None and p.pattern:
        limits = [int(b) for _a, b in re.findall(r"\{(\d+),(\d+)\}", p.pattern)]
        if limits:
            maxlen = max(8, min(maxlen, limits[-1]))
    name = ("zx" + secrets.token_hex(9))[:maxlen]
    if p is not None and p.pattern and not re.match(p.pattern, name):
        logger.debug("control name does not fit %s's pattern; using it anyway", p.name)
    return name


@dataclass
class Probe:
    state: str                    # exists | absent | inconclusive | skipped_robots | offline | error
    detail: str = ""
    http_status: Optional[int] = None
    username_in_page: Optional[bool] = None


def _signals(resp, username: str) -> Tuple[bool, bool]:
    """(soft_404, username_in_page) computed from the page; text is not kept."""
    ctype = resp.header("Content-Type").lower()
    uname = username.lower()
    if "html" in ctype:
        doc = pm.extract(resp.text, resp.url or "")
        canon = (doc["links"].get("canonical") or [""])[0]
        og_title = pm.meta_first(doc["meta"], "og:title")
        og_url = pm.meta_first(doc["meta"], "og:url")
        h1 = " ".join(doc["h1"])
        soft = bool(SOFT_404.search(f"{doc['title']} {og_title} {h1}"))
        hay = " ".join([doc["title"], og_title, canon, og_url, h1]).lower()
        return soft, uname in hay
    return False, uname in resp.text.lower()


def probe(p: Platform, username: str, retries: int = 1) -> Probe:
    """One check of one username on one platform."""
    url = _fill(p.url, username)
    resp, err = safe_request(url, timeout=10, respect_robots=True, read_body=True, max_bytes=BODY_CAP,
                             retries=retries, headers={"Accept": "text/html,application/json;q=0.9,*/*;q=0.5"})
    if resp is None:
        if err and err.startswith("offline"):
            return Probe("offline", err)
        if err and err.startswith("not fetched"):
            return Probe("skipped_robots", err)
        return Probe("error", err or "request failed")
    code = resp.status_code
    if code in p.absent_codes:
        return Probe("absent", f"HTTP {code}", code)
    if code != 200:
        return Probe("inconclusive", f"HTTP {code} (rate-limited, blocked or error)", code)
    if not _same_page(url, resp.url or url):
        return Probe("inconclusive", "redirected to a different page", code)

    soft404, in_page = _signals(resp, username)
    if soft404:
        return Probe("absent", "page says the profile was not found (soft 404)", code, in_page)
    if p.kind == "status":
        return Probe("exists", "HTTP 200", code, in_page)
    if p.kind == "message":
        if p.absent_text and p.absent_text.lower() in resp.text.lower():
            return Probe("absent", "profile-not-found message shown", code, in_page)
        return Probe("exists", "HTTP 200, no not-found message", code, in_page)
    try:                                                    # kind == "json"
        data = resp.json()
    except ValueError:
        return Probe("inconclusive", "unexpected (non-JSON) response", code)
    if p.absent_if_empty and not data:
        return Probe("absent", "API returned no user", code, False)
    if p.absent_path and _dig(data, p.absent_path):
        return Probe("absent", "API reports the user is missing", code, False)
    if p.exists_path and _dig(data, p.exists_path):
        return Probe("exists", "API returned a user record", code, in_page)
    return Probe("inconclusive", "API response not understood", code)


def check_platform(p: Platform, username: str) -> Dict[str, Any]:
    res: Dict[str, Any] = {
        "platform": p.name, "category": p.category, "status": "error", "detail": "",
        "profile_url": _fill(p.profile_url or p.url, username), "http_status": None,
        "checked_at": timestamp(), "control_check": None, "existence_confidence": None,
        "username_in_page": None,
    }
    if p.pattern and not re.match(p.pattern, username):
        res.update(status="skipped_format", detail="username format not valid on this platform (no request made)")
        return res

    first = probe(p, username)
    res["http_status"], res["detail"], res["username_in_page"] = first.http_status, first.detail, first.username_in_page
    if first.state == "absent":
        res["status"] = "not_found"
    elif first.state in ("skipped_robots", "offline", "error", "inconclusive"):
        res["status"] = first.state
    elif first.state == "exists":
        controls = [probe(p, control_name(p)).state for _ in range(2)]      # two names that cannot exist
        res["controls"] = controls
        if "exists" in controls:
            res.update(status="unreliable", control_check="failed",
                       detail="a random non-existent name also looked 'found' – this platform cannot be checked reliably")
        else:
            res["status"] = "found"
            if controls == ["absent", "absent"]:
                res["control_check"] = "passed"
                res["existence_confidence"] = "HIGH" if first.username_in_page else "MEDIUM"
            else:
                res["control_check"] = "inconclusive"
                res["existence_confidence"] = "LOW"
            if first.username_in_page:
                res["detail"] += "; username appears in the page title/URL"
    return res


# --------------------------------------------------------------------------- selftest
def selftest_platform(p: Platform) -> Dict[str, Any]:
    """Negative control (random name) + positive control (known-good account) for one rule."""
    neg = probe(p, control_name(p))
    pos = probe(p, p.known_good) if p.known_good and (not p.pattern or re.match(p.pattern, p.known_good)) else None
    if neg.state == "exists":
        verdict, note = "unreliable", "answers 'found' for a name that cannot exist – remove or fix this rule"
    elif neg.state == "skipped_robots":
        verdict, note = "blocked_by_robots", "robots.txt disallows (or could not confirm) automated access"
    elif neg.state in ("inconclusive", "error", "offline"):
        verdict, note = "unreachable_or_blocked", neg.detail
    elif pos is None:
        verdict, note = "ok_negative_only", "negative control passes; no known-good account to confirm positives"
    elif pos.state == "exists":
        verdict, note = "healthy", "negative and positive controls both behave as expected"
    elif pos.state == "absent":
        verdict, note = "stale_rule", f"known-good account '{p.known_good}' was reported absent: rule may be outdated"
    else:
        verdict, note = "positive_inconclusive", f"known-good account check was {pos.state}: {pos.detail}"
    return {"platform": p.name, "category": p.category, "verdict": verdict, "note": note,
            "negative": neg.state, "positive": pos.state if pos else None}
