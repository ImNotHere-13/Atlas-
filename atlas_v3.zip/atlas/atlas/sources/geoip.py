"""
Coarse IP geolocation with cross-checking.

Two independent HTTPS providers (ipinfo.io, ipwho.is) are queried and compared; the result reports
whether they AGREE on country / region / city. ip-api.com (cleartext HTTP only) is used only if both
HTTPS providers fail. Always approximate network location, never a person's address.
Data minimisation: latitude/longitude and postcodes are never requested from or stored for ip-api
and are discarded from the others.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from ..utils.helpers import is_offline, is_public_ip, safe_request, timestamp

_ASN_RE = re.compile(r"\bAS(\d{1,10})\b", re.IGNORECASE)


def parse_asn(*texts):
    """Extract 'AS12345' from provider strings such as 'AS15169 Google LLC'."""
    for t in texts:
        if t:
            m = _ASN_RE.search(str(t))
            if m:
                return f"AS{m.group(1)}"
    return None


def _norm(v: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(v or "").lower())


def _ipinfo(ip: str):
    resp, err = safe_request(f"https://ipinfo.io/{ip}/json", timeout=8, retries=1)
    if resp is None or resp.status_code != 200:
        return None, f"ipinfo.io: {err or 'HTTP ' + str(getattr(resp, 'status_code', '?'))}"
    try:
        d = resp.json()
    except ValueError as e:
        return None, f"ipinfo.io parse: {e}"
    if not isinstance(d, dict) or d.get("bogon") or not d.get("country"):
        return None, "ipinfo.io: no usable data"
    return {"country_code": str(d.get("country")).upper(), "country": None, "region": d.get("region"),
            "city": d.get("city"), "timezone": d.get("timezone"), "organisation": d.get("org"),
            "hostname": d.get("hostname"), "as": d.get("org")}, None


def _ipwho(ip: str):
    resp, err = safe_request(f"https://ipwho.is/{ip}", timeout=8, retries=1)
    if resp is None or resp.status_code != 200:
        return None, f"ipwho.is: {err or 'HTTP ' + str(getattr(resp, 'status_code', '?'))}"
    try:
        d = resp.json()
    except ValueError as e:
        return None, f"ipwho.is parse: {e}"
    if not isinstance(d, dict) or d.get("success") is False or not d.get("country_code"):
        return None, f"ipwho.is: {d.get('message', 'no usable data') if isinstance(d, dict) else 'no usable data'}"
    conn = d.get("connection") or {}
    asn = conn.get("asn")
    org = conn.get("org") or conn.get("isp")
    tz = d.get("timezone")
    return {"country_code": str(d.get("country_code")).upper(), "country": d.get("country"),
            "region": d.get("region"), "city": d.get("city"),
            "timezone": tz.get("id") if isinstance(tz, dict) else tz,
            "organisation": f"AS{asn} {org}" if asn and org else org, "isp": conn.get("isp"),
            "as": f"AS{asn} {org}" if asn and org else None, "hostname": None}, None


def _ipapi(ip: str):
    url = (f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,regionName,city,timezone,"
           "isp,org,as,asname,mobile,proxy,hosting")
    resp, err = safe_request(url, timeout=8, retries=1)
    if resp is None or resp.status_code != 200:
        return None, f"ip-api.com: {err or 'HTTP ' + str(getattr(resp, 'status_code', '?'))}"
    try:
        d = resp.json()
    except ValueError as e:
        return None, f"ip-api.com parse: {e}"
    if d.get("status") != "success":
        return None, f"ip-api.com: {d.get('message')}"
    return {"country_code": str(d.get("countryCode") or "").upper() or None, "country": d.get("country"),
            "region": d.get("regionName"), "city": d.get("city"), "timezone": d.get("timezone"),
            "isp": d.get("isp"), "organisation": d.get("org"), "as": d.get("as"), "as_name": d.get("asname"),
            "is_mobile": d.get("mobile"), "is_proxy": d.get("proxy"), "is_hosting": d.get("hosting")}, None


def _agree(a: Any, b: Any) -> Optional[bool]:
    if not a or not b:
        return None
    return _norm(a) == _norm(b)


def lookup_ip_geo(ip: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "queried_at": timestamp(), "ip": ip, "success": False, "source": None, "sources_used": [],
        "data": {}, "errors": [], "cross_check": {},
        "disclaimer": (
            "IP geolocation identifies an approximate NETWORK location (usually the provider's infrastructure), "
            "not necessarily where the person using the address is. It can be wrong at country level and is "
            "frequently wrong at city level. It does not identify a specific person or exact address. "
            "Coordinates and postcodes are intentionally not collected."),
    }
    if is_offline():
        result["errors"].append("offline mode: geolocation skipped.")
        return result
    if not is_public_ip(ip):
        result["errors"].append("Not a public IP address; geolocation skipped.")
        return result

    answers: List[Dict[str, Any]] = []
    for name, fn in (("ipinfo.io", _ipinfo), ("ipwho.is", _ipwho)):
        data, err = fn(ip)
        if data:
            data["_source"] = name
            answers.append(data)
        else:
            result["errors"].append(err)
    if not answers:                                    # cleartext fallback only when both HTTPS providers failed
        data, err = _ipapi(ip)
        if data:
            data["_source"] = "ip-api.com (cleartext HTTP)"
            answers.append(data)
        else:
            result["errors"].append(err)
    if not answers:
        return result

    merged: Dict[str, Any] = {}
    for a in answers:                                  # first provider wins; later ones only fill gaps
        for k, v in a.items():
            if k != "_source" and v not in (None, "") and k not in merged:
                merged[k] = v
    if not merged.get("country"):
        merged["country"] = merged.get("country_code")
    result.update(success=True, data=merged, sources_used=[a["_source"] for a in answers],
                  source=" + ".join(a["_source"] for a in answers))
    if len(answers) >= 2:
        a, b = answers[0], answers[1]
        result["cross_check"] = {
            "providers": [a["_source"], b["_source"]],
            "country_agreement": _agree(a.get("country_code"), b.get("country_code")),
            "region_agreement": _agree(a.get("region"), b.get("region")),
            "city_agreement": _agree(a.get("city"), b.get("city")),
        }
    else:
        result["cross_check"] = {"providers": [answers[0]["_source"]], "country_agreement": None,
                                 "region_agreement": None, "city_agreement": None,
                                 "note": "Only one provider answered; the result could not be cross-checked."}
    return result
