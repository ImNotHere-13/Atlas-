"""
Input classification for ATLAS.
Determines whether the target is an IP, domain, URL, organisation, or person.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import Optional
from urllib.parse import urlparse

from .sources.username_sources import USERNAME_RE, validate_username
from .utils.helpers import (
    clean_target,
    is_valid_domain,
    is_valid_ipv4,
    is_valid_ipv6,
    is_valid_url,
)


class TargetType(Enum):
    IP = auto()
    DOMAIN = auto()
    URL = auto()
    ORGANISATION = auto()
    PERSON = auto()
    USERNAME = auto()
    UNKNOWN = auto()


@dataclass
class ClassificationResult:
    original: str
    target_type: TargetType
    normalised: str
    confidence: float
    notes: str = ""


# Matched as whole words (so "Lincoln" no longer matches "inc").
ORG_INDICATORS = frozenset({
    "inc", "ltd", "llc", "llp", "plc", "gmbh", "corp", "corporation", "co",
    "company", "group", "holdings", "technologies", "systems", "solutions",
    "services", "foundation", "university", "college", "institute", "agency",
    "ministry", "bank", "council", "association", "society", "partners",
    "united", "kingdom", "states", "republic", "department", "authority",
})

# Words that may appear lowercase inside a proper name / org name.
_CONNECTORS = frozenset({"of", "the", "and", "for", "de", "van", "von", "la", "le", "al", "bin", "&"})


def parse_forced_type(value: Optional[str]) -> Optional[TargetType]:
    """Map a user-supplied type name (e.g. from --type) to a TargetType."""
    if not value:
        return None
    mapping = {
        "ip": TargetType.IP, "domain": TargetType.DOMAIN, "url": TargetType.URL,
        "org": TargetType.ORGANISATION, "organisation": TargetType.ORGANISATION,
        "organization": TargetType.ORGANISATION, "person": TargetType.PERSON,
        "username": TargetType.USERNAME, "user": TargetType.USERNAME, "handle": TargetType.USERNAME,
    }
    try:
        return mapping[value.strip().lower()]
    except KeyError:
        raise ValueError(f"Unknown target type {value!r}; choose from: {', '.join(sorted(mapping))}")


def _redact_url(url: str) -> str:
    """Drop any user:password@ section so credentials never reach a report."""
    parsed = urlparse(url)
    if parsed.username or parsed.password:
        return url.replace(parsed.netloc, parsed.netloc.rsplit("@", 1)[-1], 1)
    return url


def classify(user_input: str, force: Optional[TargetType] = None) -> ClassificationResult:
    """
    Automatically classify the user input (or honour an explicit override).
    Returns a ClassificationResult with type and normalised form.
    """
    raw = clean_target(user_input)
    if not raw:
        return ClassificationResult(raw, TargetType.UNKNOWN, "", 0.0, "Empty input")

    if force is not None:
        return _forced(raw, force)

    # 1. URL – use .hostname so credentials, ports and IPv6 brackets are handled.
    if is_valid_url(raw):
        host = (urlparse(raw).hostname or "").lower()
        if is_valid_ipv4(host) or is_valid_ipv6(host):
            return ClassificationResult(
                _redact_url(raw), TargetType.IP, host, 0.95,
                "URL whose host is an IP address; investigating the IP",
            )
        return ClassificationResult(
            _redact_url(raw), TargetType.URL, host, 0.95,
            "Treated as URL; investigation focuses on host/domain",
        )

    # 1b. Explicit handle: @name
    if raw.startswith("@") and validate_username(raw[1:])[0]:
        return ClassificationResult(raw, TargetType.USERNAME, raw[1:], 0.9, "Handle (leading @) – username presence check")

    # 2. IPv4 / IPv6
    if is_valid_ipv4(raw):
        return ClassificationResult(raw, TargetType.IP, raw, 0.99, "IPv4 address")
    if is_valid_ipv6(raw):
        return ClassificationResult(raw, TargetType.IP, raw.strip("[]"), 0.99, "IPv6 address")

    # 3. Domain (strip scheme-less prefixes / paths)
    candidate = raw.lower()
    for prefix in ("www.",):
        if candidate.startswith(prefix):
            candidate = candidate[len(prefix):]
    candidate = candidate.split("/")[0].split("?")[0].rstrip(".")
    if is_valid_domain(candidate):
        return ClassificationResult(
            raw, TargetType.DOMAIN, candidate, 0.90, "Looks like a domain name"
        )

    # 3b. Single token that looks like a platform handle (has a digit or underscore): john_smith99
    if " " not in raw and USERNAME_RE.match(raw) and re.search(r"[0-9_]", raw):
        return ClassificationResult(
            raw, TargetType.USERNAME, raw, 0.6,
            "Single token with digits/underscore – treated as a username (low confidence). Use --type org|person to override.")

    # 4. Person vs organisation heuristic (intentionally conservative)
    words = re.findall(r"[^\W_]+(?:['’.-][^\W_]+)*|&", raw, re.UNICODE)
    lowered = {w.lower() for w in words}
    significant = [w for w in words if w.lower() not in _CONNECTORS]
    all_capitalised = bool(significant) and all(w[0].isupper() or w.isupper() for w in significant)

    if len(significant) >= 2 and all_capitalised:
        if lowered & ORG_INDICATORS:
            return ClassificationResult(
                raw, TargetType.ORGANISATION, raw, 0.70, "Contains organisation indicators"
            )
        return ClassificationResult(
            raw, TargetType.PERSON, raw, 0.55,
            "Multi-word capitalised name – treated as public figure / person (low confidence). "
            "Use --type org to override.",
        )

    return ClassificationResult(
        raw, TargetType.ORGANISATION, raw, 0.50,
        "Treated as organisation / entity name (heuristic). Use --type to override.",
    )


def _forced(raw: str, force: TargetType) -> ClassificationResult:
    """Normalise the input for an explicitly requested type."""
    note = "Type set explicitly by user"
    if force in (TargetType.DOMAIN, TargetType.URL):
        host = raw
        if is_valid_url(raw):
            host = urlparse(raw).hostname or raw
        host = host.lower().split("/")[0].split("?")[0].rstrip(".")
        if host.startswith("www."):
            host = host[4:]
        return ClassificationResult(raw, force, host, 1.0, note)
    if force == TargetType.USERNAME:
        name = raw.lstrip("@")
        ok, why = validate_username(name)
        if not ok:
            return ClassificationResult(raw, TargetType.UNKNOWN, raw, 0.0, f"Invalid username: {why}")
        return ClassificationResult(raw, force, name, 1.0, note)
    if force == TargetType.IP:
        host = urlparse(raw).hostname if is_valid_url(raw) else raw.strip("[]")
        if not (is_valid_ipv4(host or "") or is_valid_ipv6(host or "")):
            return ClassificationResult(raw, TargetType.UNKNOWN, raw, 0.0, f"{raw!r} is not a valid IP address")
        return ClassificationResult(raw, force, host, 1.0, note)
    return ClassificationResult(raw, force, raw, 1.0, note)
