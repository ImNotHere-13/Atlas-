"""
Public figure / person investigation module.

Strictly limited to publicly published PROFESSIONAL information. It does not build
dossiers on private individuals, never looks for addresses/phones/private accounts,
never reads a Person's address/home/birthplace fields or social-profile (sameAs) links,
and refuses to merge information when the identity is ambiguous.

Sources: (1) Wikipedia (public MediaWiki endpoint, for notable people) and
(2) official/public pages the *user supplies* with --source. ATLAS has no search-engine
access, so published interviews cannot be discovered automatically; search links are given.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional
from urllib.parse import quote_plus, urlparse

from ..sources import page_metadata as pm
from ..sources import wikidata, wikimedia
from ..sources.web_pages import fetch_page
from ..utils.helpers import confidence_label, is_offline, make_progress, timestamp
from ..utils.source_reliability import rate_domain

logger = logging.getLogger("atlas.modules.person")

MAX_SOURCES = 5

STRICT_BOUNDARY = (
    "ATLAS only assists with publicly available information relevant to a person's professional "
    "or public identity. It will not search for or report private addresses, personal phone numbers, "
    "private email accounts, passwords, family details, or non-public social media, and it does not "
    "build dossiers on private individuals."
)


def _names(value: Any, limit: int = 6) -> List[str]:
    items = value if isinstance(value, list) else [value]
    out = []
    for it in items[:limit]:
        t = pm.text_of(it, 150)
        if t and t not in out:
            out.append(t)
    return out


def _analyse_source(url: str, name: str) -> Dict[str, Any]:
    """Fetch one user-supplied page and extract professional facts about *name*."""
    info = fetch_page(url)
    host = (urlparse(info.get("final_url") or url).hostname or "")
    rating, why = rate_domain(host)
    rec: Dict[str, Any] = {
        "url": info.get("final_url") or url, "host": host, "reliability": rating,
        "reliability_note": why, "accessed_at": info.get("accessed_at"),
        "fetched": bool(info.get("ok")), "name_match": "none", "title": info.get("page_title"),
        "errors": info.get("errors", []),
    }
    if not info.get("ok"):
        return rec

    persons = [n for n in info.get("jsonld", []) if "person" in {t.lower() for t in pm.node_types(n)}]
    exact = [n for n in persons if pm.tokens(pm.text_of(n.get("name"))) == pm.tokens(name)]
    other = [n for n in persons if n not in exact]
    doc = info.get("doc", {})
    in_text = pm.name_in_text(name, " ".join([doc.get("title", ""), *doc.get("h1", [])]))

    if exact:
        node = exact[0]
        rec["name_match"] = "structured_exact"
        rec["job_title"] = pm.text_of(node.get("jobTitle"), 150) or None
        rec["employer"] = _names(node.get("worksFor"))
        rec["affiliations"] = _names(node.get("affiliation"))
        rec["education"] = _names(node.get("alumniOf"))
        rec["awards"] = _names(node.get("award"))
        rec["description"] = pm.text_of(node.get("description"), 400) or None
    elif in_text:
        rec["name_match"] = "page_text"
        rec["description"] = pm.meta_first(doc.get("meta", {}), "og:description", "twitter:description")[:400] or None
    elif other:
        rec["name_match"] = "different_person"
        rec["note"] = "The page's structured data describes a different person; it was ignored."
    else:
        rec["note"] = "The page does not demonstrably mention this person; it was ignored."
    return rec


def investigate_person(name: str, progress_callback=None, sources: Optional[List[str]] = None,
                       use_wikipedia: bool = True) -> Dict[str, Any]:
    progress = make_progress(progress_callback, logger)
    sources = list(sources or [])[:MAX_SOURCES]

    report: Dict[str, Any] = {
        "target": name, "target_type": "PERSON",
        "started_at": timestamp(), "completed_at": None,
        "sections": {}, "confidence_summary": {}, "sources_used": [],
        "limitations": [], "legal_notes": [], "search_hints": [], "key_findings": [],
        "strict_boundary": STRICT_BOUNDARY,
    }
    professional: Dict[str, Any] = {
        "identity": {"status": "not_determined", "explanation": ""},
        "biography": None, "wikipedia": None, "sources": [], "employment": [],
        "affiliations": [], "education": [], "achievements": [],
        "published_interviews": {
            "automated": False,
            "note": "ATLAS has no search-engine access, so published interviews are not discovered "
                    "automatically. Use the search links below and verify each result manually."},
    }
    report["professional"] = professional

    encoded = quote_plus(name)
    report["search_hints"] = [
        {"description": "Professional / public web presence", "url": f"https://duckduckgo.com/?q={encoded}"},
        {"description": "News coverage and published interviews", "url": f"https://news.google.com/search?q={encoded}+interview"},
        {"description": "Academic / publication search (if applicable)", "url": f"https://scholar.google.com/scholar?q={encoded}"},
        {"description": "Official biography heuristic", "url": f"https://duckduckgo.com/?q={encoded}+official+biography"},
    ]
    report["sections"]["scope"] = {
        "permitted": ["Public professional profiles and biographies", "Published interviews and articles",
                      "Public professional achievements and roles",
                      "Official organisational pages that mention the person",
                      "Officially published professional (not residential) locations"],
        "not_permitted_by_atlas": ["Private residential addresses", "Personal telephone numbers",
                                   "Private email addresses or credentials", "Non-public or personal social media",
                                   "Family information", "Live location tracking", "Inferring location from photos",
                                   "Any attempt to bypass access controls"],
    }

    # ---------------------------------------------------------------- Wikipedia
    ambiguous = False
    if use_wikipedia and not is_offline():
        progress("Checking Wikipedia (public MediaWiki endpoint) for a matching article...")
        wiki = wikimedia.lookup_person(name, with_licence=False)
        professional["wikipedia"] = wiki
        if wiki.get("ambiguous"):
            ambiguous = True
        elif wiki.get("found") and wiki.get("name_match"):
            report["sources_used"].append(wiki.get("page_url") or "Wikipedia")
            professional["biography"] = {
                "text": wiki.get("extract"), "description": wiki.get("description"),
                "source": wiki.get("page_url"), "date_accessed": wiki.get("queried_at"),
                "reliability": "MEDIUM", "licence": "Text from Wikipedia, CC BY-SA 4.0 – attribute and share alike.",
            }
        elif wiki.get("found"):
            report["limitations"].append(
                f"Wikipedia redirected to a differently named article ('{wiki.get('title')}'); it was not used.")
    elif is_offline():
        report["limitations"].append("Offline mode: Wikipedia and source pages were not fetched.")

    # ---------------------------------------------------------------- Wikidata (disambiguation + official site)
    wd_candidates: List[Dict[str, Any]] = []
    wd_selected: Optional[Dict[str, Any]] = None
    if use_wikipedia and not is_offline():
        progress("Checking Wikidata for people with this name (disambiguation, official website)...")
        wd = wikidata.lookup(name, "person")
        wd_candidates = [c for c in wd["candidates"] if c["exact_label"] and c["is_human"]]
        professional["wikidata"] = {
            "found": wd["found"], "ambiguous": wd["ambiguous"], "errors": wd["errors"], "source": wd["source"],
            "queried_at": wd["queried_at"],
            "candidates": [{k: c[k] for k in ("qid", "label", "description", "occupations", "employers", "url")}
                           for c in wd_candidates]}
        if wd["ambiguous"]:
            ambiguous = True
        elif wd.get("selected"):
            wd_selected = wd["selected"]
            report["sources_used"].append(wd_selected["url"])
            professional["wikidata_profile"] = {
                "qid": wd_selected["qid"], "description": wd_selected["description"],
                "occupations": wd_selected["occupations"], "employers": wd_selected["employers"],
                "official_website": wd_selected["official_website"], "url": wd_selected["url"],
                "reliability": "MEDIUM", "note": "Community-edited; one matching person found for this exact name."}
            site = wd_selected.get("official_website")
            if site and site not in sources and len(sources) < MAX_SOURCES:
                sources.append(site)                       # fetched below like a user-supplied page

    # ---------------------------------------------------------------- user-supplied sources
    for url in sources:
        progress(f"Reading official/public source: {url}")
        rec = _analyse_source(url, name)
        professional["sources"].append(rec)
        if rec["fetched"]:
            report["sources_used"].append(rec["url"])

    matched = [r for r in professional["sources"] if r["name_match"] in ("structured_exact", "page_text")]

    # employment / affiliations / education / achievements with provenance
    def collect(field: str, dest: str, label: str) -> None:
        for r in matched:
            vals = r.get(field) or []
            vals = [vals] if isinstance(vals, str) else vals
            for v in vals:
                professional[dest].append({label: v, "source": r["url"], "source_reliability": r["reliability"],
                                           "date_accessed": r["accessed_at"]})

    for r in matched:
        if r.get("job_title") or r.get("employer"):
            professional["employment"].append({
                "job_title": r.get("job_title"), "employer": r.get("employer"), "source": r["url"],
                "source_reliability": r["reliability"], "date_accessed": r["accessed_at"]})
    wdp = professional.get("wikidata_profile")
    if wdp and (wdp["occupations"] or wdp["employers"]):
        professional["employment"].append({
            "job_title": ", ".join(wdp["occupations"]) or None, "employer": wdp["employers"],
            "source": wdp["url"], "source_reliability": "MEDIUM", "date_accessed": professional["wikidata"]["queried_at"]})
    collect("affiliations", "affiliations", "organisation")
    collect("education", "education", "institution")
    collect("awards", "achievements", "achievement")

    # ---------------------------------------------------------------- identity assessment
    employers = {e.lower() for r in matched if r["name_match"] == "structured_exact" for e in (r.get("employer") or [])}
    if ambiguous:
        listing = "; ".join(f"{c['label']} – {c['description'] or 'no description'} ({c['url']})" for c in wd_candidates[:5])
        professional["identity"] = {
            "status": "ambiguous",
            "explanation": "Several people share this name (Wikipedia/Wikidata list more than one). ATLAS cannot "
                           "confidently match one person and has not combined information about different people. "
                           + (f"Candidates: {listing}. " if listing else "")
                           + "Supply an official page for the right person with --source <URL> to continue."}
        report["key_findings"].append({"finding": "Name is ambiguous – candidates: " + (listing or "see Wikipedia disambiguation page"),
                                       "source": "Wikidata / Wikipedia", "confidence": "MEDIUM"})
    elif len(employers) > 1:
        professional["identity"] = {
            "status": "possible_multiple_people",
            "explanation": "Sources name different employers for this name; they may be different people. "
                           "Findings are listed per source and have NOT been merged."}
    elif matched or professional["biography"] or professional.get("wikidata_profile"):
        n_ind = len({r["host"] for r in matched}) + (1 if (professional["biography"] or professional.get("wikidata_profile")) else 0)
        professional["identity"] = {
            "status": "name_match_only",
            "explanation": (f"{n_ind} independent source(s) match the name. ATLAS cannot verify that they all refer to "
                            "the same individual, so identity confidence is capped below HIGH.")}
    else:
        professional["identity"] = {
            "status": "no_information_located",
            "explanation": "No public professional information could be matched automatically. ATLAS does not build "
                           "dossiers on private individuals; supply an official page with --source <URL> if the "
                           "person is a public figure."}

    # ---------------------------------------------------------------- confidence
    score = 0.10
    st = professional["identity"]["status"]
    if st == "name_match_only":
        score = 0.35
        if professional["biography"] or professional.get("wikidata_profile"):
            score += 0.15
        official = [r for r in matched if r["reliability"] == "HIGH" and r["name_match"] == "structured_exact"]
        if official:
            score += 0.20
        if len({r["host"] for r in matched}) >= 2:
            score += 0.10
        score = min(score, 0.80)                       # never HIGH automatically
    elif st in ("ambiguous", "possible_multiple_people"):
        score = 0.15
    report["confidence_summary"]["overall"] = {
        "level": confidence_label(score), "score": round(score, 2),
        "note": professional["identity"]["explanation"]}

    # ---------------------------------------------------------------- key findings
    kf = report["key_findings"]
    if wdp:
        kf.append({"finding": f"Wikidata: {wdp['description'] or 'matching person found'}"
                              + (f"; official website recorded: {wdp['official_website']}" if wdp["official_website"] else ""),
                   "source": wdp["url"], "confidence": "MEDIUM"})
    kf.append({"finding": f"Identity assessment: {st.replace('_', ' ')}.", "source": "ATLAS analysis",
               "confidence": confidence_label(score)})
    if professional["biography"] and st != "ambiguous":
        kf.append({"finding": f"Biography summary available: {professional['biography'].get('description') or 'see report'}.",
                   "source": professional["biography"]["source"], "confidence": "MEDIUM"})
    for e in professional["employment"]:
        text = " at ".join(x for x in (e.get("job_title"), ", ".join(e.get("employer") or [])) if x)
        if text:
            kf.append({"finding": f"Published role: {text}.", "source": e["source"],
                       "confidence": "MEDIUM" if e["source_reliability"] != "HIGH" else "HIGH"})
    report["limitations"] += [
        "Automated person research is deliberately limited; results are leads to verify, not a dossier.",
        "Identity matching is by name only unless an official page links the facts together.",
        "Published interviews cannot be discovered automatically (no search-engine access).",
        "Public figures still have privacy rights; purpose and proportionality matter.",
    ]
    report["legal_notes"] = [
        "Under UK GDPR and the Data Protection Act 2018, information relating to an identifiable living individual is personal data.",
        "Even public information may be personal data and need a lawful basis, a stated purpose and proportionate handling.",
        "Special category data (health, politics, religion, etc.) has additional protections and is not sought by ATLAS.",
        "Using publicly available information does not by itself make an investigation lawful; legality depends on purpose, "
        "the information, how it is processed and the circumstances.",
        "The Computer Misuse Act 1990 prohibits unauthorised access to computer material; ATLAS only requests public pages.",
        "This is not formal legal advice.",
    ]
    report["completed_at"] = timestamp()
    return report
