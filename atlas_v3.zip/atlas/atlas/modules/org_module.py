"""
Organisation / company investigation module.
Focuses on public, official information only.
"""

from __future__ import annotations

import logging
import re
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote_plus, urlparse

from ..sources import page_metadata as pm
from ..sources import wikidata
from ..sources.cert_transparency import search_crtsh_org
from ..sources.web_presence import basic_web_info
from ..utils.helpers import confidence_label, is_offline, is_valid_domain, make_progress, timestamp

logger = logging.getLogger("atlas.modules.org")


LEGAL_SUFFIXES = frozenset({"inc", "ltd", "limited", "llc", "llp", "plc", "gmbh", "corp", "corporation", "co",
                            "company", "group", "holdings", "sa", "ag", "bv", "nv", "pty", "lp"})
CONNECTORS = frozenset({"of", "the", "and", "for", "&"})
CANDIDATE_TLDS = (".com", ".co.uk", ".org", ".net")
MAX_CANDIDATES = 8


def name_tokens(name: str) -> Tuple[List[str], List[str]]:
    """(core tokens incl. connectors, significant tokens without connectors) with legal suffixes removed."""
    toks = [t for t in re.findall(r"[a-z0-9]+", name.lower()) if t not in LEGAL_SUFFIXES]
    return toks, [t for t in toks if t not in CONNECTORS]


def candidate_domains(name: str) -> List[str]:
    """Plausible official domains for an organisation name (verified later, never trusted)."""
    core, sig = name_tokens(name)
    if not core:
        return []
    stems = []
    for stem in ("".join(core), "-".join(core), "".join(sig)):
        if stem and stem not in stems:
            stems.append(stem)
    out: List[str] = []
    for stem in stems[:2]:
        for tld in CANDIDATE_TLDS:
            d = stem + tld
            if is_valid_domain(d) and d not in out:
                out.append(d)
    return out[:MAX_CANDIDATES]


GENERIC_WORDS = frozenset({"welcome", "to", "home", "homepage", "official", "site", "website", "page", "online",
                           "web", "the", "and", "a", "an"})


def _segment_tokens(text: str) -> List[str]:
    return [t for t in re.findall(r"[a-z0-9]+", text.lower())
            if t not in LEGAL_SUFFIXES and t not in CONNECTORS and t not in GENERIC_WORDS]


def verify_site_name(name: str, web: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Does the responding site identify itself as this organisation?
    Looks ONLY at the site's own title / site name / main heading, one segment at a time
    (segments are separated by | – — : or ' - '). A single distinctive word must make up the WHOLE
    segment ("Example Corp – Home" matches "Example Corp"; "Example Widgets" does not); names with
    two or more distinctive words may appear as a contiguous phrase.
    """
    core, sig = name_tokens(name)
    all_tokens = re.findall(r"[a-z0-9]+", name.lower())
    if not sig:
        return False, "no distinctive words in the name to verify"
    collapsed_forms = {"".join(sig), "".join(core), "".join(all_tokens)}
    for label, value in (("page title", web.get("title")), ("site name", web.get("site_name")),
                         ("main heading", web.get("h1"))):
        if not value:
            continue
        for seg in re.split(r"\s*[|–—:·•]\s*|\s+-\s+", value):
            toks = _segment_tokens(seg)
            hit = toks == sig or "".join(toks) in collapsed_forms
            if not hit and len(sig) >= 2:
                hit = any(toks[i:i + len(sig)] == sig for i in range(len(toks) - len(sig) + 1))
            if hit:
                return True, f"{label} contains the organisation's name"
    return False, "the site's title/name does not contain the organisation's name"


def investigate_organisation(name: str, progress_callback=None) -> Dict[str, Any]:
    progress = make_progress(progress_callback, logger)

    report = {
        "target": name,
        "target_type": "ORGANISATION",
        "started_at": timestamp(),
        "completed_at": None,
        "sections": {},
        "confidence_summary": {},
        "sources_used": [],
        "limitations": [],
        "legal_notes": [],
        "search_hints": [], "key_findings": [],
    }

    progress("Performing passive public discovery for organisation...")

    # 1. Try to find an official website via simple heuristics + DuckDuckGo HTML (lightweight)
    # We avoid heavy scraping. Provide clear search URLs for the analyst.
    encoded = quote_plus(name)
    report["search_hints"] = [
        {
            "description": "General web search",
            "url": f"https://duckduckgo.com/?q={encoded}",
        },
        {
            "description": "Official site heuristic search",
            "url": f"https://duckduckgo.com/?q={encoded}+official+website",
        },
        {
            "description": "UK Companies House (if UK entity)",
            "url": f"https://find-and-update.company-information.service.gov.uk/search?q={encoded}",
        },
        {
            "description": "OpenCorporates (multi-jurisdiction)",
            "url": f"https://opencorporates.com/companies?q={encoded}",
        },
        {
            "description": "News coverage",
            "url": f"https://news.google.com/search?q={encoded}",
        },
    ]

    # 1b. Wikidata: community-recorded official website (a far better lead than guessing)
    wd_site: Optional[Dict[str, Any]] = None
    if not is_offline():
        progress("Looking the organisation up in Wikidata (official website, disambiguation)...")
        wd = wikidata.lookup(name, "org")
        report["sections"]["wikidata"] = {k: wd.get(k) for k in ("found", "ambiguous", "errors", "source", "queried_at")}
        report["sections"]["wikidata"]["candidates"] = [
            {k: c[k] for k in ("qid", "label", "description", "official_website", "url")} for c in wd["candidates"]]
        if wd.get("ambiguous"):
            report["limitations"].append(
                "Several organisations share this name in Wikidata; ATLAS did not pick one. See the candidates in "
                "sections.wikidata and confirm the right one with --source <official URL>.")
        elif wd.get("selected") and wd["selected"].get("official_website"):
            sel = wd["selected"]
            wd_site = {"domain": (urlparse(sel["official_website"]).hostname or "").removeprefix("www."),
                       "url": sel["official_website"], "qid": sel["qid"], "description": sel["description"]}
            report["sources_used"].append(sel["url"])

    # 2. Test plausible official domains and VERIFY each against the site's own name
    progress("Testing plausible official domains and verifying them against the organisation's name...")
    cleaned = [] if wd_site else candidate_domains(name)
    if wd_site:
        cleaned = [wd_site["domain"]]

    def probe(domain: str) -> Dict[str, Any]:
        target = wd_site["url"] if (wd_site and domain == wd_site["domain"]) else domain   # exact recorded URL
        return {"domain": domain, "web": basic_web_info(target)}

    found_sites: List[Dict[str, Any]] = []
    seen_hosts = set()
    if cleaned:
        with ThreadPoolExecutor(max_workers=4, thread_name_prefix="atlas-org") as pool:
            probes = list(pool.map(probe, cleaned))
        for pr in probes:
            web = pr["web"]
            if not (web.get("success") and web.get("status_code") and web["status_code"] < 400):
                continue
            final = web.get("final_url") or pr["domain"]
            host = (urlparse(final).hostname or pr["domain"]).lower()
            host = host[4:] if host.startswith("www.") else host
            if host in seen_hosts:                       # several candidates redirecting to one site
                continue
            seen_hosts.add(host)
            matched, basis = verify_site_name(name, web)
            from_wd = bool(wd_site and pr["domain"] == wd_site["domain"])
            found_sites.append({
                "origin": "Wikidata official website (P856)" if from_wd else "guessed from the name",
                "domain": pr["domain"], "title": web.get("title"), "site_name": web.get("site_name"),
                "final_url": final, "server": web.get("server"), "name_match": matched, "match_basis": basis,
            })
            report["sources_used"].append(final)
        found_sites.sort(key=lambda x: not x["name_match"])      # verified-by-name first

    matched_sites = [x for x in found_sites if x["name_match"]]
    report["sections"]["possible_official_sites"] = {
        "candidates_tested": cleaned,
        "responsive_sites": found_sites,
        "name_verified_sites": [x["domain"] for x in matched_sites],
        "note": ("Candidates are guesses from the name. 'name_match' means the site's own title/name contains the "
                 "organisation's name; that makes it a stronger lead but is NOT confirmation that it is the official site."),
    }

    wd_verified = [x for x in matched_sites if str(x.get("origin", "")).startswith("Wikidata")]
    if wd_verified:
        report["confidence_summary"]["web_presence"] = {
            "level": confidence_label(0.7), "score": 0.7,
            "note": "Wikidata records this as the organisation's official website AND the site's own name matches"}
    elif matched_sites:
        report["confidence_summary"]["web_presence"] = {
            "level": confidence_label(0.4), "score": 0.4,
            "note": "A guessed site's own title/name matches the organisation – still unconfirmed; verify manually"}
    elif found_sites:
        report["confidence_summary"]["web_presence"] = {
            "level": confidence_label(0.2), "score": 0.2,
            "note": "Candidate domains responded but none identifies itself as this organisation – likely unrelated sites"}
    else:
        report["confidence_summary"]["web_presence"] = {
            "level": confidence_label(0.15), "score": 0.15,
            "note": "No candidate domains responded; use the search hints below"}

    # 2b. Domains seen on certificates issued to this organisation name (leads only)
    if not is_offline():
        progress("Searching certificate-transparency logs for domains certified to this organisation name...")
        org_ct = search_crtsh_org(name)
        report["sections"]["certificate_organisation_domains"] = org_ct
        if org_ct.get("success") and org_ct.get("domains"):
            report["sources_used"].append("crt.sh (O= search)")
            report["key_findings"].append({
                "finding": "Domains on certificates issued to this organisation name (unverified leads): " +
                           ", ".join(d["domain"] for d in org_ct["domains"][:8]),
                "source": "crt.sh", "confidence": "LOW"})

    # 3. Placeholder for registry data – we point the user to official sources
    report["sections"]["business_registries"] = {
        "note": (
            "ATLAS does not scrape government registries automatically in order to "
            "respect terms of service and rate limits. Use the official search links provided."
        ),
        "recommended": [
            "UK: Companies House – https://find-and-update.company-information.service.gov.uk/",
            "US: SEC EDGAR, state business search portals",
            "Multi-jurisdiction: OpenCorporates, GLEIF (for LEIs)",
        ],
    }

    report["sections"]["social_and_news"] = {
        "note": "Search the provided news and general web links. Official social accounts are best confirmed from the organisation's own website.",
        "caution": "Do not treat unofficial social profiles as verified without cross-checking.",
    }

    report["limitations"].extend([
        "Organisation investigations are inherently less automated than IP/domain lookups.",
        "Many official registries require interactive use or have strict ToS against bulk scraping.",
        "Always verify any candidate website or registration data manually.",
    ])

    report["legal_notes"] = [
        "Collecting publicly available information about companies is generally permitted.",
        "Do not attempt to access non-public internal systems or employee personal data.",
        "If the organisation is a sole trader or the data includes living individuals, UK GDPR / DPA 2018 may apply.",
        "Respect robots.txt and website terms when performing any further manual research.",
    ]

    for site in found_sites:
        if site["name_match"] and str(site.get("origin", "")).startswith("Wikidata"):
            text = (f"Official website (per Wikidata, name verified on the site): {site['domain']} – {site['match_basis']}")
            conf = "MEDIUM"
        elif site["name_match"]:
            text = (f"Likely official website: {site['domain']} – {site['match_basis']} "
                    "(guessed from the name; NOT confirmed as official)")
            conf = "LOW"
        else:
            text = (f"Domain {site['domain']} responded but {site['match_basis']}; probably unrelated "
                    "(excluded from image and location lookups)")
            conf = "LOW"
        report["key_findings"].append({"finding": text, "source": site.get("final_url") or site["domain"],
                                       "confidence": conf})
    if not found_sites:
        report["key_findings"].append({"finding": "No official website could be identified automatically.",
                                       "source": "ATLAS heuristic", "confidence": "LOW"})
    report["completed_at"] = timestamp()
    return report