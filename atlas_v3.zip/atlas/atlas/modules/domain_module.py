"""
Domain / website investigation module.
Independent lookups run concurrently; per-host rate limiting still applies.
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict

from ..sources.cert_transparency import search_crtsh
from ..sources.dns_lookup import get_dns_records
from ..sources.geoip import lookup_ip_geo
from ..sources.provider_hints import infer_providers
from ..sources.rdap import query_rdap_domain
from ..sources.wayback import query_wayback
from ..sources.web_presence import basic_web_info
from ..utils.helpers import (
    confidence_label, is_offline, is_public_ip, make_progress, resolve_hostname, timestamp,
)

logger = logging.getLogger("atlas.modules.domain")

LEGAL_NOTES = [
    "Domain RDAP, DNS, and Certificate Transparency data are public by design.",
    "Observing a public website's headers and title is generally permitted passive research.",
    "Do not attempt to bypass authentication, scrape behind logins, or test for vulnerabilities without authorisation.",
    "UK Computer Misuse Act 1990 prohibits unauthorised access. This tool only requests publicly reachable resources.",
    "If the domain relates to an individual (e.g. personal site), treat any personal data under UK GDPR / DPA 2018 principles.",
]


def _conf(score: float, note: str) -> Dict[str, Any]:
    return {"level": confidence_label(score), "score": score, "note": note}


def _resolve_and_geo(domain: str) -> Dict[str, Any]:
    ips = resolve_hostname(domain)
    out: Dict[str, Any] = {"ips": ips, "geo": None}
    public = [ip for ip in ips if is_public_ip(ip)]
    if public:
        out["geo"] = lookup_ip_geo(public[0])
        out["geo_ip"] = public[0]
    return out


def investigate_domain(domain: str, progress_callback=None) -> Dict[str, Any]:
    progress = make_progress(progress_callback, logger)

    report: Dict[str, Any] = {
        "target": domain, "target_type": "DOMAIN",
        "started_at": timestamp(), "completed_at": None,
        "sections": {}, "confidence_summary": {}, "sources_used": [],
        "limitations": [], "legal_notes": list(LEGAL_NOTES), "key_findings": [],
    }

    progress("Running RDAP, DNS, resolution, Certificate Transparency and HTTP checks in parallel...")
    with ThreadPoolExecutor(max_workers=6, thread_name_prefix="atlas") as pool:
        f_rdap = pool.submit(query_rdap_domain, domain)
        f_dns = pool.submit(get_dns_records, domain)
        f_res = pool.submit(_resolve_and_geo, domain)
        f_ct = pool.submit(search_crtsh, domain)
        f_web = pool.submit(basic_web_info, domain)
        f_way = pool.submit(query_wayback, domain)

        def done(name: str, fut):
            try:
                value = fut.result()
            except Exception as e:  # one failing source must not sink the report
                logger.exception("%s lookup crashed", name)
                value = {"success": False, "errors": [f"{name} crashed: {e}"]}
            progress(f"{name} complete")
            return value

        rdap = done("RDAP", f_rdap)
        dns = done("DNS", f_dns)
        res = done("Resolution/geo", f_res)
        ct = done("Certificate Transparency", f_ct)
        web = done("HTTP", f_web)
        way = done("Web history", f_way)

    # --- RDAP
    report["sections"]["registration"] = rdap
    if rdap.get("success"):
        report["sources_used"].append(rdap.get("source") or "RDAP")
        report["confidence_summary"]["registration"] = _conf(0.80, "RDAP registration data")
    else:
        report["confidence_summary"]["registration"] = _conf(
            0.25, "RDAP failed – domain may be new, restricted, or service unavailable")
        report["limitations"].append("Domain registration (RDAP) data incomplete.")

    # --- DNS
    report["sections"]["dns"] = dns
    if dns.get("success"):
        report["sources_used"].append(f"DNS ({dns.get('method')})")
        report["confidence_summary"]["dns"] = _conf(0.90, "Live DNS resolution")
    else:
        report["confidence_summary"]["dns"] = _conf(0.2, "DNS lookup failed")

    # --- Resolution + geo
    ips = res.get("ips", [])
    report["sections"]["resolved_ips"] = {"ips": ips, "count": len(ips)}
    non_public = [ip for ip in ips if not is_public_ip(ip)]
    if non_public:
        report["limitations"].append(
            f"Domain resolves to non-public address(es) ({', '.join(non_public[:3])}); "
            "these were not queried or contacted."
        )
    geo = res.get("geo")
    if geo:
        report["sections"]["primary_ip_geo"] = geo
        if geo.get("success"):
            report["sources_used"].append(geo.get("source") or "GeoIP")

    # --- Certificate Transparency
    report["sections"]["certificate_transparency"] = ct
    if ct.get("success"):
        report["sources_used"].append("crt.sh")
        report["confidence_summary"]["subdomains_ct"] = _conf(
            0.75, f"Found {len(ct.get('unique_names', []))} unique names in CT logs")
    else:
        report["confidence_summary"]["subdomains_ct"] = _conf(0.2, "CT search failed or returned no data")

    # --- Web presence
    report["sections"]["web_presence"] = web
    if web.get("success"):
        report["sources_used"].append(web.get("final_url") or domain)
        report["confidence_summary"]["web"] = _conf(0.70, "Public HTTP response observed")
    else:
        report["limitations"].append("No HTTP response could be obtained from the domain.")

    # --- Web history (Internet Archive)
    report["sections"]["web_history"] = way
    if way.get("success"):
        report["sources_used"].append("web.archive.org (CDX API)")
        report["confidence_summary"]["web_history"] = _conf(
            0.7 if way.get("captures_found") else 0.4,
            "Internet Archive capture dates (shows the site existed then, not who ran it)")
    elif not is_offline():
        report["limitations"].append("Internet Archive history could not be retrieved.")

    # --- Related domains (certificate co-listing) and provider inference (DNS)
    related = ct.get("related_domains") or []
    if related:
        report["sections"]["related_domains"] = {
            "domains": related[:15], "note": ct.get("related_domains_note"), "confidence": "LOW",
            "source": "crt.sh (shared certificates; multi-tenant CDN certificates excluded)"}
    prov = infer_providers((dns.get("records") or {}) if dns.get("success") else {})
    if prov["email"] or prov["dns"] or prov["sending_services"]:
        report["sections"]["provider_inference"] = prov

    # ---- key findings (each with its source)
    kf = report["key_findings"]
    summ = rdap.get("raw_summary") or {}
    for ev in summ.get("events") or []:
        if isinstance(ev, dict) and ev.get("eventAction") in ("registration", "expiration", "last changed"):
            kf.append({"finding": f"Domain {ev['eventAction']}: {ev.get('eventDate')}", "source": rdap.get("source"),
                       "confidence": "HIGH"})
    if summ.get("nameservers"):
        kf.append({"finding": f"Name servers: {', '.join(n for n in summ['nameservers'] if n)}",
                   "source": rdap.get("source"), "confidence": "HIGH"})
    if ips:
        kf.append({"finding": f"Resolves to: {', '.join(ips[:6])}", "source": "DNS resolution", "confidence": "HIGH"})
    if ct.get("success"):
        kf.append({"finding": f"{len(ct.get('unique_names', []))} related host name(s) seen in Certificate Transparency logs",
                   "source": "crt.sh", "confidence": "MEDIUM"})
    if way.get("captures_found"):
        kf.append({"finding": f"Internet Archive has captures from {way['first_capture']} to {way['last_capture']} "
                              f"({way['months_with_captures']} months with captures)",
                   "source": way.get("first_snapshot_url"), "confidence": "MEDIUM"})
    elif way.get("success"):
        kf.append({"finding": "The Internet Archive has no captures of this domain (new, private or excluded site)",
                   "source": "web.archive.org (CDX API)", "confidence": "MEDIUM"})
    if related:
        kf.append({"finding": "Possibly related domains on shared certificates: " + ", ".join(r["domain"] for r in related[:6]),
                   "source": "crt.sh", "confidence": "LOW"})
    if prov["email"] or prov["dns"]:
        kf.append({"finding": "Provider inference – email: " + (", ".join(prov["email"]) or "unknown") +
                              "; DNS: " + (", ".join(prov["dns"]) or "unknown"),
                   "source": "DNS records", "confidence": "MEDIUM"})
    if web.get("success"):
        kf.append({"finding": f"Website responded HTTP {web.get('status_code')}"
                              f"{'; title: ' + web['title'] if web.get('title') else ''}",
                   "source": web.get("final_url"), "confidence": "HIGH"})
    if is_offline():
        report["limitations"].append("Offline mode: no network lookups were performed.")

    report["completed_at"] = timestamp()
    return report
