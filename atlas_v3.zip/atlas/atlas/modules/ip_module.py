"""
IP address investigation module.
Passive only.
"""

from __future__ import annotations

import ipaddress
import logging
from typing import Any, Dict

from ..sources.geoip import lookup_ip_geo, parse_asn
from ..sources.rdap import query_rdap_ip
from ..sources.reputation import check_ip_reputation
from ..utils.helpers import confidence_label, is_offline, make_progress, timestamp
from ..utils.network_safety import ip_category, parse_ip

logger = logging.getLogger("atlas.modules.ip")

LEGAL_NOTES = [
    "Querying public RDAP, DNS, and free geolocation services for an IP address is generally considered passive public research.",
    "Do not attempt to map an IP to a specific individual or private residence without lawful authority.",
    "Geolocation data is approximate and must not be treated as precise personal location information.",
    "Under UK GDPR / DPA 2018, IP addresses can be personal data in certain contexts. Processing must have a lawful basis if personal data is involved.",
    "This tool performs only passive lookups and does not attempt unauthorised access (Computer Misuse Act 1990).",
]


HOSTING_KEYWORDS = (
    "hosting", "cloud", "data center", "datacenter", "datacentre", "colo", "vps", "server", "amazon", "aws",
    "google", "microsoft", "azure", "digitalocean", "ovh", "hetzner", "linode", "akamai", "cloudflare",
    "fastly", "oracle", "alibaba", "vultr", "leaseweb", "contabo",
)

UNCERTAINTY = (
    "An IP address is not proof of a person's identity or residence: it identifies a network endpoint that may be "
    "shared (NAT, mobile carriers, VPNs, proxies, CDNs, corporate gateways) and may be reassigned over time."
)


def _hosting_indicators(rdap, geo) -> Dict[str, Any]:
    reasons = []
    gdata = (geo or {}).get("data") or {}
    if gdata.get("is_hosting"):
        reasons.append("Geolocation provider flags the address as hosting / data-centre.")
    if gdata.get("is_proxy"):
        reasons.append("Geolocation provider flags the address as proxy / VPN / relay.")
    text = " ".join(str(x or "") for x in (
        (rdap or {}).get("raw_summary", {}).get("name"), gdata.get("organisation"), gdata.get("isp"),
        gdata.get("as_name"), gdata.get("hostname"))).lower()
    hits = sorted({k for k in HOSTING_KEYWORDS if k in text})
    if hits:
        reasons.append(f"Network/organisation name contains hosting-related terms: {', '.join(hits)}.")
    return {"likely_hosting_or_datacentre": bool(reasons), "indicators": reasons,
            "confidence": "LOW" if reasons else "VERY LOW / UNVERIFIED",
            "note": "Heuristic only; absence of indicators does not mean the address is residential."}


def _conf(score: float, note: str) -> Dict[str, Any]:
    return {"level": confidence_label(score), "score": score, "note": note}


def investigate_ip(ip: str, progress_callback=None) -> Dict[str, Any]:
    """Full passive investigation of a public IP address."""
    progress = make_progress(progress_callback, logger)

    report: Dict[str, Any] = {
        "target": ip, "target_type": "IP",
        "started_at": timestamp(), "completed_at": None,
        "sections": {}, "confidence_summary": {}, "sources_used": [],
        "limitations": [], "legal_notes": list(LEGAL_NOTES), "key_findings": [],
    }

    progress("Determining IP version and basic properties...")
    try:
        cat = ip_category(ip)
        addr = parse_ip(ip)
    except ValueError:
        report["sections"]["basic"] = {"error": "Invalid IP address"}
        report["completed_at"] = timestamp()
        return report

    ip = cat["normalised"]
    report["target"] = ip
    report["sections"]["basic"] = {
        "ip_version": f"IPv{addr.version}", "category": cat["category"], "is_global": cat["is_global"],
        "explanation": cat["explanation"], "is_private": addr.is_private, "is_loopback": addr.is_loopback,
        "is_reserved": addr.is_reserved, "is_multicast": addr.is_multicast,
        "is_link_local": addr.is_link_local, "notes": [UNCERTAINTY],
    }
    report["key_findings"].append({"finding": f"{ip} is {cat['category']}: {cat['explanation']}",
                                   "source": "Python ipaddress (local analysis)", "confidence": "HIGH"})

    # Non-global addresses mean nothing to public registries; don't send them out.
    if not cat["is_global"]:
        report["sections"]["basic"]["notes"].append(
            "No external lookups were performed because public registry, geolocation and reputation data "
            "would be meaningless for this address.")
        report["limitations"].append(f"{cat['category'].title()} address – external lookups skipped.")
        report["completed_at"] = timestamp()
        return report
    if is_offline():
        report["limitations"].append("Offline mode: no registry, geolocation or reputation lookups were made.")

    progress("Querying public RDAP registries for network registration...")
    rdap = query_rdap_ip(ip)
    report["sections"]["rdap"] = rdap
    if rdap.get("success"):
        report["sources_used"].append(rdap.get("source") or "RDAP")
        report["confidence_summary"]["network_registration"] = _conf(
            0.85, "RDAP data from regional internet registry")
    else:
        report["confidence_summary"]["network_registration"] = _conf(
            0.2, "RDAP lookup failed or incomplete")
        report["limitations"].append("Could not retrieve RDAP registration data.")

    progress("Looking up approximate geolocation and ISP information (cross-checking providers)...")
    geo = lookup_ip_geo(ip)
    report["sections"]["geolocation"] = geo
    cc = geo.get("cross_check") or {}
    if geo.get("success"):
        report["sources_used"].append(geo.get("source") or "GeoIP")
        if cc.get("country_agreement") is True:
            score, note = 0.6, ("Two independent providers agree on the country"
                                + ("" if cc.get("city_agreement") else "; city/region differ or are unconfirmed")
                                + ". Network location only – never street-level or personal.")
        elif cc.get("country_agreement") is False:
            score, note = 0.15, "Providers DISAGREE on the country – treat the location as unreliable."
            report["limitations"].append("Geolocation providers disagree on the country; the location is unreliable.")
        else:
            score, note = 0.4, "Single provider only – approximate network location, could not be cross-checked."
        report["confidence_summary"]["geolocation"] = _conf(score, note)
    else:
        report["confidence_summary"]["geolocation"] = _conf(0.1, "Geolocation lookup failed")

    # accuracy cross-check: registry (RDAP) country vs geolocation country
    reg_country = ((rdap or {}).get("raw_summary") or {}).get("country")
    geo_cc = ((geo or {}).get("data") or {}).get("country_code")
    checks: Dict[str, Any] = {"geolocation_providers": cc.get("providers", []),
                              "geolocation_country_agreement": cc.get("country_agreement"),
                              "registry_country": reg_country, "geolocation_country": geo_cc}
    if reg_country and geo_cc:
        checks["registry_vs_geolocation"] = "match" if reg_country.upper() == str(geo_cc).upper() else "differs"
        if checks["registry_vs_geolocation"] == "differs":
            checks["explanation"] = ("The registry country reflects where the network operator is registered; the "
                                     "geolocation country estimates where the address is used. They often differ for "
                                     "multinational, hosting and CDN networks and are not an error by themselves.")
    report["sections"]["accuracy_checks"] = checks

    progress("Checking selected public reputation / blocklist sources...")
    rep = check_ip_reputation(ip)
    report["sections"]["reputation"] = rep
    if rep.get("success"):
        report["sources_used"].extend(rep.get("sources_checked", []))
        findings = [f for f in rep.get("findings", []) if f.get("source") != "Manual recommendation"]
        listed = [f for f in findings if f.get("listed") is True]
        unknown = [f for f in findings if f.get("listed") is None]
        if listed:
            report["confidence_summary"]["reputation"] = _conf(
                0.7, f"{len(listed)} positive listing(s) among checked sources")
        elif unknown:
            report["confidence_summary"]["reputation"] = _conf(
                0.3, f"No listings, but {len(unknown)} source(s) gave no usable answer (refused / rate-limited)")
        else:
            report["confidence_summary"]["reputation"] = _conf(0.55, "No listings among checked public RBLs")
    else:
        report["limitations"].append("Blocklist checks could not be completed.")

    # ---- derived findings
    summ = (rdap or {}).get("raw_summary") or {}
    if rdap.get("success") and summ.get("name"):
        report["key_findings"].append({
            "finding": f"Registered network: {summ.get('name')} ({summ.get('start_address')} – {summ.get('end_address')}), "
                       f"registry country {summ.get('country') or 'n/a'}.",
            "source": rdap.get("source"), "confidence": "HIGH"})
    gdata = geo.get("data") or {}
    asn = parse_asn(gdata.get("as"), gdata.get("organisation"))
    if geo.get("success"):
        report["key_findings"].append({
            "finding": f"Network operator (ISP/organisation): {gdata.get('isp') or gdata.get('organisation') or 'unknown'}"
                       f"{'; ' + asn if asn else ''}.",
            "source": geo.get("source"), "confidence": "LOW"})
    hosting = _hosting_indicators(rdap, geo)
    report["sections"]["hosting_indicators"] = hosting
    if hosting["likely_hosting_or_datacentre"]:
        report["key_findings"].append({"finding": "Indicators suggest a hosting / data-centre / relay network.",
                                       "source": "ATLAS heuristic", "confidence": "LOW"})
    report["sections"]["uncertainty"] = {"warning": UNCERTAINTY}

    report["completed_at"] = timestamp()
    return report
