"""
Username presence module ("which public platforms have an account with this exact username?").

Boundaries (also stated in every report): existence of a public profile page only; no profile
content is read; no logins; no username variants; robots.txt honoured; a shared username does NOT
show that two accounts belong to the same person.
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

from ..sources.username_sources import (
    MANUAL_LINKS, PLATFORMS, Platform, _fill, check_platform, load_platforms, selftest_platform, validate_username,
)
from ..utils.helpers import is_offline, make_progress, timestamp

logger = logging.getLogger("atlas.modules.username")

STRICT_BOUNDARY = (
    "ATLAS only checks whether a public profile page exists for the EXACT username on a curated list of "
    "mainstream platforms that permit automated access. It does not read profile content, log in, bypass "
    "access controls, try spelling variants, or link accounts to a real-world person."
)

IDENTITY_WARNING = (
    "A username that exists on several platforms does NOT show that the accounts belong to the same person: "
    "usernames are frequently reused by unrelated people. Treat every result as a lead to verify, never as "
    "identification. Wrongly attributing accounts to a person can cause real harm."
)

LEGAL_NOTES = [
    "A username can be personal data under UK GDPR / DPA 2018 when it relates to an identifiable person; you need a lawful basis and a specific purpose.",
    "Suitable purposes include checking your own handle or brand for impersonation, authorised security assessments and "
    "proportionate public-interest research. Do not use this to locate, monitor or harass an individual.",
    "Platform terms of service may restrict automated checks; ATLAS honours robots.txt and queries one public URL per platform, but you remain responsible for compliance.",
    "Using public information does not by itself make an investigation lawful; legality depends on purpose, the information, how it is processed and the circumstances.",
    "This is not formal legal advice.",
]

_ORDER = {"found": 0, "unreliable": 1, "inconclusive": 2, "error": 3, "skipped_robots": 4,
          "skipped_format": 5, "not_found": 6, "offline": 7}


def investigate_username(
    username: str,
    progress_callback=None,
    stop_at_first: bool = False,
    platforms: Optional[List[Platform]] = None,
    max_workers: int = 8,
    platforms_path: Optional[str] = None,
) -> Dict[str, Any]:
    progress = make_progress(progress_callback, logger)
    load_warnings: List[str] = []
    list_source = "built-in list"
    if platforms is None:
        if platforms_path:
            platforms, load_warnings = load_platforms(platforms_path)
            list_source = f"custom list ({platforms_path})"
        else:
            platforms = PLATFORMS
    platforms = list(platforms)
    username = (username or "").strip().lstrip("@")

    report: Dict[str, Any] = {
        "target": username, "target_type": "USERNAME",
        "started_at": timestamp(), "completed_at": None,
        "sections": {}, "confidence_summary": {}, "sources_used": [],
        "limitations": [], "legal_notes": list(LEGAL_NOTES), "key_findings": [],
        "strict_boundary": STRICT_BOUNDARY, "search_hints": [],
    }
    accounts: Dict[str, Any] = {"found": [], "unreliable": [], "inconclusive": [], "skipped": [],
                                "not_found_count": 0, "checked": 0, "stop_at_first": stop_at_first,
                                "platform_list": list_source}
    report["limitations"] += load_warnings
    report["accounts"] = accounts

    if not platforms:
        report["error"] = "No usable platforms to check" + (f" ({'; '.join(load_warnings)})" if load_warnings else "")
        report["completed_at"] = timestamp()
        return report
    ok, why = validate_username(username)
    if not ok:
        report["error"] = f"Invalid username: {why}"
        report["completed_at"] = timestamp()
        return report

    # manual links: printed for the user, never fetched
    report["search_hints"] = [
        {"description": f"{name} (blocks automated access – open manually if you have a legitimate need)",
         "url": _fill(tpl, username)} for name, tpl in MANUAL_LINKS]

    if is_offline():
        report["limitations"].append("Offline mode: no platforms were queried.")
        accounts["status"] = "offline"
        report["completed_at"] = timestamp()
        return report

    progress(f"Checking {len(platforms)} public platforms for the exact username '{username}' "
             f"(robots.txt honoured, one request each)...")
    results: List[Dict[str, Any]] = []
    stopped_early = False
    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="atlas-user") as pool:
        futures = {pool.submit(check_platform, p, username): p for p in platforms}
        for fut in as_completed(futures):
            p = futures[fut]
            try:
                r = fut.result()
            except Exception as e:                          # one platform failing must not sink the scan
                logger.exception("%s check crashed", p.name)
                r = {"platform": p.name, "category": p.category, "status": "error",
                     "detail": f"check crashed: {e}", "profile_url": None, "http_status": None,
                     "checked_at": timestamp(), "control_check": None}
            results.append(r)
            if r["status"] == "found":
                progress(f"match: {r['platform']} → {r['profile_url']}")
                if stop_at_first:
                    stopped_early = True
                    for other in futures:
                        other.cancel()                      # pending checks never start
                    break

    order = {p.name: i for i, p in enumerate(platforms)}
    results.sort(key=lambda r: (_ORDER.get(r["status"], 9), order.get(r["platform"], 99)))
    accounts["checked"] = len(results)
    for r in results:
        st = r["status"]
        if st == "found":
            accounts["found"].append({
                "platform": r["platform"], "category": r["category"], "profile_url": r["profile_url"],
                "evidence": r["detail"], "control_check": r["control_check"], "checked_at": r["checked_at"],
                "existence_confidence": r.get("existence_confidence") or "LOW",
                "username_in_page": r.get("username_in_page"),
                "identity_confidence": "UNVERIFIED",
            })
        elif st == "unreliable":
            accounts["unreliable"].append(r)
        elif st in ("inconclusive", "error"):
            accounts["inconclusive"].append(r)
        elif st in ("skipped_robots", "skipped_format", "offline"):
            accounts["skipped"].append(r)
        else:
            accounts["not_found_count"] += 1

    n_found = len(accounts["found"])
    report["sections"]["scan_summary"] = {
        "platforms_in_list": len(platforms), "checked": accounts["checked"], "matches": n_found,
        "not_found": accounts["not_found_count"], "unreliable_platforms": len(accounts["unreliable"]),
        "inconclusive_or_error": len(accounts["inconclusive"]), "skipped": len(accounts["skipped"]),
        "stopped_at_first_match": stopped_early,
    }
    for a in accounts["found"]:
        report["sources_used"].append(a["profile_url"])
        report["key_findings"].append({
            "finding": f"A public profile exists for '{username}' on {a['platform']} ({a['category']}): {a['profile_url']}",
            "source": a["profile_url"], "confidence": a["existence_confidence"] + " (existence only)"})
    if not n_found:
        report["key_findings"].append({
            "finding": f"No match for '{username}' on the {accounts['checked']} platform(s) ATLAS could check.",
            "source": "HTTP responses from the platforms listed", "confidence": "LOW"})
    report["key_findings"].append({"finding": IDENTITY_WARNING, "source": "ATLAS", "confidence": "n/a"})

    best = "HIGH" if any(a["existence_confidence"] == "HIGH" for a in accounts["found"]) else "MEDIUM" if any(
        a["existence_confidence"] == "MEDIUM" for a in accounts["found"]) else "LOW"
    report["confidence_summary"]["account_existence"] = {
        "level": best, "score": {"HIGH": 0.85, "MEDIUM": 0.6, "LOW": 0.3}[best],
        "note": "Based on HTTP responses, soft-404 detection and two control checks per match; sites change and may block automated requests."}
    report["confidence_summary"]["identity_linkage"] = {
        "level": "UNVERIFIED", "score": 0.0, "note": "Same username ≠ same person. ATLAS makes no identity claim."}

    if stopped_early:
        report["limitations"].append("Scan stopped at the first match (--stop-at-first); remaining platforms were not checked.")
    skipped_robots = [r["platform"] for r in accounts["skipped"] if r["status"] == "skipped_robots"]
    if skipped_robots:
        report["limitations"].append("Not queried because robots.txt disallows or could not be verified: " + ", ".join(skipped_robots) + ".")
    if accounts["unreliable"]:
        report["limitations"].append("Unreliable detection (control check failed): " +
                                     ", ".join(r["platform"] for r in accounts["unreliable"]) + ".")
    if accounts["inconclusive"]:
        report["limitations"].append("Inconclusive (rate-limited, blocked, error or redirected): " +
                                     ", ".join(r["platform"] for r in accounts["inconclusive"]) + ".")
    report["limitations"] += [
        "Only exact-username matches on a curated list of platforms are checked; accounts under other names are not found.",
        "Major social networks that block automated access are not queried (manual links are provided).",
        "Detection rules can go stale when a platform changes; a missing result is not proof an account does not exist.",
        IDENTITY_WARNING,
    ]
    report["completed_at"] = timestamp()
    return report


def run_selftest(progress_callback=None, platforms_path: Optional[str] = None, max_workers: int = 8) -> Dict[str, Any]:
    """Health-check every platform rule (negative control + known-good account). Makes ~1-2 requests per platform."""
    progress = make_progress(progress_callback, logger)
    out: Dict[str, Any] = {"checked_at": timestamp(), "results": [], "summary": {}, "recommendations": [], "warnings": []}
    if is_offline():
        out["status"] = "offline"
        return out
    if platforms_path:
        platforms, out["warnings"] = load_platforms(platforms_path)
    else:
        platforms = PLATFORMS
    progress(f"Health-checking {len(platforms)} platform rules (random-name control + known-good account)...")
    results: List[Dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="atlas-selftest") as pool:
        futs = {pool.submit(selftest_platform, p): p for p in platforms}
        for fut in as_completed(futs):
            p = futs[fut]
            try:
                results.append(fut.result())
            except Exception as e:
                results.append({"platform": p.name, "category": p.category, "verdict": "error", "note": str(e),
                                "negative": None, "positive": None})
    order = {p.name: i for i, p in enumerate(platforms)}
    results.sort(key=lambda r: order.get(r["platform"], 999))
    out["results"] = results
    for r in results:
        out["summary"][r["verdict"]] = out["summary"].get(r["verdict"], 0) + 1
    for r in results:
        if r["verdict"] in ("unreliable", "stale_rule"):
            out["recommendations"].append(f"{r['platform']}: {r['note']}")
    out["status"] = "done"
    return out
