"""Heuristic source-reliability ratings (transparent, deliberately conservative)."""

from __future__ import annotations

from typing import Dict, Tuple
from urllib.parse import urlparse

_OFFICIAL_SUFFIXES = (".gov.uk", ".gov", ".ac.uk", ".edu", ".nhs.uk", ".mod.uk", ".police.uk",
                      ".parliament.uk", ".sch.uk", ".europa.eu", ".int")
_COMMUNITY = ("wikipedia.org", "wikimedia.org", "wikidata.org")

# Non-URL sources used by ATLAS.
_NAMED: Dict[str, Tuple[str, str]] = {
    "rdap": ("HIGH", "Regional/registry-operated RDAP data (authoritative for registration, not for identity)."),
    "dns": ("HIGH", "Live DNS answers (authoritative for what the DNS currently says)."),
    "crt.sh": ("MEDIUM", "Public Certificate Transparency logs via crt.sh; complete for logged certs, not for all hosts."),
    "ipinfo.io": ("LOW", "Commercial IP-geolocation estimate; network location only, often inaccurate below country level."),
    "ip-api.com": ("LOW", "Free IP-geolocation estimate; network location only, often inaccurate below country level."),
    "spamhaus": ("MEDIUM", "Widely used DNS blocklist; an indicator, not proof."),
    "spamcop": ("MEDIUM", "Widely used DNS blocklist; an indicator, not proof."),
    "heuristic": ("LOW", "Automated guess; requires human verification."),
}


def rate_domain(host: str) -> Tuple[str, str]:
    host = (host or "").lower().rstrip(".")
    if host.endswith(_OFFICIAL_SUFFIXES):
        return "HIGH", "Government / academic / institutional domain; likely an official source."
    if any(host == d or host.endswith("." + d) for d in _COMMUNITY):
        return "MEDIUM", "Community-edited reference; generally reliable for notable subjects but not authoritative."
    return "LOW", "Domain ownership/authority not independently verified by ATLAS."


def rate_source(source: str) -> Tuple[str, str]:
    """Rate a URL or a named data source."""
    s = (source or "").strip()
    if s.startswith(("http://", "https://")):
        host = urlparse(s).hostname or ""
        for key in ("rdap", "crt.sh"):
            if key in host:
                return _NAMED[key if key != "rdap" else "rdap"]
        if host.endswith("iana.org") or host.startswith("rdap."):
            return _NAMED["rdap"]
        return rate_domain(host)
    low = s.lower()
    for key, val in _NAMED.items():
        if key in low:
            return val
    if low.startswith("dns"):
        return _NAMED["dns"]
    return "LOW", "Source not classified by ATLAS."
