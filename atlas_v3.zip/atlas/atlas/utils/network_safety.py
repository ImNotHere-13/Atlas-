"""
Network safety layer for ATLAS (standard library only).

Every outbound request in ATLAS goes through :func:`safe_request`, which:

* only allows http/https URLs without embedded credentials, on a small set of ports
* resolves the host itself, refuses non-public addresses (SSRF protection) and then
  connects to the *validated IP* (defeats DNS-rebinding between check and use)
* re-validates every redirect hop (max 5)
* optionally honours robots.txt (conservatively: if it cannot be read, it is treated
  as "no automated access")
* applies per-host rate limiting, timeouts, a hard body-size cap and a total deadline
* can be switched off entirely with offline mode
"""

from __future__ import annotations

import http.client
import ipaddress
import logging
import socket
import ssl
import threading
import time
from typing import Any, Dict, List, Optional, Tuple
from urllib import robotparser
from urllib.parse import urljoin, urlparse

logger = logging.getLogger("atlas.net")

_sleep = time.sleep                 # indirection so tests can run without real delays
RETRY_STATUSES = (429, 502, 503, 504)
MAX_RETRY_AFTER = 5.0               # never wait (or retry) past this: a longer Retry-After is respected, not evaded

USER_AGENT = "ATLAS-OSINT/2.0 (Passive Research Agent)"
ROBOTS_TOKEN = "ATLAS-OSINT"
DEFAULT_DELAY = 1.2            # seconds between requests to the same host
MAX_BODY_BYTES = 1_000_000     # default cap on any response body
MAX_REDIRECTS = 5
TOTAL_DEADLINE = 30.0          # seconds, whole request incl. body read
ALLOWED_PORTS = {80, 443, 8080, 8443}
MAX_URL_LENGTH = 2048

# --------------------------------------------------------------------------
# Offline mode
# --------------------------------------------------------------------------
_offline = False


def set_offline(value: bool) -> None:
    global _offline
    _offline = bool(value)


def is_offline() -> bool:
    return _offline


OFFLINE_MESSAGE = "offline mode: network access disabled"


# --------------------------------------------------------------------------
# IP classification
# --------------------------------------------------------------------------
_CGNAT = ipaddress.ip_network("100.64.0.0/10")
_DOC_NETS = [ipaddress.ip_network(n) for n in
             ("192.0.2.0/24", "198.51.100.0/24", "203.0.113.0/24", "2001:db8::/32")]


def parse_ip(value: str):
    """Parse an IP (unwrapping IPv4-mapped IPv6 and zone ids). Raises ValueError."""
    addr = ipaddress.ip_address(value.strip().strip("[]").split("%")[0])
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped:
        addr = addr.ipv4_mapped
    return addr


def ip_category(value: str) -> Dict[str, Any]:
    """
    Classify an IP address.
    Returns {"category", "is_global", "explanation"} – category is one of:
    public, private, loopback, link-local, multicast, unspecified, documentation,
    shared-address-space, reserved.
    """
    addr = parse_ip(value)
    if addr.is_unspecified:
        cat, why = "unspecified", "Unspecified address (0.0.0.0 / ::)."
    elif addr.is_loopback:
        cat, why = "loopback", "Loopback address – refers to the local machine only."
    elif addr.is_link_local:
        cat, why = "link-local", "Link-local address – only valid on the local network segment."
    elif addr.is_multicast:
        cat, why = "multicast", "Multicast address – not assigned to a single host."
    elif any(addr in n for n in _DOC_NETS if n.version == addr.version):
        cat, why = "documentation", "Reserved for documentation/examples; never routed on the internet."
    elif addr.version == 4 and addr in _CGNAT:
        cat, why = "shared-address-space", "Carrier-grade NAT range (100.64.0.0/10); not globally routable."
    elif addr.is_reserved:
        cat, why = "reserved", "Reserved / special-use address; not globally routable."
    elif addr.is_private:
        cat, why = "private", "Private-use address (RFC 1918 / ULA)."
    elif addr.is_global:
        cat, why = "public", "Publicly routable address."
    else:
        cat, why = "reserved", "Reserved / special-use address; not globally routable."
    return {"category": cat, "is_global": cat == "public", "explanation": why,
            "ip_version": addr.version, "normalised": str(addr)}


def is_public_ip(ip: str) -> bool:
    try:
        return ip_category(ip)["is_global"]
    except ValueError:
        return False


# --------------------------------------------------------------------------
# Resolution
# --------------------------------------------------------------------------

def resolve_hostname(hostname: str) -> List[str]:
    """Resolve hostname to IP addresses (empty list in offline mode / on failure)."""
    if _offline:
        return []
    results: List[str] = []
    try:
        for info in socket.getaddrinfo(hostname, None, type=socket.SOCK_STREAM):
            ip = info[4][0]
            if ip not in results:
                results.append(ip)
    except (socket.gaierror, UnicodeError, OSError):
        pass
    return results


def resolve_public(host: str) -> Tuple[List[str], str]:
    """
    Resolve *host* and require that EVERY address is globally routable.
    Returns (ips, error); error is "" on success.
    """
    host = host.strip("[]")
    try:
        ips = [str(parse_ip(host))]
    except ValueError:
        ips = resolve_hostname(host)
    if not ips:
        return [], "host did not resolve"
    for ip in ips:
        if not is_public_ip(ip):
            return [], f"resolves to non-public address {ip}"
    return ips, ""


def host_is_public(host: str) -> Tuple[bool, str]:
    ips, err = resolve_public(host)
    return (not err), err


# --------------------------------------------------------------------------
# URL validation
# --------------------------------------------------------------------------

def validate_url(url: str) -> Tuple[bool, str]:
    """Static checks only (no DNS): scheme, credentials, port, length, control chars."""
    if not isinstance(url, str) or not url:
        return False, "empty URL"
    if len(url) > MAX_URL_LENGTH:
        return False, "URL too long"
    if any(ord(c) < 33 or ord(c) == 127 for c in url):
        return False, "URL contains whitespace/control characters"
    try:
        p = urlparse(url)
        port = p.port
    except ValueError:
        return False, "malformed URL"
    if p.scheme not in ("http", "https"):
        return False, f"unsupported scheme {p.scheme!r} (only http/https)"
    if not p.hostname:
        return False, "URL has no host"
    if p.username or p.password:
        return False, "URLs with embedded credentials are refused"
    if port is not None and port not in ALLOWED_PORTS:
        return False, f"port {port} not allowed"
    return True, ""


def is_safe_public_url(url: str) -> bool:
    """Static validation only – used for links/images rendered in reports."""
    ok, _ = validate_url(url)
    return ok


# --------------------------------------------------------------------------
# Rate limiting
# --------------------------------------------------------------------------
_rate_lock = threading.Lock()
_last_request: Dict[str, float] = {}


def rate_limit(host: str, delay: float = DEFAULT_DELAY) -> None:
    """Thread-safe per-host rate limiting."""
    with _rate_lock:
        now = time.monotonic()
        wait = delay - (now - _last_request.get(host, -1e9))
        _last_request[host] = now + max(wait, 0.0)
    if wait > 0:
        time.sleep(wait)


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------

class SimpleResponse:
    def __init__(self, status_code: int, headers: Dict[str, str], url: str, content: bytes):
        self.status_code = status_code
        self.headers = headers
        self.url = url
        self.content = content
        self.truncated = False

    @property
    def text(self) -> str:
        return self.content.decode("utf-8", errors="replace")

    def json(self) -> Any:
        import json
        return json.loads(self.text)

    def header(self, name: str, default: str = "") -> str:
        for k, v in self.headers.items():
            if k.lower() == name.lower():
                return v
        return default


class _PinnedHTTPConnection(http.client.HTTPConnection):
    def __init__(self, host, port, pin_ip, timeout):
        super().__init__(host, port, timeout=timeout)
        self._pin_ip = pin_ip

    def connect(self):
        self.sock = socket.create_connection((self._pin_ip, self.port), self.timeout)


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host, port, pin_ip, timeout):
        super().__init__(host, port, timeout=timeout, context=ssl.create_default_context())
        self._pin_ip = pin_ip

    def connect(self):
        sock = socket.create_connection((self._pin_ip, self.port), self.timeout)
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


def _single_request(url: str, method: str, headers: Dict[str, str], timeout: float,
                    ips: List[str], max_bytes: int, read_body: bool) -> SimpleResponse:
    """One HTTP(S) request to a pinned, pre-validated IP. No redirect following."""
    p = urlparse(url)
    https = p.scheme == "https"
    port = p.port or (443 if https else 80)
    path = (p.path or "/") + (f"?{p.query}" if p.query else "")
    cls = _PinnedHTTPSConnection if https else _PinnedHTTPConnection
    last_err: Optional[Exception] = None
    for ip in ips:
        conn = cls(p.hostname, port, ip, timeout)
        try:
            conn.request(method, path, headers={**headers, "Connection": "close"})
            r = conn.getresponse()
            hdrs = {k.lower(): v for k, v in r.getheaders()}
            body = b""
            truncated = False
            if read_body and method != "HEAD":
                deadline = time.monotonic() + TOTAL_DEADLINE
                while True:
                    chunk = r.read(16384)
                    if not chunk:
                        break
                    body += chunk
                    if len(body) > max_bytes:
                        body, truncated = body[:max_bytes], True
                        break
                    if time.monotonic() > deadline:
                        truncated = True
                        break
            resp = SimpleResponse(r.status, hdrs, url, body)
            resp.truncated = truncated
            return resp
        except Exception as e:            # try the next validated IP
            last_err = e
        finally:
            try:
                conn.close()
            except Exception:
                pass
    raise last_err or OSError("no addresses to connect to")


# robots.txt cache: host-key -> RobotFileParser | None(disallow all)
_robots_cache: Dict[str, Optional[robotparser.RobotFileParser]] = {}
_robots_lock = threading.Lock()


def robots_allowed(url: str) -> Tuple[bool, str]:
    """
    Check robots.txt for *url*. Conservative: 4xx => allowed (RFC 9309),
    5xx / unreachable / offline => NOT allowed (cannot verify permission).
    """
    p = urlparse(url)
    key = f"{p.scheme}://{p.netloc}"
    with _robots_lock:
        cached = key in _robots_cache
        rp = _robots_cache.get(key)
    if not cached:
        resp, err = safe_request(f"{key}/robots.txt", timeout=8, max_bytes=200_000,
                                 respect_robots=False)
        if resp is None:
            rp = None
        elif 200 <= resp.status_code < 300:
            rp = robotparser.RobotFileParser()
            rp.parse(resp.text.splitlines())
        elif 400 <= resp.status_code < 500:
            rp = robotparser.RobotFileParser()
            rp.parse([])                       # empty robots.txt => everything allowed
        else:
            rp = None
        with _robots_lock:
            _robots_cache[key] = rp
    if rp is None:
        return False, "robots.txt could not be verified; treated as no automated access"
    if rp.can_fetch(ROBOTS_TOKEN, url):
        return True, ""
    return False, "disallowed by robots.txt"


def _retry_delay(resp: "SimpleResponse") -> Optional[float]:
    """Seconds to wait before a retry, or None if the server asked for a longer pause than we allow."""
    raw = resp.header("Retry-After").strip()
    if raw.isdigit():
        secs = float(raw)
        return None if secs > MAX_RETRY_AFTER else secs
    return 1.5


def clear_robots_cache() -> None:
    with _robots_lock:
        _robots_cache.clear()


def safe_request(
    url: str,
    timeout: float = 12.0,
    headers: Optional[Dict[str, str]] = None,
    method: str = "GET",
    allow_redirects: bool = True,
    max_bytes: int = MAX_BODY_BYTES,
    read_body: bool = True,
    respect_robots: bool = False,
    retries: int = 0,
) -> Tuple[Optional[SimpleResponse], Optional[str]]:
    """
    Safe, polite HTTP request. Returns (response_or_None, error_or_None).

    retries: how many times to repeat a request after a transient failure (connection error, or HTTP
    429/502/503/504). A Retry-After longer than MAX_RETRY_AFTER is honoured by NOT retrying.
    """
    if _offline:
        return None, OFFLINE_MESSAGE
    hdrs = {
        "User-Agent": USER_AGENT,
        "Accept": "application/rdap+json, application/json, text/html, */*",
        "Accept-Language": "en-GB,en;q=0.9",
    }
    if headers:
        hdrs.update(headers)

    current = url
    try:
        for _ in range(MAX_REDIRECTS + 1):
            ok, why = validate_url(current)
            if not ok:
                return None, f"refused URL: {why}"
            host = urlparse(current).hostname
            ips, err = resolve_public(host)
            if err:
                return None, f"refused to contact {host}: {err}"
            if respect_robots and method == "GET":
                allowed, why = robots_allowed(current)
                if not allowed:
                    return None, f"not fetched: {why}"
            attempt = 0
            while True:
                rate_limit(urlparse(current).netloc)
                try:
                    resp = _single_request(current, method, hdrs, timeout, ips, max_bytes, read_body)
                except Exception:
                    if attempt < retries:
                        attempt += 1
                        _sleep(1.0)
                        continue
                    raise
                if resp.status_code in RETRY_STATUSES and attempt < retries:
                    wait = _retry_delay(resp)
                    if wait is not None:
                        attempt += 1
                        _sleep(wait)
                        continue
                break
            location = resp.header("Location")
            if allow_redirects and resp.status_code in (301, 302, 303, 307, 308) and location:
                current = urljoin(current, location)
                continue
            resp.url = current
            return resp, None
        return None, f"too many redirects (> {MAX_REDIRECTS})"
    except Exception as e:
        logger.debug("Request failed for %s: %s", url, e)
        return None, f"{type(e).__name__}: {e}"
