"""Local report retention controls: list, delete, purge. Path-traversal safe."""

from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Dict, List, Optional

_BASE_RE = re.compile(r"^atlas_[\w.\-]+_\d{8}T\d{6}Z$")
_EXTS = (".json", ".txt", ".html")


def _dir(output_dir: str) -> Path:
    return Path(output_dir).resolve()


def _files_for(base: str, d: Path) -> List[Path]:
    out = []
    for ext in _EXTS:
        p = (d / f"{base}{ext}").resolve()
        if p.parent == d and p.is_file():          # must live directly inside the reports dir
            out.append(p)
    return out


def list_reports(output_dir: str) -> List[Dict]:
    d = _dir(output_dir)
    if not d.is_dir():
        return []
    bases = set()
    for p in d.iterdir():
        name = p.name
        for ext in _EXTS:
            if name.endswith(ext) and _BASE_RE.match(name[: -len(ext)]):
                bases.add(name[: -len(ext)])
    rows = []
    for b in bases:
        files = _files_for(b, d)
        if files:
            rows.append({"name": b, "files": [f.name for f in files],
                         "modified": max(f.stat().st_mtime for f in files),
                         "bytes": sum(f.stat().st_size for f in files)})
    return sorted(rows, key=lambda r: r["modified"], reverse=True)


def delete_report(output_dir: str, name: str) -> int:
    """Delete one report set by base name (e.g. atlas_example.com_20260101T000000Z). Returns files removed."""
    name = name.strip()
    for ext in _EXTS:                              # tolerate a pasted filename
        if name.endswith(ext):
            name = name[: -len(ext)]
    if not _BASE_RE.match(name):
        raise ValueError("not a valid ATLAS report name")
    d = _dir(output_dir)
    files = _files_for(name, d)
    for f in files:
        f.unlink()
    return len(files)


def delete_all(output_dir: str) -> int:
    return sum(delete_report(output_dir, r["name"]) for r in list_reports(output_dir))


def purge_older_than(output_dir: str, days: float, now: Optional[float] = None) -> int:
    cutoff = (now or time.time()) - days * 86400
    return sum(delete_report(output_dir, r["name"]) for r in list_reports(output_dir) if r["modified"] < cutoff)
