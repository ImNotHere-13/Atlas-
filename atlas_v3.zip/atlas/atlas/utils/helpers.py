"""
Utility helpers for ATLAS (validation, timestamps, progress).

Network functionality lives in :mod:`atlas.utils.network_safety`; the names are
re-exported here for backwards compatibility.
"""

from __future__ import annotations

import ipaddress
import logging
import re
from datetime import datetime, timezone
from typing import Callable, Optional
from urllib.parse import urlparse

logger = logging.getLogger("atlas.utils")



# --------------------------------------------------------------------------
# Small generic helpers
# --------------------------------------------------------------------------

def timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def confidence_label(score: float) -> str:
    """Map 0.0–1.0 score to human label."""
    if score >= 0.85:
        return "HIGH"
    if score >= 0.60:
        return "MEDIUM"
    if score >= 0.35:
        return "LOW"
    return "VERY LOW / UNVERIFIED"


def make_progress(callback: Optional[Callable[[str], None]], log: logging.Logger) -> Callable[[str], None]:
    """Build the progress function every module uses (callback + debug log)."""
    def progress(msg: str) -> None:
        if callback:
            callback(msg)
        log.debug(msg)
    return progress


def clean_target(value: str) -> str:
    """Trim whitespace and one layer of matching surrounding quotes."""
    value = (value or "").strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'“”‘’":
        value = value[1:-1].strip()
    return value


# --------------------------------------------------------------------------
# Validation
# --------------------------------------------------------------------------

def is_valid_ipv4(value: str) -> bool:
    try:
        return isinstance(ipaddress.ip_address(value.strip()), ipaddress.IPv4Address)
    except ValueError:
        return False


def is_valid_ipv6(value: str) -> bool:
    try:
        return isinstance(ipaddress.ip_address(value.strip().strip("[]")), ipaddress.IPv6Address)
    except ValueError:
        return False


_DOMAIN_RE = re.compile(
    r"^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$", re.IGNORECASE
)


def is_valid_domain(value: str) -> bool:
    """Basic domain validation (not exhaustive)."""
    value = value.strip().lower().rstrip(".")
    if value.startswith(("http://", "https://")):
        return False
    if not 1 <= len(value) <= 253:
        return False
    return bool(_DOMAIN_RE.match(value))


def is_valid_url(value: str) -> bool:
    try:
        result = urlparse(value.strip())
        return result.scheme in ("http", "https") and bool(result.netloc)
    except ValueError:
        return False



from .network_safety import (  # noqa: E402,F401  (re-exports)
    SimpleResponse, USER_AGENT, host_is_public, is_public_ip, is_offline,
    rate_limit, resolve_hostname, safe_request, set_offline,
)
