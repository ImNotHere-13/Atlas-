"""
Safe HTML rendering helpers (standard library only).

Generated pages contain NO JavaScript, set a restrictive Content-Security-Policy,
escape every dynamic value, only emit http(s) URLs, and add rel/referrer protections.
"""

from __future__ import annotations

import html
import os
from typing import Any, Dict, Optional

from .network_safety import is_safe_public_url

CSP = ("default-src 'none'; img-src https: http:; style-src 'unsafe-inline'; "
       "base-uri 'none'; form-action 'none'; frame-ancestors 'none'")

BASE_CSS = """
:root{color-scheme:light dark;--bg:#fff;--fg:#1b1f24;--mut:#59636e;--card:#f6f8fa;--bd:#d0d7de;--acc:#0969da;--ok:#1a7f37;--warn:#9a6700;--bad:#cf222e}
@media (prefers-color-scheme:dark){:root{--bg:#0d1117;--fg:#e6edf3;--mut:#8d96a0;--card:#161b22;--bd:#30363d;--acc:#58a6ff;--ok:#3fb950;--warn:#d29922;--bad:#f85149}}
body{font:15px/1.55 system-ui,-apple-system,Segoe UI,sans-serif;background:var(--bg);color:var(--fg);max-width:980px;margin:2rem auto;padding:0 1rem}
h1{font-size:1.6rem}h2{font-size:1.15rem;border-bottom:1px solid var(--bd);padding-bottom:.3rem;margin-top:2rem}
a{color:var(--acc);word-break:break-all}table{border-collapse:collapse;width:100%}td,th{border:1px solid var(--bd);padding:.35rem .6rem;vertical-align:top;text-align:left}
th{background:var(--card);width:28%}pre{background:var(--card);border:1px solid var(--bd);padding:.7rem;overflow:auto;white-space:pre-wrap}
.muted{color:var(--mut)}.badge{display:inline-block;border:1px solid var(--bd);border-radius:1rem;padding:0 .6rem;font-size:.8rem}
.verified{color:var(--ok)}.probable{color:var(--warn)}.unverified{color:var(--bad)}
.notice{border-left:4px solid var(--warn);background:var(--card);padding:.5rem .8rem;margin:1rem 0}
"""


def esc(value: Any) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def safe_link(url: Optional[str], text: Optional[str] = None) -> str:
    """An <a> tag for http(s) URLs; plain escaped text for anything else."""
    if url and is_safe_public_url(str(url)):
        return (f'<a href="{esc(url)}" target="_blank" rel="noopener noreferrer nofollow">'
                f"{esc(text or url)}</a>")
    return esc(text or url or "")


def page(title: str, body: str) -> str:
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8">'
            f'<meta http-equiv="Content-Security-Policy" content="{CSP}">'
            f'<meta name="referrer" content="no-referrer">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1">'
            f"<title>{esc(title)}</title><style>{BASE_CSS}</style></head><body>{body}</body></html>")


def write_private(path: str, text: str) -> None:
    """Write a file readable only by the current user (best effort on Windows)."""
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)
