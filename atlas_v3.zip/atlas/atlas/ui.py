"""
Terminal user interface for ATLAS.

Standard library only. Colour uses plain ANSI codes that ATLAS adds itself, only on a colour-capable
terminal (honours NO_COLOR). ALL printed text is stripped of control characters BEFORE any styling
is applied, which prevents terminal escape-sequence injection from remote page content.
"""

from __future__ import annotations

import os
import re
import shlex
import sys
import time
from typing import Any, Dict, List, Optional, Tuple


_SGR = {"bold": "1", "dim": "2", "red": "31", "green": "32", "cyan": "36", "bold cyan": "1;36", "bold red": "1;31"}


def _color_enabled() -> bool:
    if os.environ.get("NO_COLOR") or os.environ.get("ATLAS_PLAIN") or not sys.stdout.isatty():
        return False
    if os.name == "nt":                # only terminals known to understand ANSI
        return bool(os.environ.get("WT_SESSION") or os.environ.get("ANSICON") or os.environ.get("TERM"))
    return os.environ.get("TERM", "") not in ("", "dumb")


_CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f-\x9f]")

BANNER = r"""
    ___   ________  ___    ___   _____
   /   | /_  __/ / / / |  / / | / ___/
  / /| |  / / / / / /| | / /| | \__ \
 / ___ | / / / /_/ / | |/ / | |___/ /
/_/  |_|/_/  \____/  |___/  |_/____/

  ATLAS – Passive OSINT Intelligence Agent
  Ethical • Transparent • Source-aware
"""

HELP = """
Commands
--------
  investigate <target> [--type T] [--source URL ...]
                         Full investigation (IP, domain, URL, organisation, person, username)
  username <name> [--stop-at-first] [--platforms FILE]
                         Which public platforms have an account with this exact username
                         (also: @name, or a bare handle such as john_smith99)
  selftest [--platforms FILE]
                         Health-check the username platform rules (finds stale/unreliable ones)
  report                 Show the last report again
  export [html]          Export last report (JSON + TXT, optionally HTML)
  reports list | delete <name|all> | purge <days>
                         Manage locally stored reports
  offline on|off         Disable/enable all network access
  help, exit

Notes
-----
* Only public, passive sources; robots.txt is honoured; private/internal addresses are never contacted.
* --source <URL>: an official/public page you supply (e.g. a biography page or a company's real website).
* Organisations and public figures are looked up in Wikidata/Wikipedia, certificate-transparency logs and the
  Internet Archive; domains also get web history and related-domain discovery.
* IP geolocation is an approximate NETWORK location, never a person's address.
* Username results show that a public profile EXISTS, not who owns it: the same username is often used by different people.
"""


def sanitize(text: Any) -> str:
    """Remove control characters (incl. ESC) from untrusted text."""
    return _CTRL.sub("", "" if text is None else str(text))


def emit(text: str = "", style: Optional[str] = None) -> None:
    text = sanitize(text)                 # ALWAYS strip control characters (terminal escape injection)
    code = _SGR.get(style or "")
    print(f"\x1b[{code}m{text}\x1b[0m" if code and _color_enabled() else text)


def link(url: Optional[str]) -> str:
    """
    Clickable URL for the terminal. Deliberately a plain, sanitised URL: virtually every terminal
    makes plain http(s) URLs clickable, and emitting escape-sequence hyperlinks would require
    letting control characters through the sanitiser.
    """
    return sanitize(url)


def print_banner() -> None:
    emit(BANNER, "bold cyan")
    emit("Passive research only. No unauthorised access. No private data collection.\n", "dim")


def print_help() -> None:
    emit(HELP)


def progress_printer(message: str) -> None:
    emit(f"  → {message}", "cyan")


def print_error(msg: str) -> None:
    emit(f"Error: {msg}", "bold red")


def print_info(msg: str) -> None:
    emit(msg, "bold")


def print_report_text(text: str) -> None:
    emit(text)


def show_classification(c: Dict[str, Any]) -> None:
    emit("\n── Input classification ──", "bold")
    for k in ("original_input", "normalised", "type", "confidence", "notes"):
        emit(f"  {k.replace('_', ' '):<15}: {c.get(k)}")


def show_summary(report: Dict[str, Any]) -> None:
    emit("\n=== Investigation Complete ===", "bold cyan")
    for f in report.get("key_findings") or []:
        emit(f"  • {sanitize(f.get('finding'))}  [{f.get('confidence')}]")
    conf = report.get("confidence_summary") or {}
    for k, v in conf.items():
        if isinstance(v, dict):
            emit(f"  {k}: {v.get('level')} – {sanitize(v.get('note'))}")
    show_accounts(report)
    for lim in (report.get("limitations") or [])[:4]:
        emit(f"  limitation: {sanitize(lim)}", "dim")
    export = report.get("export") or {}
    for kind, path in export.items():
        emit(f"{kind.upper():<8}: {path}", "green")
    if export:
        emit("Type 'report' to see the full report.", "dim")


def show_accounts(report: Dict[str, Any]) -> None:
    acc = report.get("accounts")
    if acc is None:
        return
    summ = (report.get("sections") or {}).get("scan_summary") or {}
    emit("\n── Username presence ──", "bold")
    found = acc.get("found", [])
    if found:
        for a in found:
            emit(f"  ✔ {sanitize(a['platform']):<28} {link(a['profile_url'])}", "green")
            emit(f"      {a['category']}; existence {a['existence_confidence']} ({sanitize(a['evidence'])}; control check {a['control_check']})", "dim")
    elif acc.get("status") == "offline":
        emit("  Offline mode – no platforms were queried, so nothing can be said about this username.")
    else:
        emit("  No matches found on the platforms ATLAS could check.")
    if summ:
        emit(f"  checked {summ.get('checked')} of {summ.get('platforms_in_list')} platforms · not found {summ.get('not_found')} · "
             f"skipped {summ.get('skipped')} · inconclusive {summ.get('inconclusive_or_error')} · unreliable {summ.get('unreliable_platforms')}", "dim")
    emit("  Same username ≠ same person: results are leads to verify, never identification.", "bold")
    hints = report.get("search_hints") or []
    if hints:
        emit("  Platforms that block automated access (open manually if you have a legitimate need):", "dim")
        for h in hints:
            emit(f"    {sanitize(h['description']).split(' (')[0]:<14} {link(h['url'])}", "dim")


_VERDICT = {"healthy": "OK", "ok_negative_only": "ok*", "stale_rule": "STALE?", "unreliable": "UNRELIABLE",
            "blocked_by_robots": "robots", "unreachable_or_blocked": "blocked", "positive_inconclusive": "?", "error": "error"}


def show_selftest(res: Dict[str, Any]) -> None:
    emit("\n── Platform rule health check ──", "bold")
    if res.get("status") == "offline":
        emit("  Offline mode – nothing was checked."); return
    for w in res.get("warnings", []):
        emit(f"  warning: {w}", "red")
    for r in res["results"]:
        emit(f"  {_VERDICT.get(r['verdict'], r['verdict']):<11} {sanitize(r['platform']):<30} {sanitize(r['note'])}",
             "green" if r["verdict"] == "healthy" else "dim" if r["verdict"].startswith("ok") else "red")
    emit("  Summary: " + ", ".join(f"{k} {v}" for k, v in sorted(res["summary"].items())))
    for rec in res["recommendations"]:
        emit(f"  ! {sanitize(rec)}", "red")
    emit("  ok* = negative control passed but no known-good account exists to confirm positive matches.", "dim")


def show_reports(rows: List[Dict[str, Any]]) -> None:
    if not rows:
        emit("  No stored reports.")
    for r in rows:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(r["modified"]))
        emit(f"  {r['name']}   {when}   {r['bytes']} bytes   ({', '.join(r['files'])})")


def ask_confirm(prompt: str) -> bool:
    """Explicit user permission. Refuses automatically when not interactive."""
    if not sys.stdin.isatty():
        emit("  Cannot ask for permission (non-interactive session); action refused.", "red")
        return False
    try:
        return input(f"  {prompt} [y/N] ").strip().lower() in ("y", "yes")
    except (EOFError, KeyboardInterrupt):
        return False


def split_command(line: str) -> List[str]:
    try:
        return shlex.split(line)
    except ValueError:
        return line.split()


def parse_target_args(tokens: List[str]) -> Tuple[str, Dict[str, Any]]:
    """Parse '<target words> [--type T] [--source URL]... [--platforms FILE]' from interactive input."""
    words, opts = [], {"type": None, "sources": [], "stop_at_first": False, "platforms": None}
    it = iter(tokens)
    for tok in it:
        if tok == "--type":
            opts["type"] = next(it, None)
        elif tok == "--source":
            val = next(it, None)
            if val:
                opts["sources"].append(val)
        elif tok == "--platforms":
            opts["platforms"] = next(it, None)
        elif tok == "--stop-at-first":
            opts["stop_at_first"] = True
        else:
            words.append(tok)
    return " ".join(words), opts
