"""
ATLAS Investigation Engine – core orchestration.

Pipeline: classify -> target module -> finalise (legal assessment, source reliability) -> (optional) export.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import urlparse

from . import __version__
from .classifier import ClassificationResult, TargetType, classify
from .modules.domain_module import investigate_domain
from .modules.ip_module import investigate_ip
from .modules.org_module import investigate_organisation
from .modules.person_module import investigate_person
from .modules.username_module import investigate_username
from .report import export_reports, render_text_report
from .sources import web_pages
from .utils.helpers import is_offline, set_offline, timestamp
from .utils.network_safety import ip_category, validate_url
from .utils.source_reliability import rate_source

logger = logging.getLogger("atlas.agent")

MAX_SOURCES = 5


class AtlasAgent:
    """Accepts a target, classifies it, runs the appropriate modules, produces a report."""

    def __init__(self, output_dir: str = "reports", include_raw: bool = False, offline: bool = False,
                 save: bool = True):
        self.output_dir = output_dir
        self.include_raw = include_raw      # raw RDAP payloads in exports (contacts always redacted)
        self.save = save                    # automatically export after each full investigation
        self.last_report: Optional[Dict[str, Any]] = None
        self.set_offline(offline)

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def set_offline(value: bool) -> None:
        set_offline(value)

    def _context(self, sources: Optional[List[str]], use_wikipedia: bool = True) -> Dict[str, Any]:
        valid, rejected = [], []
        for url in (sources or [])[:MAX_SOURCES]:
            ok, why = validate_url(url)
            if ok:
                host = urlparse(url).hostname or ""
                try:                                    # IP literals can be judged without any lookup
                    if not ip_category(host)["is_global"]:
                        ok, why = False, "non-public IP address"
                except ValueError:
                    pass
            (valid if ok else rejected).append(url if ok else f"{url[:80]} ({why})")
        hosts = sorted({(urlparse(u).hostname or "").lower() for u in valid})
        return {"sources": valid, "official_domains": hosts, "rejected_sources": rejected,
                "use_wikipedia": use_wikipedia}

    # ------------------------------------------------------------------ full investigation
    def investigate(
        self,
        user_input: str,
        progress_callback: Optional[Callable[[str], None]] = None,
        export: bool = True,
        force_type: Optional[TargetType] = None,
        sources: Optional[List[str]] = None,
        html: bool = False,
        use_wikipedia: bool = True,
        stop_at_first: bool = False,
        platforms_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        def progress(msg: str) -> None:
            if progress_callback:
                progress_callback(msg)
            logger.debug(msg)

        web_pages.clear_cache()
        c = classify(user_input, force=force_type)
        progress(f"Received target: {c.original}")
        progress(f"Classified as {c.target_type.name} (confidence {c.confidence:.2f}) – {c.notes}")
        ctx = self._context(sources, use_wikipedia)

        T = TargetType
        if c.target_type == T.IP:
            report = investigate_ip(c.normalised, progress_callback=progress)
        elif c.target_type in (T.DOMAIN, T.URL):
            report = investigate_domain(c.normalised, progress_callback=progress)
        elif c.target_type == T.ORGANISATION:
            report = investigate_organisation(c.normalised, progress_callback=progress)
        elif c.target_type == T.PERSON:
            report = investigate_person(c.normalised, progress_callback=progress,
                                        sources=ctx["sources"], use_wikipedia=use_wikipedia)
        elif c.target_type == T.USERNAME:
            report = investigate_username(c.normalised, progress_callback=progress, stop_at_first=stop_at_first,
                                          platforms_path=platforms_path)
        else:
            report = self._unknown_report(user_input, c)

        report.setdefault("key_findings", [])
        self._finalise(report, c, ctx)
        self.last_report = report

        if export and self.save and "error" not in report:
            self._export(report, progress, html=html)
        return report

    # ------------------------------------------------------------------ internals
    def _unknown_report(self, user_input: str, c: ClassificationResult) -> Dict[str, Any]:
        return {
            "target": user_input, "target_type": "UNKNOWN",
            "error": "Could not classify input with sufficient confidence",
            "suggestion": "Try a clearer IP address, domain name, organisation name, or publicly known person's name, "
                          "or force a type with --type.",
        }

    def _finalise(self, report: Dict[str, Any], c: ClassificationResult, ctx: Dict[str, Any]) -> None:
        report["classification"] = {
            "original_input": c.original, "normalised": c.normalised, "type": c.target_type.name,
            "confidence": c.confidence, "notes": c.notes,
        }
        report["atlas_version"] = __version__
        report["offline"] = is_offline()
        report["completed_at"] = report.get("completed_at") or timestamp()
        for r in ctx.get("rejected_sources", []):
            report.setdefault("limitations", []).append(f"Ignored unsafe/invalid --source URL: {r}")
        # source reliability table
        seen, rows = set(), []
        for s in report.get("sources_used", []):
            s = str(s)
            if s and s not in seen:
                seen.add(s)
                rating, why = rate_source(s)
                rows.append({"source": s, "rating": rating, "rationale": why})
        report["source_reliability"] = rows
        report["legal_assessment"] = self._legal_assessment(c.target_type)

    def _export(self, report: Dict[str, Any], progress, html: bool = False) -> None:
        try:
            paths = export_reports(report, self.output_dir, include_raw=self.include_raw, html=html)
            report["export"] = paths
            for p in paths.values():
                progress(f"Report exported → {p}")
        except Exception as e:
            logger.warning("Export failed: %s", e)
            report["export_error"] = str(e)

    def export_last(self, html: bool = False) -> Dict[str, str]:
        if not self.last_report:
            raise RuntimeError("No report to export.")
        paths = export_reports(self.last_report, self.output_dir, include_raw=self.include_raw, html=html)
        self.last_report["export"] = paths
        return paths

    def _legal_assessment(self, target_type: TargetType) -> Dict[str, Any]:
        base: Dict[str, Any] = {
            "disclaimer": (
                "This assessment is provided for transparency only and is not formal legal advice. Using publicly "
                "available information does not automatically make an investigation lawful: the position depends on "
                "jurisdiction, the purpose of processing, the data involved, how it is collected and used, and the "
                "circumstances. Seek qualified legal advice for your use case."),
            "primary_frameworks_considered": ["UK GDPR", "Data Protection Act 2018",
                                              "Computer Misuse Act 1990", "PECR"],
            "activity_classification": {
                "public_rdap_dns_ct_lookups": {"classification": "Generally permitted public research",
                    "notes": "RDAP, DNS and Certificate Transparency are designed as public data sources."},
                "passive_http_observation": {"classification": "Generally permitted public research",
                    "notes": "Requests to public pages honour robots.txt; a single request is visible in the site's logs."},
                "geolocation_of_public_ip": {"classification": "Generally permitted public research (with caveats)",
                    "notes": "Approximate network location only. An IP can be personal data in context."},
                "blocklist_reputation_checks": {"classification": "Generally permitted public research",
                    "notes": "Standard passive DNS-based blocklist queries; indicators only."},
                "automated_scraping_of_registries_or_social": {"classification": "Potentially restricted or regulated",
                    "notes": "May breach terms or data-protection rules. ATLAS avoids this."},
                "unauthorised_access_or_credential_testing": {"classification": "Not permitted by the system",
                    "notes": "Prohibited under the Computer Misuse Act 1990 and equivalent laws."},
                "collection_of_private_personal_data": {"classification": "Not permitted by the system",
                    "notes": "ATLAS does not seek private addresses, phones, accounts, credentials or residential locations."},
                "facial_recognition_or_reverse_image_search": {"classification": "Not permitted by the system",
                    "notes": "Not implemented; ATLAS never identifies people from images."},
            },
        }
        if target_type == TargetType.USERNAME:
            base["activity_classification"]["username_account_enumeration"] = {
                "classification": "Requires careful assessment; purpose and proportionality matter",
                "notes": "Checks only whether a public profile page exists for an exact username on platforms that permit "
                         "automated access (robots.txt honoured). A username can be personal data; do not use results to "
                         "identify, locate, monitor or harass an individual."}
        if target_type == TargetType.PERSON:
            base["activity_classification"]["person_focused_research"] = {
                "classification": "Requires careful assessment; a lawful basis is needed",
                "notes": "Information about an identifiable living individual is personal data even when public; "
                         "UK GDPR principles (purpose limitation, minimisation, accuracy, storage limitation) apply."}
        return base

    def render_last_report(self) -> str:
        if not self.last_report:
            return "No report available."
        return render_text_report(self.last_report)
