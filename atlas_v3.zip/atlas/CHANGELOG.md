# Changelog

## 3.0.0  – "lean, wider, more accurate"

### Removed (a full 2.1 snapshot was kept separately)
- VPN manager (`vpn` commands, tkinter window, platform detection), public-image discovery and the local gallery, and the approximate-location module.
  IP geolocation remains as network information inside IP reports. Reports now have 10 sections (was 12).

### Added – wider public reach (all keyless)
- **Wikidata** for people and organisations: disambiguation (candidate lists instead of guesses), community-recorded **official website**, occupation and employer (professional facts only).
- **Internet Archive** web history for domains (first/last capture, months with captures).
- **Related domains** from certificate co-listing (shared CDN certificates excluded) and **organisation certificate search** (`crt.sh O=`), both labelled LOW-confidence leads.
- **Provider inference** from DNS (email, DNS and sending services).
- **Username search: 79 platforms** in an editable `atlas/data/platforms.json`, `--platforms FILE` for your own list (validated; dating/adult/messaging/health/finance refused), more mastodon instances, Bluesky, GitLab, Codeforces, Minecraft, blogging/creative/gaming sites.

### Added – accuracy
- Username: soft-404 page detection, **two** control checks, username-in-page signal, graded HIGH/MEDIUM/LOW confidence, per-platform `absent_codes`, empty-JSON detection, and **`selftest`** (negative control + known-good accounts) to find stale/unreliable rules.
- Network: bounded retry for transient failures (429/502/503/504, connection errors); `Retry-After` above 5 s is respected by not retrying.
- IP: **two-provider geolocation cross-check** (ipinfo.io + ipwho.is over HTTPS) with explicit agreement/disagreement and confidence derived from it; registry-vs-geolocation country check.
- Organisations: candidate websites are **verified against the site's own name** (whole title segment for one-word names); unrelated look-alikes are labelled as such; more candidate TLDs (.co.uk, .org, .net); Wikidata site preferred over guessing.

### Changed
- Username page reads are capped at 100 KB and used only for two booleans (nothing stored).
- Test suite: 183 offline tests (removed-feature tests dropped; new tests for every addition).

### Fixed (found by the new tests)
- Organisation module: a local import shadowed `urlparse`; Wikidata sites are now fetched at their recorded URL.
- One-word organisation names accepted any page containing that word ("Example Widgets" for "Example Corp").


## 2.1.0

### Added
- **Username presence checks** (`username <name>`, `@name`, or a bare handle such as `john_smith99`; `--type username`; `--stop-at-first`).
  ATLAS requests ONE public profile/API URL per platform for the exact username (28 mainstream developer, community, creative and gaming platforms)
  and reports where a public profile exists.
  - **Control check:** when a name looks "found", a random name that cannot exist is tested on the same platform; if that also looks found the
    platform is reported as *unreliable* instead of producing a false match.
  - **Existence only:** no profile content is read or stored; status checks download no response body.
  - **Same username ≠ same person:** every match is labelled identity UNVERIFIED and the warning appears in the terminal, every report and the limitations.
  - robots.txt is honoured (platforms that disallow automated access are listed as skipped); usernames are validated per platform before any request;
    no spelling variants are tried; no dating, adult, messaging, health or finance platforms are included.
  - Platforms that block automated access (Instagram, X, TikTok, Facebook, LinkedIn, Reddit, YouTube, Threads, Pinterest) are never queried;
    manual links are printed for you to open yourself.
  - Per-platform outcomes: found / not found / unreliable / inconclusive (blocked, rate-limited, redirected) / skipped (robots, format) / error.
- New files: `sources/username_sources.py`, `modules/username_module.py`, `tests/test_username.py` (27 tests; 186 in total).

### Changed
- Reports for IP and username targets now say images are "Not applicable" (instead of "not run").
- Classifier: `@handle` and single tokens containing a digit or underscore are treated as usernames (low confidence; override with `--type`).

## 2.0.0

### Added
- **Public image discovery** (`images <target>`, `--no-images`, `--gallery`): finds image *references* via Open Graph, Twitter Card,
  `link rel=image_src` and JSON-LD; header-only validation (type allow-list, 8 MB cap, no SVG); licence/attribution hints;
  every image labelled **verified / probable / unverified** with a reason; images are linked, never downloaded or re-hosted.
- **Local HTML image gallery** (`gallery` command / `--gallery`), opened with `webbrowser` + `pathlib`; no JavaScript, strict CSP.
- **Approximate location module** (`location <target>`): coarse IP network location (LOW), hosting-network location for domains,
  and organisation-level published locations from JSON-LD (locality/region/country only). Each finding carries source, date accessed,
  precision, confidence (HIGH/MEDIUM/LOW/UNVERIFIED) and limitations. Standard message when nothing is verified.
- **VPN Manager** (`vpn status|connect|disconnect|gui`): adapters for Windows (PowerShell + `rasdial`), Linux (NetworkManager `nmcli`)
  and macOS (`scutil --nc`); terminal dashboard and optional tkinter window; explicit permission before any change;
  status verified against the OS after each action.
- **Person module upgrade**: Wikipedia summary (public endpoint) and user-supplied official pages (`--source URL`, max 5) →
  biography, roles, affiliations, education, achievements with per-source reliability; ambiguity detection; identity confidence
  capped below HIGH; published-interview limitation stated honestly.
- **IP module upgrade**: category detection (private, loopback, link-local, multicast, reserved, unspecified, documentation, CGNAT),
  IPv4-mapped IPv6, hosting/data-centre indicators, ASN, uncertainty warnings, zero network traffic for non-public addresses.
- **Report system**: 12-section structure shared by TXT / HTML / JSON; per-finding sources; source-reliability table;
  `--html`, `--no-save`, `--raw`; owner-only file permissions.
- **Retention controls**: `reports list|delete <name|all>|purge <days>`, `--list-reports`, `--delete-reports`, `--purge-older-than`.
- **Offline mode** (`--offline`, `offline on|off`): no sockets, no DNS, no lookups of any kind.
- **robots.txt support** (it was promised in 1.x but not implemented): checked before page and image access; unverifiable ⇒ not fetched.
- New files: `utils/network_safety.py`, `utils/html_gallery.py`, `utils/platform_detection.py`, `utils/source_reliability.py`,
  `utils/retention.py`, `sources/image_discovery.py`, `sources/location_sources.py`, `sources/page_metadata.py`,
  `sources/wikimedia.py`, `modules/image_module.py`, `modules/location_module.py`, `modules/vpn_module.py`, `vpn_gui.py`, `tests/`.

### Changed
- **Standard library only.** Removed `requests`, `dnspython`, `rich`, `beautifulsoup4`. ATLAS now includes a strict stdlib DNS client
  (UDP+TCP fallback, compression-loop protection, ID/question validation) and plain ANSI colouring.
- **Data minimisation:** geolocation no longer requests or keeps latitude/longitude/postcodes; exports and renders scrub those keys.
- HTTP layer rewritten on `http.client`: validated-IP connection pinning (anti DNS-rebinding), per-hop redirect validation,
  port/scheme/credential restrictions, body-size and total-time caps.
- CLI: `investigate`, `images`, `location`, `vpn`, `reports`; options may appear before or between target words (`parse_intermixed_args`).
- Terminal output strips control characters from all text (blocks escape-sequence injection from remote pages).
- Geolocation prefers HTTPS (`ipinfo.io`); cleartext `ip-api.com` is a flagged fallback only.

### Fixed (carried from 1.1.0 and new)
- Classifier: whole-word organisation matching, URL credentials/ports/IPv6, IP-host URLs, quoted names; credentials redacted from reports.
- Certificate-transparency filter accepted look-alikes (`evilexample.com`).
- Blocklist "query refused" (127.255.255.x) was reported as a listing; IPv6 support; defunct SORBS removed.
- RDAP registry fallbacks used only for matching TLDs; contact fields redacted from exports.
- DNS client raised `UnicodeError` instead of `DNSError` for over-long labels (found by the new tests).
- Report links swallowed a trailing `]`; `report` command rendered unscrubbed data.
- `--source` pointing at a private IP literal is now rejected up front and reported.

## 1.1.0
Bug-fix release (classifier, CT filter, blocklists, RDAP, UI duplication, export timestamps) – see git history.

## 1.0.0
Initial release.
