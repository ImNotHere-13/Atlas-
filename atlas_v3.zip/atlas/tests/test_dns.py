import struct, unittest
from tests.helpers import ns
from atlas.sources import dns_lookup as d


def _resp(txid=0x1234, answers=b"", an=0, flags=0x8180):
    _, pkt = d.build_query("example.com", 1, txid=txid)
    return struct.pack(">HHHHHH", txid, flags, 1, an, 0, 0) + pkt[12:] + answers


class DNSClient(unittest.TestCase):
    def test_parse_a_and_mx_with_compression(self):
        a = b"\xc0\x0c" + struct.pack(">HHIH", 1, 1, 60, 4) + bytes([93, 184, 216, 34])
        mx_rdata = struct.pack(">H", 10) + b"\x04mail\xc0\x0c"
        a += b"\xc0\x0c" + struct.pack(">HHIH", 15, 1, 60, len(mx_rdata)) + mx_rdata
        rcode, trunc, ans = d.parse_response(_resp(answers=a, an=2), 0x1234)
        self.assertEqual((rcode, trunc), (0, False))
        self.assertEqual(ans, [("A", "93.184.216.34"), ("MX", "10 mail.example.com")])

    def test_txt_and_caa(self):
        txt = b"\x05hello\x06 world"
        caa = bytes([0, 5]) + b"issue" + b"letsencrypt.org"
        a = (b"\xc0\x0c" + struct.pack(">HHIH", 16, 1, 1, len(txt)) + txt +
             b"\xc0\x0c" + struct.pack(">HHIH", 257, 1, 1, len(caa)) + caa)
        _, _, ans = d.parse_response(_resp(answers=a, an=2), 0x1234)
        self.assertEqual(ans[0], ("TXT", "hello world"))
        self.assertEqual(ans[1], ("CAA", '0 issue "letsencrypt.org"'))

    def test_malformed_inputs_raise_dnserror_not_crash(self):
        good = _resp(answers=b"\xc0\x0c" + struct.pack(">HHIH", 1, 1, 60, 4) + b"\x01\x02\x03\x04", an=1)
        cases = [b"", b"\x00" * 5, good[:20], good[:-2],                         # truncated
                 _resp(txid=0x9999),                                               # id mismatch
                 _resp(flags=0x0100),                                              # not a response
                 struct.pack(">HHHHHH", 0x1234, 0x8180, 1, 0, 0, 0) + b"\xc0\x0c" + b"\0\1\0\1",  # pointer loop
                 _resp(answers=b"\xc0\x0c" + struct.pack(">HHIH", 1, 1, 60, 500), an=1)]  # rdlen overruns
        for c in cases:
            with self.assertRaises(d.DNSError, msg=c[:12]):
                d.parse_response(c, 0x1234)

    def test_label_validation(self):
        with self.assertRaises(d.DNSError):
            d.build_query("a" * 70 + ".com", 1)

    def test_nameserver_parsing(self):
        import tempfile, os
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".conf") as f:
            f.write("# c\nnameserver 192.0.2.1\nnameserver fe80::1%eth0\nsearch x\n")
        try:
            self.assertEqual(d.get_system_nameservers(f.name), ["192.0.2.1", "fe80::1"])
        finally:
            os.unlink(f.name)
        self.assertEqual(d.get_system_nameservers("/nonexistent/resolv.conf"), [])

    def test_offline(self):
        ns.set_offline(True)
        try:
            r = d.get_dns_records("example.com")
            self.assertFalse(r["success"])
            self.assertIn("offline", r["errors"][0])
        finally:
            ns.set_offline(False)


if __name__ == "__main__":
    unittest.main()
