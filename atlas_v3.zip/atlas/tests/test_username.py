import json, re, unittest
from unittest import mock
from tests.helpers import FakeWeb, ns, patch_agent_network
from atlas.agent import AtlasAgent
from atlas.classifier import TargetType as T, classify, parse_forced_type
from atlas.modules.username_module import IDENTITY_WARNING, investigate_username
from atlas.sources import username_sources as us
from atlas.sources.username_sources import Platform, check_platform, validate_username

GH = Platform("Alpha", "developer", "https://alpha.example/{}")
MSG = Platform("Beta", "community", "https://beta.example/user?id={}", kind="message", absent_text="No such user.")
JS = Platform("Gamma", "community", "https://gamma.example/api?u={}", kind="json", profile_url="https://gamma.example/u/{}",
              exists_path=("users", 0, "id"), absent_path=("users", 0, "missing"))
FMT = Platform("Delta", "gaming", "https://delta.example/{}", pattern=r"^[a-z]{3}$")


class Validation(unittest.TestCase):
    def test_usernames(self):
        for ok in ("jdoe", "a", "john.smith_99", "A-b", "x" * 39):
            self.assertTrue(validate_username(ok)[0], ok)
        for bad in ("", "-x", ".x", "a b", "a/b", "../x", "a?b=c", "a#b", "a:b@c", "x" * 40, "é", "a\nb", "%2e", "a\x00"):
            self.assertFalse(validate_username(bad)[0], repr(bad))

    def test_classification(self):
        for s, norm in (("@jdoe_42", "jdoe_42"), ("john_smith99", "john_smith99"), ("@john.smith", "john.smith")):
            r = classify(s); self.assertEqual((r.target_type, r.normalised), (T.USERNAME, norm), s)
        for s, t in (("Microsoft", T.ORGANISATION), ("Tim Cook", T.PERSON), ("example.com", T.DOMAIN), ("8.8.8.8", T.IP),
                     ("Apple Inc", T.ORGANISATION), ("john.smith", T.DOMAIN)):
            self.assertEqual(classify(s).target_type, t, s)
        self.assertEqual(classify("jdoe", parse_forced_type("username")).target_type, T.USERNAME)
        self.assertEqual(classify("@jdoe", parse_forced_type("handle")).normalised, "jdoe")
        self.assertEqual(classify("a b", parse_forced_type("username")).target_type, T.UNKNOWN)

    def test_default_platform_list_policy(self):
        names = [p.name for p in us.PLATFORMS]
        self.assertEqual(len(names), len(set(names)))
        banned = re.compile(r"dating|adult|porn|tinder|grindr|onlyfans|whatsapp|telegram|signal|snapchat|bank|health", re.I)
        for p in us.PLATFORMS:
            self.assertTrue(p.url.startswith("https://"), p.name)
            self.assertEqual(p.url.count("{}"), 1, p.name)
            self.assertNotIn(p.category, us.EXCLUDED_CATEGORIES, p.name)
            self.assertFalse(banned.search(p.name + p.url), p.name)
            if p.kind == "message": self.assertTrue(p.absent_text, p.name)
            if p.kind == "json": self.assertTrue(p.exists_path or p.absent_path, p.name)
        manual = " ".join(n for n, _ in us.MANUAL_LINKS)
        self.assertIn("Instagram", manual)
        self.assertFalse({n for n, _ in us.MANUAL_LINKS} & set(names))        # blocked sites are never queried

    def test_url_building_quotes_username(self):
        self.assertEqual(us._fill("https://a.example/{}", "x.y_z-1"), "https://a.example/x.y_z-1")
        self.assertEqual(us._fill("https://a.example/{}", "a/b"), "https://a.example/a%2Fb")    # cannot add a path segment


class PlatformChecks(unittest.TestCase):
    def test_status_found_with_clean_control(self):
        with FakeWeb() as web:
            web.add("https://alpha.example/jdoe", "<html>profile</html>")
            r = check_platform(GH, "jdoe")
        self.assertEqual((r["status"], r["control_check"]), ("found", "passed"))
        self.assertEqual(r["profile_url"], "https://alpha.example/jdoe")

    def test_body_is_capped_and_page_content_is_not_kept(self):
        with FakeWeb() as web, mock.patch.object(ns, "_single_request", wraps=web._single) as sp:
            web.add("https://alpha.example/jdoe", "<title>jdoe</title><p>bio: lives in Leeds</p>")
            r = check_platform(GH, "jdoe")
        calls = [c for c in sp.call_args_list if c[0][0].startswith("https://alpha.example/jdoe")]
        self.assertTrue(calls and all(c[0][5] <= 100_000 for c in calls))        # max_bytes cap
        self.assertNotIn("Leeds", json.dumps(r))

    def test_not_found(self):
        with FakeWeb():
            self.assertEqual(check_platform(GH, "jdoe")["status"], "not_found")

    def test_message_kind(self):
        with FakeWeb() as web:
            web.add("https://beta.example/user?id=jdoe", "<p>karma: 5</p>")
            web.add("https://beta.example/user?id=nobody", "<p>No such user.</p>")
            self.assertEqual(check_platform(MSG, "jdoe")["status"], "found")
            self.assertEqual(check_platform(MSG, "nobody")["status"], "not_found")

    def test_json_kind_and_human_profile_url(self):
        with FakeWeb() as web:
            web.add("https://gamma.example/api?u=jdoe", json.dumps({"users": [{"id": 7, "name": "jdoe"}]}), ctype="application/json")
            web.add("https://gamma.example/api?u=ghost", json.dumps({"users": [{"missing": ""}]}), ctype="application/json")
            web.add("https://gamma.example/api?u=weird", "not json", ctype="application/json")
            web.add("https://gamma.example/api?u=odd", json.dumps({"other": 1}), ctype="application/json")
            r = check_platform(JS, "jdoe")
            self.assertEqual((r["status"], r["profile_url"]), ("found", "https://gamma.example/u/jdoe"))
            self.assertEqual(check_platform(JS, "ghost")["status"], "not_found")
            self.assertEqual(check_platform(JS, "weird")["status"], "inconclusive")
            self.assertEqual(check_platform(JS, "odd")["status"], "inconclusive")

    def test_soft_404_platform_is_marked_unreliable_not_found(self):
        with FakeWeb(default=(200, {"content-type": "text/html"}, b"<html>app shell</html>")):
            r = check_platform(GH, "jdoe")
        self.assertEqual((r["status"], r["control_check"]), ("unreliable", "failed"))

    def test_inconclusive_and_errors(self):
        for code in (403, 429, 500, 503):
            with FakeWeb() as web:
                web.add("https://alpha.example/jdoe", "", status=code)
                self.assertEqual(check_platform(GH, "jdoe")["status"], "inconclusive", code)
        with FakeWeb() as web:                       # robots.txt fine, profile request itself fails -> error
            def fail_profile(url, *a):
                if url.endswith("/robots.txt"):
                    return web._single(url, *a)
                raise OSError("boom")
            with mock.patch.object(ns, "_single_request", side_effect=fail_profile):
                self.assertEqual(check_platform(GH, "jdoe")["status"], "error")
        with FakeWeb(), mock.patch.object(ns, "_single_request", side_effect=OSError("boom")):
            # nothing is reachable, so robots.txt cannot be verified either: skipped, never assumed allowed
            self.assertEqual(check_platform(GH, "jdoe")["status"], "skipped_robots")

    def test_redirect_to_other_page_is_inconclusive_but_case_canonicalisation_is_fine(self):
        with FakeWeb() as web:
            web.add("https://alpha.example/jdoe", "", 302, headers={"location": "/login"})
            web.add("https://alpha.example/login", "login page")
            self.assertEqual(check_platform(GH, "jdoe")["status"], "inconclusive")
        with FakeWeb() as web:
            web.add("https://alpha.example/JDoe", "", 301, headers={"location": "/jdoe"})
            web.add("https://alpha.example/jdoe", "profile")
            self.assertEqual(check_platform(GH, "JDoe")["status"], "found")

    def test_robots_disallow_means_no_profile_request(self):
        with FakeWeb() as web:
            web.add("https://alpha.example/robots.txt", "User-agent: *\nDisallow: /\n", ctype="text/plain")
            web.add("https://alpha.example/jdoe", "profile")
            r = check_platform(GH, "jdoe")
            self.assertEqual(r["status"], "skipped_robots")
            self.assertNotIn(("GET", "https://alpha.example/jdoe"), web.requests)

    def test_incompatible_format_makes_no_request(self):
        with FakeWeb() as web:
            r = check_platform(FMT, "jdoe_42")
            self.assertEqual(r["status"], "skipped_format"); self.assertEqual(web.requests, [])

    def test_offline(self):
        ns.set_offline(True)
        try:
            self.assertEqual(check_platform(GH, "jdoe")["status"], "offline")
        finally:
            ns.set_offline(False)

    def test_never_contacts_non_public_hosts(self):
        with FakeWeb(resolver=lambda h: ["10.0.0.1"]) as web:
            self.assertEqual(check_platform(GH, "jdoe")["status"], "error"); self.assertEqual(web.requests, [])


class ModuleReport(unittest.TestCase):
    PLATS = [GH, MSG, JS, FMT, Platform("Epsilon", "creative", "https://eps.example/{}")]

    def web(self):
        web = FakeWeb()
        web.__enter__(); self.addCleanup(web.__exit__, None, None, None)
        web.add("https://alpha.example/jdoe", "p")
        web.add("https://beta.example/user?id=jdoe", "p")
        web.add("https://eps.example/jdoe", "", status=429)
        return web

    def test_report_structure_and_honest_statuses(self):
        web = self.web()
        r = investigate_username("@jdoe", platforms=self.PLATS)
        self.assertEqual((r["target"], r["target_type"]), ("jdoe", "USERNAME"))
        found = {a["platform"]: a for a in r["accounts"]["found"]}
        self.assertEqual(set(found), {"Alpha", "Beta"})
        for a in found.values():
            self.assertEqual(a["identity_confidence"], "UNVERIFIED"); self.assertEqual(a["existence_confidence"], "MEDIUM")
            self.assertTrue(a["profile_url"].startswith("https://"))
        s = r["sections"]["scan_summary"]
        self.assertEqual((s["matches"], s["not_found"], s["skipped"], s["inconclusive_or_error"]), (2, 1, 1, 1))
        self.assertEqual(r["confidence_summary"]["identity_linkage"]["level"], "UNVERIFIED")
        self.assertTrue(any("does NOT show" in l for l in r["limitations"]))
        self.assertTrue(all(f["source"] for f in r["key_findings"]))
        self.assertTrue(any("Epsilon" in l for l in r["limitations"]))                # inconclusive named

    def test_manual_links_listed_but_never_fetched(self):
        web = self.web()
        r = investigate_username("jdoe", platforms=self.PLATS)
        urls = [h["url"] for h in r["search_hints"]]
        self.assertTrue(any("instagram.com/jdoe" in u for u in urls))
        fetched = " ".join(u for _, u in web.requests)
        for host in ("instagram", "x.com", "tiktok", "facebook", "linkedin", "reddit", "youtube"):
            self.assertNotIn(host, fetched)

    def test_no_match_is_reported_honestly(self):
        with FakeWeb():
            r = investigate_username("jdoe", platforms=self.PLATS)
        self.assertEqual(r["accounts"]["found"], [])
        self.assertIn("No match", r["key_findings"][0]["finding"])
        self.assertEqual(r["confidence_summary"]["account_existence"]["level"], "LOW")

    def test_stop_at_first(self):
        web = self.web()
        r = investigate_username("jdoe", platforms=[GH] + [Platform(f"P{i}", "x", f"https://p{i}.example/{{}}") for i in range(20)],
                                 stop_at_first=True, max_workers=1)
        self.assertEqual(len(r["accounts"]["found"]), 1)
        self.assertTrue(r["sections"]["scan_summary"]["stopped_at_first_match"])
        self.assertLess(r["accounts"]["checked"], 21)
        self.assertTrue(any("stopped at the first match" in l.lower() for l in r["limitations"]))

    def test_one_crashing_platform_does_not_sink_the_scan(self):
        web = self.web()
        real = us.check_platform
        def flaky(p, u):
            if p.name == "Beta": raise RuntimeError("boom")
            return real(p, u)
        with mock.patch("atlas.modules.username_module.check_platform", side_effect=flaky):
            r = investigate_username("jdoe", platforms=self.PLATS)
        self.assertEqual([a["platform"] for a in r["accounts"]["found"]], ["Alpha"])
        self.assertTrue(any(x["platform"] == "Beta" for x in r["accounts"]["inconclusive"]))

    def test_invalid_username_makes_no_requests(self):
        with FakeWeb() as web:
            for bad in ("a b", "../etc", "", "x" * 50):
                r = investigate_username(bad, platforms=self.PLATS)
                self.assertIn("Invalid username", r["error"])
            self.assertEqual(web.requests, [])

    def test_offline(self):
        ns.set_offline(True)
        try:
            with mock.patch.object(ns, "_single_request", side_effect=AssertionError("network used")):
                r = investigate_username("jdoe")
        finally:
            ns.set_offline(False)
        self.assertEqual(r["accounts"]["status"], "offline"); self.assertEqual(r["accounts"]["found"], [])

    def test_no_profile_content_is_stored(self):
        web = self.web()
        web.add("https://alpha.example/jdoe", "<h1>Jane Doe</h1> bio: lives in Leeds, email jane@x.y")
        blob = json.dumps(investigate_username("jdoe", platforms=[GH]))
        for banned in ("Jane Doe", "Leeds", "jane@x.y"):
            self.assertNotIn(banned, blob)


class AgentAndCLI(unittest.TestCase):
    def test_agent_flow_with_default_platforms_and_export(self):
        import tempfile, os
        with tempfile.TemporaryDirectory() as d, FakeWeb() as web:
            web.add("https://github.com/jdoe_42", "x")      # GitHub rejects underscores -> skipped_format; try a valid one
            web.add("https://codeberg.org/jdoe_42", "profile")
            r = AtlasAgent(output_dir=d).investigate("@jdoe_42", html=True)
            self.assertEqual(r["target_type"], "USERNAME")
            self.assertEqual([a["platform"] for a in r["accounts"]["found"]], ["Codeberg"])
            gh = next(x for x in r["accounts"]["skipped"] if x["platform"] == "GitHub")
            self.assertEqual(gh["status"], "skipped_format")
            self.assertNotIn("images", r); self.assertNotIn("location", r)
            self.assertEqual(r["accounts"]["platform_list"], "built-in list")
            txt = open(r["export"]["txt"], encoding="utf-8").read()
            self.assertIn("MATCH – Codeberg", txt); self.assertIn("same person", txt)
            self.assertIn("username_account_enumeration", r["legal_assessment"]["activity_classification"])
            html = open(r["export"]["html"], encoding="utf-8").read()
            self.assertNotIn("<script", html.lower()); self.assertIn("https://codeberg.org/jdoe_42", html)


    def test_cli_and_interactive(self):
        import contextlib, io, tempfile
        import main as m
        def run(argv):
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                try: code = m.main(argv)
                except SystemExit as e: code = e.code
            return code, out.getvalue()
        self.addCleanup(lambda: ns.set_offline(False))
        with FakeWeb() as web:
            web.add("https://codeberg.org/jdoe", "p")
            code, out = run(["username", "jdoe", "--no-save", "--no-report", "--stop-at-first"])
            self.assertEqual(code, 0); self.assertIn("Username presence", out); self.assertIn("https://codeberg.org/jdoe", out)
            self.assertIn("Same username", out); self.assertIn("instagram.com/jdoe", out)
            code, out = run(["@jdoe", "--no-save", "--no-report"])
            self.assertIn("Classified as USERNAME", out)
        code, out = run(["username", "bad name", "--no-save"]); self.assertEqual(code, 1)
        code, out = run(["username", "--offline", "jdoe", "--no-save", "--no-report"]); self.assertEqual(code, 0)
        self.assertIn("nothing can be said", out); self.assertNotIn("No matches", out)
        lines = iter(["username", "username jdoe --stop-at-first", "exit"])
        with mock.patch("builtins.input", side_effect=lambda *a: next(lines)), contextlib.redirect_stdout(io.StringIO()) as o, \
             FakeWeb():
            m.run_interactive(m.AtlasAgent(output_dir=tempfile.mkdtemp(), save=False))
        self.assertIn("Usage: username", o.getvalue()); self.assertIn("Username presence", o.getvalue())


if __name__ == "__main__":
    unittest.main()
