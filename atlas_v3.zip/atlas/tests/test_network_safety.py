import http.server, threading, unittest
import unittest.mock
from tests.helpers import FakeWeb, ns, PUBLIC_IP


class IPCategories(unittest.TestCase):
    def test_categories(self):
        table = {"8.8.8.8": "public", "10.1.1.1": "private", "192.168.0.1": "private", "127.0.0.1": "loopback",
                 "169.254.1.1": "link-local", "224.0.0.1": "multicast", "0.0.0.0": "unspecified",
                 "100.64.1.1": "shared-address-space", "192.0.2.5": "documentation", "240.0.0.1": "reserved",
                 "::1": "loopback", "fe80::1": "link-local", "ff02::1": "multicast", "fc00::1": "private",
                 "2001:db8::1": "documentation", "2606:4700::1111": "public", "::ffff:8.8.8.8": "public",
                 "::ffff:10.0.0.1": "private"}
        for ip, cat in table.items():
            self.assertEqual(ns.ip_category(ip)["category"], cat, ip)

    def test_invalid(self):
        with self.assertRaises(ValueError):
            ns.ip_category("999.1.1.1")


class URLValidation(unittest.TestCase):
    def test_rejected(self):
        for u in ("", "ftp://a.com", "file:///etc/passwd", "javascript:alert(1)", "data:text/html,x", "http://a b.com",
                  "https://u:p@a.com/", "http://a.com:22/", "http://", "http://a.com/\x00", "https://a.com/" + "x" * 3000):
            self.assertFalse(ns.validate_url(u)[0], u)

    def test_accepted(self):
        for u in ("https://a.com/x?y=1", "http://a.com:8080/", "https://[2606:4700::1111]/"):
            self.assertTrue(ns.validate_url(u)[0], u)


class SafeRequest(unittest.TestCase):
    def test_refuses_private_literals(self):
        for u in ("http://127.0.0.1/", "http://10.0.0.5/x", "http://[::1]/", "http://169.254.169.254/latest/meta-data/",
                  "http://192.168.1.1/", "http://0.0.0.0/"):
            resp, err = ns.safe_request(u)
            self.assertIsNone(resp, u)
            self.assertIn("refused", err)

    def test_hostname_resolving_to_private_refused(self):
        with FakeWeb(resolver=lambda h: ["10.0.0.9"]) as web:
            resp, err = ns.safe_request("http://internal.example/")
            self.assertIsNone(resp)
            self.assertIn("non-public", err)
            self.assertEqual(web.requests, [])

    def test_mixed_resolution_refused(self):
        with FakeWeb(resolver=lambda h: [PUBLIC_IP, "127.0.0.1"]):
            self.assertIsNone(ns.safe_request("http://rebind.example/")[0])

    def test_redirect_to_private_blocked(self):
        def resolver(h):
            return ["127.0.0.1"] if h == "evil.internal" else [PUBLIC_IP]
        with FakeWeb(resolver=resolver) as web:
            web.add("http://a.example/", "", 302, headers={"location": "http://evil.internal/admin"})
            resp, err = ns.safe_request("http://a.example/")
            self.assertIsNone(resp)
            self.assertIn("refused", err)

    def test_redirect_to_file_scheme_blocked(self):
        with FakeWeb() as web:
            web.add("http://a.example/", "", 302, headers={"location": "file:///etc/passwd"})
            resp, err = ns.safe_request("http://a.example/")
            self.assertIsNone(resp)
            self.assertIn("unsupported scheme", err)

    def test_redirect_loop_capped(self):
        with FakeWeb() as web:
            web.add("http://a.example/", "", 302, headers={"location": "http://a.example/"})
            self.assertIn("too many redirects", ns.safe_request("http://a.example/")[1])

    def test_relative_redirect_followed(self):
        with FakeWeb() as web:
            web.add("http://a.example/", "", 301, headers={"location": "/final"})
            web.add("http://a.example/final", "ok")
            resp, err = ns.safe_request("http://a.example/")
            self.assertEqual(resp.text, "ok")

    def test_offline_mode(self):
        with FakeWeb() as web:
            ns.set_offline(True)
            resp, err = ns.safe_request("https://a.example/")
            self.assertIsNone(resp)
            self.assertIn("offline", err)
            self.assertEqual(web.requests, [])

    def test_offline_resolution_returns_nothing(self):
        ns.set_offline(True)
        try:
            self.assertEqual(ns.resolve_hostname("localhost"), [])
        finally:
            ns.set_offline(False)


class Robots(unittest.TestCase):
    def test_disallowed(self):
        with FakeWeb() as web:
            web.add("https://a.example/robots.txt", "User-agent: *\nDisallow: /private\n", ctype="text/plain")
            web.add("https://a.example/private/x", "secret")
            web.add("https://a.example/public", "fine")
            self.assertIsNone(ns.safe_request("https://a.example/private/x", respect_robots=True)[0])
            self.assertEqual(ns.safe_request("https://a.example/public", respect_robots=True)[0].text, "fine")

    def test_specific_agent_blocked(self):
        with FakeWeb() as web:
            web.add("https://a.example/robots.txt", "User-agent: ATLAS-OSINT\nDisallow: /\n", ctype="text/plain")
            web.add("https://a.example/", "x")
            resp, err = ns.safe_request("https://a.example/", respect_robots=True)
            self.assertIsNone(resp)
            self.assertIn("robots", err)

    def test_missing_robots_allows(self):
        with FakeWeb() as web:
            web.add("https://a.example/", "x")
            self.assertIsNotNone(ns.safe_request("https://a.example/", respect_robots=True)[0])

    def test_robots_server_error_is_conservative(self):
        with FakeWeb() as web:
            web.add("https://a.example/robots.txt", "", 503)
            web.add("https://a.example/", "x")
            self.assertIsNone(ns.safe_request("https://a.example/", respect_robots=True)[0])

    def test_robots_unreachable_is_conservative(self):
        with FakeWeb() as web:
            with unittest.mock.patch.object(ns, "_single_request", side_effect=OSError("boom")):
                self.assertIsNone(ns.safe_request("https://a.example/", respect_robots=True)[0])


class _Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if self.path == "/big":
            self.send_response(200); self.send_header("Content-Type", "text/plain"); self.end_headers()
            for _ in range(50):
                self.wfile.write(b"x" * 100_000)
        else:
            self.send_response(200); self.send_header("Content-Type", "text/plain")
            self.send_header("X-Host", self.headers.get("Host", "")); self.end_headers(); self.wfile.write(b"hello")


class RealSocketBehaviour(unittest.TestCase):
    """Exercise the real pinned-connection code against a loopback server."""
    @classmethod
    def setUpClass(cls):
        class Quiet(http.server.ThreadingHTTPServer):
            def handle_error(self, *a):          # clients closing early (body-cap test) is expected
                pass
        cls.srv = Quiet(("127.0.0.1", 0), _Handler)
        cls.port = cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown(); cls.srv.server_close()

    def test_connection_is_pinned_to_validated_ip(self):
        # The hostname does not resolve anywhere; the pinned IP is what gets connected to.
        r = ns._single_request(f"http://pinned.invalid:{self.port}/", "GET", {}, 5, ["127.0.0.1"], 10_000, True)
        self.assertEqual(r.text, "hello")
        self.assertTrue(r.header("X-Host").startswith("pinned.invalid"))

    def test_body_cap(self):
        r = ns._single_request(f"http://x.invalid:{self.port}/big", "GET", {}, 5, ["127.0.0.1"], 250_000, True)
        self.assertTrue(r.truncated)
        self.assertEqual(len(r.content), 250_000)

    def test_headers_only_probe_reads_no_body(self):
        r = ns._single_request(f"http://x.invalid:{self.port}/", "GET", {}, 5, ["127.0.0.1"], 10, False)
        self.assertEqual((r.status_code, r.content), (200, b""))

    def test_connection_failure_raises(self):
        with self.assertRaises(OSError):
            ns._single_request("http://x.invalid:9/", "GET", {}, 2, ["127.0.0.1"], 10, True)


if __name__ == "__main__":
    unittest.main()
