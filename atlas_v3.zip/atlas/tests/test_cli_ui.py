import contextlib, io, os, tempfile, unittest
from unittest import mock
from tests.helpers import FakeWeb, ns
import main as atlas_main
from atlas import ui


def run(argv, stdin=None):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = atlas_main.main(argv)
        except SystemExit as e:
            code = e.code
    return code, out.getvalue(), err.getvalue()


class OriginalCLIStillWorks(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.addCleanup(lambda: ns.set_offline(False))

    def test_dash_t_form(self):
        code, out, _ = run(["-t", "10.0.0.1", "--no-report", "-o", self.tmp.name])
        self.assertEqual(code, 0); self.assertIn("Classified as IP", out)
        self.assertEqual(len(os.listdir(self.tmp.name)), 2)

    def test_investigate_form_unquoted_multiword(self):
        code, out, _ = run(["investigate", "Tim", "Cook", "--offline", "--no-report", "-o", self.tmp.name])
        self.assertEqual(code, 0); self.assertIn("Classified as PERSON", out)

    def test_bare_target_and_type_override(self):
        code, out, _ = run(["Microsoft", "--type", "person", "--offline", "--no-report", "--no-save"])
        self.assertIn("Classified as PERSON", out)

    def test_bad_type_is_a_clean_error(self):
        code, _, err = run(["--type", "bogus", "x"])
        self.assertEqual(code, 2); self.assertIn("Unknown target type", err)

    def test_unknown_target_returns_error_code(self):
        code, out, _ = run(["investigate", "--type", "ip", "notanip", "--no-save"])
        self.assertEqual(code, 1)

    def test_full_report_is_printed_by_default_with_all_sections(self):
        code, out, _ = run(["10.0.0.1", "--no-save"])
        for n in range(1, 11):
            self.assertIn(f"{n}. ", out)
        self.assertIn("PRIVACY AND LEGAL CONSIDERATIONS", out)

    def test_html_flag_and_no_save(self):
        code, out, _ = run(["10.0.0.1", "--html", "--no-report", "-o", self.tmp.name])
        self.assertTrue(any(f.endswith(".html") for f in os.listdir(self.tmp.name)))
        with tempfile.TemporaryDirectory() as d:
            run(["10.0.0.1", "--no-save", "-o", d])
            self.assertEqual(os.listdir(d), [])



class NewCommands(unittest.TestCase):
    def setUp(self):
        self.addCleanup(lambda: ns.set_offline(False))

    def test_reports_management(self):
        with tempfile.TemporaryDirectory() as d:
            run(["10.0.0.1", "--no-report", "-o", d])
            code, out, _ = run(["reports", "list", "-o", d]); self.assertIn("atlas_10.0.0.1_", out)
            code, out, _ = run(["--list-reports", "-o", d]); self.assertEqual(code, 0)
            name = [r for r in os.listdir(d) if r.endswith(".json")][0][:-5]
            code, out, _ = run(["reports", "delete", name, "-o", d]); self.assertIn("Deleted 2", out)
            code, out, _ = run(["reports", "delete", "../../etc/passwd", "-o", d]); self.assertEqual(code, 1)
            run(["10.0.0.1", "--no-report", "-o", d])
            with mock.patch("sys.stdin.isatty", return_value=False):          # no permission => nothing deleted
                code, out, _ = run(["--delete-reports", "-o", d])
            self.assertEqual(code, 1); self.assertEqual(len(os.listdir(d)), 2)
            with mock.patch("sys.stdin.isatty", return_value=True), mock.patch("builtins.input", return_value="y"):
                run(["--delete-reports", "-o", d])
            self.assertEqual(os.listdir(d), [])
            code, out, _ = run(["--purge-older-than", "1", "-o", d]); self.assertEqual(code, 0)


class Interactive(unittest.TestCase):
    def test_interactive_session_all_commands(self):
        lines = iter(["help", "report", "export", "investigate 10.0.0.1", "10.0.0.2", "report",
                      "export html", "selftest", "reports list", "reports purge x", "offline on", "offline off",
                      "bogus --type", "investigate", "investigate --type nonsense a", "", "exit"])
        tmp = tempfile.TemporaryDirectory(); self.addCleanup(tmp.cleanup); self.addCleanup(lambda: ns.set_offline(False))
        from atlas.agent import AtlasAgent
        agent = AtlasAgent(output_dir=tmp.name, offline=True)
        out = io.StringIO()
        with mock.patch("builtins.input", side_effect=lambda *a: next(lines)), contextlib.redirect_stdout(out):
            atlas_main.run_interactive(agent)
        text = out.getvalue()
        for needle in ("Commands", "No report to export", "Classified as IP", "Exported:",
                       "Platform rule health check", "Offline mode ON", "Offline mode OFF", "Goodbye"):
            self.assertIn(needle, text, needle)
        self.assertNotIn("Traceback", text)


class UI(unittest.TestCase):
    def test_sanitize_strips_terminal_escapes(self):
        s = ui.sanitize("a\x1b[2Jb\x1b]0;pwned\x07c\x9bd\x00e\nf\tg")
        self.assertNotIn("\x1b", s); self.assertNotIn("\x07", s); self.assertNotIn("\x9b", s)
        self.assertIn("\nf\tg", s)

    def test_colour_added_only_by_atlas_after_sanitising(self):
        out = io.StringIO()
        with mock.patch("atlas.ui._color_enabled", return_value=True), contextlib.redirect_stdout(out):
            ui.emit("a\x1b[31mINJECTED\x1b[0m", "red")
        self.assertEqual(out.getvalue(), "\x1b[31ma[31mINJECTED[0m\x1b[0m\n")
        # i.e. the injected escapes lost their ESC byte; the only ESC bytes are ATLAS's own wrapper
        self.assertEqual(out.getvalue().count("\x1b"), 2)

    def test_no_colour_when_not_a_tty_or_no_color(self):
        with mock.patch("sys.stdout.isatty", return_value=False):
            self.assertFalse(ui._color_enabled())
        with mock.patch("sys.stdout.isatty", return_value=True), mock.patch.dict(os.environ, {"NO_COLOR": "1", "TERM": "xterm"}):
            self.assertFalse(ui._color_enabled())

    def test_emit_sanitises_remote_text(self):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            ui.emit("title \x1b[31mred\x1b[0m \x1b]8;;http://evil\x1b\\click")
        self.assertNotIn("\x1b", out.getvalue())

    def test_links_are_plain_sanitised_urls_never_escape_sequences(self):
        for tty in (False, True):
            with mock.patch("sys.stdout.isatty", return_value=tty), mock.patch.dict(os.environ, {"TERM": "xterm"}):
                self.assertEqual(ui.link("https://a.example/x"), "https://a.example/x")
                self.assertNotIn("\x1b", ui.link("https://a.example/\x1b]8;;http://evil\x1b\\"))

    def test_options_may_precede_the_target(self):
        code, out, _ = run(["investigate", "--type", "person", "--offline", "--no-save", "--no-report", "Tim", "Cook"])
        self.assertEqual(code, 0); self.assertIn("Classified as PERSON", out)

    def test_parse_target_args(self):
        t, o = ui.parse_target_args(["Jane", "Roe", "--source", "https://a.example/", "--type", "person",
                                     "--platforms", "my.json", "--stop-at-first"])
        self.assertEqual((t, o["sources"], o["type"], o["platforms"], o["stop_at_first"]),
                         ("Jane Roe", ["https://a.example/"], "person", "my.json", True))

    def test_split_command_tolerates_bad_quotes(self):
        self.assertEqual(ui.split_command('investigate "Tim Cook'), ["investigate", '"Tim', "Cook"])
        self.assertEqual(ui.split_command('investigate "Tim Cook"'), ["investigate", "Tim Cook"])


if __name__ == "__main__":
    unittest.main()
