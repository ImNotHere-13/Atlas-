import json, unittest
from unittest import mock
from tests.helpers import FakeWeb, ns
from atlas.modules.person_module import investigate_person

def page(name, job=None, employer=None, awards=None, extra=""):
    d = {"@type": "Person", "name": name}
    if job: d["jobTitle"] = job
    if employer: d["worksFor"] = {"@type": "Organization", "name": employer}
    if awards: d["award"] = awards
    d.update({"address": {"addressLocality": "PrivateVille", "streetAddress": "9 Home Rd"},
              "sameAs": ["https://social.example/private"], "telephone": "+44 1234 567890", "email": "x@y.z"})
    return f'<title>{name}</title><script type="application/ld+json">{json.dumps(d)}</script>{extra}'


class Person(unittest.TestCase):
    def run_p(self, name="Jane Roe", pages=None, wiki=None):
        pages = pages or {}
        with FakeWeb() as web, mock.patch("atlas.modules.person_module.wikimedia.lookup_person",
                                          return_value=wiki or {"found": False, "errors": ["none"]}):
            for u, b in pages.items():
                web.add(u, b)
            return investigate_person(name, sources=list(pages))

    def test_no_information_does_not_invent_a_profile(self):
        r = self.run_p()
        self.assertEqual(r["professional"]["identity"]["status"], "no_information_located")
        self.assertIsNone(r["professional"]["biography"])
        self.assertEqual(r["professional"]["employment"], [])
        self.assertIn(r["confidence_summary"]["overall"]["level"], ("VERY LOW / UNVERIFIED",))
        self.assertTrue(r["search_hints"])                          # guidance still provided
        self.assertIn("does not build dossiers", r["professional"]["identity"]["explanation"])

    def test_ambiguous_name_is_not_merged(self):
        r = self.run_p(pages={"https://x.example/p": page("Jane Roe", "Chef", "Cafe")}, wiki={"ambiguous": True, "found": False})
        self.assertEqual(r["professional"]["identity"]["status"], "ambiguous")
        self.assertIn("cannot", r["professional"]["identity"]["explanation"])
        self.assertIsNone(r["professional"]["biography"])
        self.assertLessEqual(r["confidence_summary"]["overall"]["score"], 0.2)

    def test_conflicting_employers_are_not_merged(self):
        r = self.run_p(pages={"https://a.example/p": page("Jane Roe", "Chef", "Cafe"),
                              "https://b.example/p": page("Jane Roe", "Judge", "Court")})
        self.assertEqual(r["professional"]["identity"]["status"], "possible_multiple_people")
        self.assertEqual(len(r["professional"]["employment"]), 2)           # listed separately, per source

    def test_official_source_extracts_professional_facts_with_provenance(self):
        r = self.run_p(pages={"https://dept.uni.ac.uk/jane": page("Jane Roe", "Professor", "Uni", ["Prize 2020"])},
                       wiki={"found": True, "name_match": True, "title": "Jane Roe", "description": "Scientist",
                             "extract": "Jane Roe is a scientist.", "page_url": "https://en.wikipedia.org/wiki/Jane_Roe",
                             "queried_at": "t"})
        p = r["professional"]
        self.assertEqual(p["identity"]["status"], "name_match_only")
        self.assertEqual(p["employment"][0]["job_title"], "Professor")
        self.assertEqual(p["employment"][0]["source_reliability"], "HIGH")
        self.assertEqual(p["achievements"][0]["achievement"], "Prize 2020")
        self.assertEqual(p["biography"]["reliability"], "MEDIUM")
        self.assertIn("CC BY-SA", p["biography"]["licence"])
        self.assertTrue(all(f["source"] for f in r["key_findings"]))

    def test_identity_confidence_is_never_high(self):
        r = self.run_p(pages={"https://dept.uni.ac.uk/jane": page("Jane Roe", "Professor", "Uni"),
                              "https://gov.uk/jane": page("Jane Roe", "Professor", "Uni")},
                       wiki={"found": True, "name_match": True, "title": "Jane Roe", "extract": "x",
                             "page_url": "https://en.wikipedia.org/wiki/Jane_Roe", "queried_at": "t"})
        self.assertNotEqual(r["confidence_summary"]["overall"]["level"], "HIGH")
        self.assertLessEqual(r["confidence_summary"]["overall"]["score"], 0.80)

    def test_page_about_a_different_person_is_ignored(self):
        r = self.run_p(pages={"https://a.example/p": page("Someone Else", "Chef", "Cafe")})
        self.assertEqual(r["professional"]["sources"][0]["name_match"], "different_person")
        self.assertEqual(r["professional"]["employment"], [])

    def test_private_fields_are_never_collected(self):
        r = self.run_p(pages={"https://dept.uni.ac.uk/jane": page("Jane Roe", "Professor", "Uni")})
        blob = json.dumps(r)
        for banned in ("PrivateVille", "9 Home Rd", "social.example", "+44 1234", "x@y.z"):
            self.assertNotIn(banned, blob)

    def test_wikipedia_redirect_to_other_name_not_used(self):
        r = self.run_p(wiki={"found": True, "name_match": False, "title": "Other Name", "extract": "nope"})
        self.assertIsNone(r["professional"]["biography"])
        self.assertTrue(any("not used" in l for l in r["limitations"]))

    def test_interviews_are_not_fabricated(self):
        r = self.run_p()
        self.assertFalse(r["professional"]["published_interviews"]["automated"])

    def test_offline(self):
        ns.set_offline(True)
        try:
            r = investigate_person("Jane Roe", sources=["https://a.example/"])
        finally:
            ns.set_offline(False)
        self.assertEqual(r["professional"]["identity"]["status"], "no_information_located")
        self.assertTrue(any("Offline" in l or "offline" in l for l in r["limitations"]))


if __name__ == "__main__":
    unittest.main()
