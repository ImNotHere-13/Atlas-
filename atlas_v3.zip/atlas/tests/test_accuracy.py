import json, unittest
from unittest import mock
from tests.helpers import FakeWeb, OG_PAGE, PUBLIC_IP, ns, patch_agent_network
from atlas.agent import AtlasAgent
from atlas.modules import org_module
from atlas.modules.ip_module import investigate_ip
from atlas.modules.org_module import candidate_domains, investigate_organisation, name_tokens, verify_site_name
from atlas.modules.person_module import investigate_person
from atlas.sources import cert_transparency as ct, provider_hints, wayback, wikidata
from atlas.sources.geoip import lookup_ip_geo


def A(status, headers=None, body=""):
    return (status, headers or {}, body.encode() if isinstance(body, str) else body)


class Retries(unittest.TestCase):
    def test_transient_503_is_retried_once(self):
        with FakeWeb() as web:
            web.sequence("https://a.example/x", [A(503), A(200, {"content-type": "text/plain"}, "ok")])
            resp, err = ns.safe_request("https://a.example/x", retries=1)
            self.assertEqual((resp.status_code, resp.text), (200, "ok"))
            self.assertEqual(len([r for r in web.requests if r[1].endswith("/x")]), 2)
            self.assertEqual(web.sleeps, [1.5])

    def test_default_is_no_retry(self):
        with FakeWeb() as web:
            web.sequence("https://a.example/x", [A(503), A(200)])
            self.assertEqual(ns.safe_request("https://a.example/x")[0].status_code, 503)

    def test_long_retry_after_is_respected_not_evaded(self):
        with FakeWeb() as web:
            web.sequence("https://a.example/x", [A(429, {"retry-after": "60"}), A(200)])
            self.assertEqual(ns.safe_request("https://a.example/x", retries=3)[0].status_code, 429)
            self.assertEqual(len([r for r in web.requests if r[1].endswith("/x")]), 1)
            self.assertEqual(web.sleeps, [])

    def test_short_retry_after_is_honoured(self):
        with FakeWeb() as web:
            web.sequence("https://a.example/x", [A(429, {"retry-after": "2"}), A(200)])
            self.assertEqual(ns.safe_request("https://a.example/x", retries=1)[0].status_code, 200)
            self.assertEqual(web.sleeps, [2.0])

    def test_connection_error_retried_then_reported(self):
        with FakeWeb() as web:
            web.sequence("https://a.example/x", [OSError("reset"), A(200)])
            self.assertEqual(ns.safe_request("https://a.example/x", retries=1)[0].status_code, 200)
        with FakeWeb() as web:
            web.sequence("https://a.example/x", [OSError("reset")])
            resp, err = ns.safe_request("https://a.example/x", retries=2)
            self.assertIsNone(resp); self.assertIn("OSError", err)
            self.assertEqual(len(web.requests), 3)                           # 1 + 2 retries, then gives up

    def test_non_transient_codes_not_retried(self):
        with FakeWeb() as web:
            web.sequence("https://a.example/x", [A(404), A(200)])
            self.assertEqual(ns.safe_request("https://a.example/x", retries=2)[0].status_code, 404)


IPINFO = json.dumps({"country": "US", "region": "California", "city": "Mountain View", "org": "AS15169 Google LLC",
                     "loc": "37.4,-122.0", "postal": "94043"})
def ipwho(cc="US", region="California", city="Mountain View"):
    return json.dumps({"success": True, "country": "United States", "country_code": cc, "region": region, "city": city,
                       "latitude": 37.4, "longitude": -122.0, "postal": "94043",
                       "connection": {"asn": 15169, "org": "Google LLC", "isp": "Google LLC"}, "timezone": {"id": "America/Los_Angeles"}})


class GeoConsensus(unittest.TestCase):
    def geo(self, ipinfo=IPINFO, who=None, apiapi=None):
        with FakeWeb() as web:
            if ipinfo: web.add("https://ipinfo.io/8.8.8.8/json", ipinfo, ctype="application/json")
            if who: web.add("https://ipwho.is/8.8.8.8", who, ctype="application/json")
            if apiapi: web.add("http://ip-api.com/json/8.8.8.8?fields=status,message,country,countryCode,regionName,city,timezone,"
                               "isp,org,as,asname,mobile,proxy,hosting", apiapi, ctype="application/json")
            return lookup_ip_geo("8.8.8.8"), web

    def test_agreement(self):
        g, _ = self.geo(who=ipwho())
        self.assertEqual(g["sources_used"], ["ipinfo.io", "ipwho.is"])
        cc = g["cross_check"]
        self.assertEqual((cc["country_agreement"], cc["region_agreement"], cc["city_agreement"]), (True, True, True))
        self.assertEqual(g["data"]["country"], "United States")
        blob = json.dumps(g)
        for banned in ("37.4", "-122.0", "94043", "latitude", "postal"):
            self.assertNotIn(banned, blob)

    def test_country_disagreement_is_surfaced(self):
        g, _ = self.geo(who=ipwho(cc="CA", region="Ontario", city="Toronto"))
        self.assertIs(g["cross_check"]["country_agreement"], False)

    def test_city_only_disagreement(self):
        g, _ = self.geo(who=ipwho(city="Sunnyvale"))
        cc = g["cross_check"]
        self.assertEqual((cc["country_agreement"], cc["city_agreement"]), (True, False))

    def test_single_provider_is_flagged_as_uncrosschecked(self):
        g, _ = self.geo()
        self.assertTrue(g["success"]); self.assertIn("could not be cross-checked", g["cross_check"]["note"])
        self.assertIsNone(g["cross_check"]["country_agreement"])

    def test_cleartext_fallback_only_when_https_providers_fail(self):
        g, web = self.geo(ipinfo=None, apiapi=json.dumps({"status": "success", "countryCode": "US", "country": "United States"}))
        self.assertEqual(g["source"], "ip-api.com (cleartext HTTP)")
        g, web = self.geo(who=ipwho(), apiapi=json.dumps({"status": "success", "countryCode": "US"}))
        self.assertFalse([r for r in web.requests if "ip-api.com" in r[1]])

    def test_all_providers_fail_and_special_addresses(self):
        g, _ = self.geo(ipinfo=None)
        self.assertFalse(g["success"]); self.assertTrue(g["errors"])
        self.assertIn("Not a public", lookup_ip_geo("10.0.0.1")["errors"][0])
        ns.set_offline(True)
        try: self.assertIn("offline", lookup_ip_geo("8.8.8.8")["errors"][0])
        finally: ns.set_offline(False)

    def test_malformed_provider_data_never_crashes(self):
        for bad in ("not json", "[]", "{}", json.dumps({"success": False, "message": "quota"})):
            g, _ = self.geo(ipinfo=bad, who=bad)
            self.assertFalse(g["success"])


class IPAccuracy(unittest.TestCase):
    def run_ip(self, who, rdap_country="US"):
        rdap = json.dumps({"name": "GOOGLE", "country": rdap_country, "startAddress": "8.8.8.0", "endAddress": "8.8.8.255"})
        with FakeWeb() as web, mock.patch("atlas.sources.reputation.socket.gethostbyname", side_effect=__import__("socket").gaierror):
            web.add("https://rdap.org/ip/8.8.8.8", rdap, ctype="application/rdap+json")
            web.add("https://ipinfo.io/8.8.8.8/json", IPINFO, ctype="application/json")
            if who: web.add("https://ipwho.is/8.8.8.8", who, ctype="application/json")
            return investigate_ip("8.8.8.8")

    def test_agreeing_providers_raise_confidence(self):
        r = self.run_ip(ipwho())
        self.assertEqual(r["confidence_summary"]["geolocation"]["level"], "MEDIUM")
        self.assertEqual(r["sections"]["accuracy_checks"]["registry_vs_geolocation"], "match")

    def test_disagreement_lowers_confidence_and_warns(self):
        r = self.run_ip(ipwho(cc="CA"))
        self.assertIn("VERY LOW", r["confidence_summary"]["geolocation"]["level"])
        self.assertLess(r["confidence_summary"]["geolocation"]["score"], 0.35)
        self.assertTrue(any("disagree" in l for l in r["limitations"]))

    def test_single_provider_is_low_confidence(self):
        r = self.run_ip(None)
        self.assertEqual(r["confidence_summary"]["geolocation"]["level"], "LOW")

    def test_registry_country_difference_is_explained_not_called_an_error(self):
        r = self.run_ip(ipwho(), rdap_country="NL")
        ac = r["sections"]["accuracy_checks"]
        self.assertEqual(ac["registry_vs_geolocation"], "differs"); self.assertIn("not an error", ac["explanation"])


# ----------------------------------------------------------------------------- Wikidata
def wd_entity(human=True, site=None, occ=None, emp=None, wp=None):
    claims = {"P31": [{"mainsnak": {"datavalue": {"value": {"id": "Q5" if human else "Q4830453"}}}}]}
    if site: claims["P856"] = [{"mainsnak": {"datavalue": {"value": site}}}]
    if occ: claims["P106"] = [{"mainsnak": {"datavalue": {"value": {"id": q}}}} for q in occ]
    if emp: claims["P108"] = [{"mainsnak": {"datavalue": {"value": {"id": q}}}} for q in emp]
    e = {"claims": claims}
    if wp: e["sitelinks"] = {"enwiki": {"title": wp}}
    return e


def wd_web(web, hits, entities, labels=None):
    web.route("action=wbsearchentities", json.dumps({"search": hits}))
    web.route("props=labels|descriptions|claims", json.dumps({"entities": entities}))
    web.route("props=labels&languages", json.dumps({"entities": {q: {"labels": {"en": {"value": v}}} for q, v in (labels or {}).items()}}))


def hit(qid, label, desc=""):
    return {"id": qid, "label": label, "description": desc, "match": {"type": "label", "text": label}}


class Wikidata(unittest.TestCase):
    def test_single_human_selected_with_professional_facts_only(self):
        with FakeWeb() as web:
            wd_web(web, [hit("Q1", "Jane Roe", "scientist")],
                   {"Q1": wd_entity(site="https://jane.example/", occ=["Q901"], emp=["Q902"], wp="Jane Roe")},
                   {"Q901": "physicist", "Q902": "Example University"})
            r = wikidata.lookup("Jane Roe", "person")
        sel = r["selected"]
        self.assertEqual((r["found"], r["ambiguous"], sel["qid"]), (True, False, "Q1"))
        self.assertEqual((sel["occupations"], sel["employers"], sel["official_website"]),
                         (["physicist"], ["Example University"], "https://jane.example/"))
        self.assertEqual(sel["wikipedia_url"], "https://en.wikipedia.org/wiki/Jane_Roe")
        for banned in ("birth", "residence", "spouse", "P569", "P551", "P26"):
            self.assertNotIn(banned, json.dumps(r))

    def test_two_people_same_name_is_ambiguous_and_lists_candidates(self):
        with FakeWeb() as web:
            wd_web(web, [hit("Q1", "Jane Roe", "scientist"), hit("Q2", "Jane Roe", "footballer")],
                   {"Q1": wd_entity(), "Q2": wd_entity()})
            r = wikidata.lookup("Jane Roe", "person")
        self.assertTrue(r["ambiguous"]); self.assertIsNone(r["selected"])
        self.assertEqual({c["description"] for c in r["candidates"]}, {"scientist", "footballer"})

    def test_kind_filters_people_from_organisations(self):
        with FakeWeb() as web:
            wd_web(web, [hit("Q1", "Acme", "company"), hit("Q2", "Acme", "person")],
                   {"Q1": wd_entity(human=False, site="https://acme.example/"), "Q2": wd_entity()})
            self.assertEqual(wikidata.lookup("Acme", "org")["selected"]["qid"], "Q1")
            self.assertEqual(wikidata.lookup("Acme", "person")["selected"]["qid"], "Q2")

    def test_unsafe_official_website_is_ignored(self):
        with FakeWeb() as web:
            wd_web(web, [hit("Q1", "Acme")], {"Q1": wd_entity(human=False, site="javascript:alert(1)")})
            self.assertIsNone(wikidata.lookup("Acme", "org")["selected"]["official_website"])
        with FakeWeb() as web:
            wd_web(web, [hit("Q1", "Acme")], {"Q1": wd_entity(human=False, site="https://u:p@acme.example/")})
            self.assertIsNone(wikidata.lookup("Acme", "org")["selected"]["official_website"])

    def test_no_match_and_failures(self):
        with FakeWeb() as web:
            wd_web(web, [], {})
            self.assertFalse(wikidata.lookup("Nobody Here", "person")["found"])
        with FakeWeb():                                                     # 404 everywhere
            r = wikidata.lookup("Jane Roe", "person"); self.assertFalse(r["found"]); self.assertTrue(r["errors"])
        with FakeWeb() as web:
            web.route("action=wbsearchentities", "not json")
            self.assertFalse(wikidata.lookup("Jane Roe", "person")["found"])

    def test_fuzzy_non_exact_labels_are_never_selected(self):
        with FakeWeb() as web:
            wd_web(web, [hit("Q1", "Jane Roeder")], {"Q1": wd_entity()})
            r = wikidata.lookup("Jane Roe", "person")
        self.assertIsNone(r["selected"]); self.assertFalse(r["found"])


class PersonWithWikidata(unittest.TestCase):
    def run_p(self, setup, sources=None):
        with FakeWeb() as web, mock.patch("atlas.modules.person_module.wikimedia.lookup_person", return_value={"found": False}):
            setup(web)
            return investigate_person("Jane Roe", sources=sources or []), web

    def test_unique_match_adds_roles_and_fetches_the_recorded_official_site(self):
        page = ('<title>Jane Roe</title><script type="application/ld+json">{"@type":"Person","name":"Jane Roe",'
                '"jobTitle":"Professor","address":{"addressLocality":"HomeTown"}}</script>')
        def setup(web):
            wd_web(web, [hit("Q1", "Jane Roe", "scientist")],
                   {"Q1": wd_entity(site="https://jane.example/", occ=["Q901"], emp=["Q902"])},
                   {"Q901": "physicist", "Q902": "Example University"})
            web.add("https://jane.example/", page)
        r, web = self.run_p(setup)
        p = r["professional"]
        self.assertEqual(p["identity"]["status"], "name_match_only")
        self.assertEqual(p["wikidata_profile"]["occupations"], ["physicist"])
        jobs = {(e["job_title"], e["source"].split("/")[2]) for e in p["employment"]}
        self.assertIn(("physicist", "www.wikidata.org"), jobs); self.assertIn(("Professor", "jane.example"), jobs)
        self.assertIn(("GET", "https://jane.example/"), web.requests)
        self.assertNotIn("HomeTown", json.dumps(r))
        self.assertNotEqual(r["confidence_summary"]["overall"]["level"], "HIGH")

    def test_ambiguous_name_lists_candidates_and_merges_nothing(self):
        def setup(web):
            wd_web(web, [hit("Q1", "Jane Roe", "scientist"), hit("Q2", "Jane Roe", "footballer")],
                   {"Q1": wd_entity(site="https://jane.example/"), "Q2": wd_entity()})
            web.add("https://jane.example/", "<title>Jane Roe</title>")
        r, web = self.run_p(setup)
        p = r["professional"]
        self.assertEqual(p["identity"]["status"], "ambiguous")
        self.assertIn("footballer", p["identity"]["explanation"]); self.assertIn("scientist", p["identity"]["explanation"])
        self.assertNotIn("wikidata_profile", p); self.assertEqual(p["employment"], [])
        self.assertNotIn(("GET", "https://jane.example/"), web.requests)       # no site fetched for an ambiguous match
        self.assertLessEqual(r["confidence_summary"]["overall"]["score"], 0.2)

    def test_explicit_user_sources_still_work_alongside(self):
        def setup(web):
            wd_web(web, [], {})
            web.add("https://dept.uni.ac.uk/jane", '<title>Jane Roe</title><script type="application/ld+json">'
                    '{"@type":"Person","name":"Jane Roe","jobTitle":"Chair"}</script>')
        r, _ = self.run_p(setup, sources=["https://dept.uni.ac.uk/jane"])
        self.assertEqual(r["professional"]["employment"][0]["job_title"], "Chair")


# ----------------------------------------------------------------------------- org
class OrgVerification(unittest.TestCase):
    def test_candidates_strip_legal_suffixes_and_are_capped(self):
        self.assertEqual(candidate_domains("Example Corp Ltd")[0], "example.com")
        self.assertIn("example.co.uk", candidate_domains("Example Ltd"))
        self.assertLessEqual(len(candidate_domains("Bank of America")), 8)
        self.assertEqual(candidate_domains("Ltd"), [])
        self.assertEqual(name_tokens("The Bank of America Corp")[1], ["the"][:0] + ["bank", "america"])

    def test_name_verification(self):
        ok = lambda n, **w: verify_site_name(n, w)[0]
        self.assertTrue(ok("Example Corp", title="Example Corp – Home"))
        self.assertTrue(ok("Example Corp", title="Welcome to Example Corp"))
        self.assertTrue(ok("Bank of America", title="Bank of America | Official Site"))
        self.assertTrue(ok("Example Corp", site_name="ExampleCorp"))
        self.assertTrue(ok("Bank of America", h1="Bank of America"))
        self.assertFalse(ok("Example Corp", title="Buy cheap domains"))
        self.assertFalse(ok("Example Corp", title="Example Widgets"))              # partial words are not enough
        self.assertFalse(ok("Example Corp", title="Examples of good design"))
        self.assertFalse(ok("Ltd", title="Ltd"))

    def run_org(self, setup, name="Example Corp"):
        with FakeWeb() as web, patch_agent_network():
            setup(web)
            return investigate_organisation(name), web

    def test_unrelated_responding_domain_is_excluded_and_called_unrelated(self):
        def setup(web):
            web.add("https://example.com", "<title>Parked domain for sale</title>")
        r, _ = self.run_org(setup)
        site = r["sections"]["possible_official_sites"]["responsive_sites"][0]
        self.assertFalse(site["name_match"])
        self.assertEqual(r["sections"]["possible_official_sites"]["name_verified_sites"], [])
        self.assertTrue(any("probably unrelated" in f["finding"] for f in r["key_findings"]))
        self.assertLess(r["confidence_summary"]["web_presence"]["score"], 0.35)

    def test_guessed_site_with_matching_name_is_only_a_low_lead(self):
        def setup(web):
            web.add("https://example.com", "<title>Example Corp – Welcome</title>")
        r, _ = self.run_org(setup)
        self.assertEqual(r["sections"]["possible_official_sites"]["name_verified_sites"], ["example.com"])
        f = next(f for f in r["key_findings"] if "Likely official" in f["finding"])
        self.assertEqual(f["confidence"], "LOW"); self.assertIn("NOT confirmed", f["finding"])

    def test_wikidata_official_site_beats_guessing_and_is_name_verified(self):
        def setup(web):
            wd_web(web, [hit("Q9", "Example Corp", "company")], {"Q9": wd_entity(human=False, site="https://www.excorp.test/")})
            web.add("https://www.excorp.test/", "<title>Example Corp | Official</title>")
            web.add("https://example.com", "<title>Example Corp</title>")      # a guess that must NOT be tested
            web.route("https://crt.sh/?O=", "[]")
        r, web = self.run_org(setup)
        site = r["sections"]["possible_official_sites"]["responsive_sites"][0]
        self.assertEqual((site["domain"], site["name_match"]), ("excorp.test", True))
        self.assertIn("Wikidata", site["origin"])
        self.assertEqual(r["confidence_summary"]["web_presence"]["score"], 0.7)
        self.assertFalse([x for x in web.requests if x[1].rstrip("/") == "https://example.com"])
        self.assertTrue(any("per Wikidata" in f["finding"] for f in r["key_findings"]))

    def test_ambiguous_organisation_is_not_resolved_by_guessing_wikidata(self):
        def setup(web):
            wd_web(web, [hit("Q9", "Example Corp", "company"), hit("Q8", "Example Corp", "charity")],
                   {"Q9": wd_entity(human=False, site="https://a.test/"), "Q8": wd_entity(human=False, site="https://b.test/")})
            web.route("https://crt.sh/?O=", "[]")
        r, web = self.run_org(setup)
        self.assertTrue(r["sections"]["wikidata"]["ambiguous"])
        self.assertTrue(any("share this name" in l for l in r["limitations"]))
        self.assertNotIn(("GET", "https://a.test/"), web.requests)

    def test_certificate_organisation_domains_are_low_confidence_leads(self):
        def setup(web):
            web.route("https://crt.sh/?O=", json.dumps([{"name_value": "www.example-corp.com\nexample-corp.co.uk"},
                                                        {"name_value": "api.example-corp.com"}]))
        r, _ = self.run_org(setup)
        doms = {d["domain"]: d["certificates"] for d in r["sections"]["certificate_organisation_domains"]["domains"]}
        self.assertEqual(doms, {"example-corp.com": 2, "example-corp.co.uk": 1})
        f = next(f for f in r["key_findings"] if "unverified leads" in f["finding"]); self.assertEqual(f["confidence"], "LOW")


# ----------------------------------------------------------------------------- domain extras
class Wayback(unittest.TestCase):
    def web(self, web, first, last, months):
        base = "https://web.archive.org/cdx/search/cdx?url=example.org&output=json&fl=timestamp"
        web.add(base + "&limit=1", json.dumps([["timestamp"]] + first), ctype="application/json")
        web.add(base + "&limit=-1", json.dumps([["timestamp"]] + last), ctype="application/json")
        web.add(base + "&collapse=timestamp:6&limit=3000", json.dumps([["timestamp"]] + months), ctype="application/json")

    def test_history(self):
        with FakeWeb() as web:
            self.web(web, [["20050301120000"]], [["20260101000000"]], [[f"2005{m:02d}01000000"] for m in range(3, 13)])
            r = wayback.query_wayback("example.org")
        self.assertEqual((r["first_capture"], r["last_capture"], r["months_with_captures"]), ("2005-03-01", "2026-01-01", 10))
        self.assertTrue(r["first_snapshot_url"].startswith("https://web.archive.org/web/20050301120000/"))
        self.assertIn("not show who operated", r["note"])

    def test_no_captures_is_reported_as_such(self):
        with FakeWeb() as web:
            self.web(web, [], [], [])
            r = wayback.query_wayback("example.org")
        self.assertEqual((r["success"], r["captures_found"]), (True, False))

    def test_failure_and_garbage(self):
        with FakeWeb():
            self.assertFalse(wayback.query_wayback("example.org")["success"])
        with FakeWeb() as web:
            web.route("web.archive.org/cdx", "garbage")
            self.assertFalse(wayback.query_wayback("example.org")["success"])
        with FakeWeb() as web:
            web.route("web.archive.org/cdx", json.dumps([["timestamp"], ["not-a-timestamp"]]))
            self.assertFalse(wayback.query_wayback("example.org")["captures_found"])


class RelatedDomains(unittest.TestCase):
    def test_related_domains_exclude_own_and_shared_cdn_certificates(self):
        shared = "\n".join(f"customer{i}.net" for i in range(30)) + "\nexample.org"
        entries = [{"name_value": "www.example.org\nexample-shop.com\nsni123.cloudflaressl.com"},
                   {"name_value": "api.example.org\nexample-shop.com\npartner.co.uk"},
                   {"name_value": shared}]
        with FakeWeb() as web:
            web.add("https://crt.sh/?q=%25.example.org&output=json", json.dumps(entries), ctype="application/json")
            r = ct.search_crtsh("example.org")
        rel = {d["domain"]: d["certificates"] for d in r["related_domains"]}
        self.assertEqual(rel, {"example-shop.com": 2, "partner.co.uk": 1})
        self.assertNotIn("example.org", rel); self.assertFalse(any("customer" in d for d in rel))
        self.assertIn("verify", r["related_domains_note"])

    def test_registrable(self):
        self.assertEqual(ct.registrable("a.b.example.co.uk"), "example.co.uk")
        self.assertEqual(ct.registrable("www.example.com"), "example.com")


class ProviderHints(unittest.TestCase):
    def test_inference(self):
        r = provider_hints.infer_providers({"MX": ["10 aspmx.l.google.com."], "NS": ["ns-1.awsdns-01.org."],
                                            "TXT": ["v=spf1 include:_spf.google.com include:sendgrid.net ~all", "other"]})
        self.assertEqual((r["email"], r["dns"], r["sending_services"]),
                         (["Google Workspace / Gmail"], ["Amazon Route 53"], ["Google Workspace", "SendGrid"]))
        self.assertEqual(provider_hints.infer_providers({}), {"email": [], "dns": [], "sending_services": [], "caveat": r["caveat"]})


class DomainIntegration(unittest.TestCase):
    def test_new_sections_and_findings(self):
        with FakeWeb() as web, patch_agent_network(), \
             mock.patch("atlas.modules.domain_module.get_dns_records", return_value={
                 "success": True, "method": "t", "records": {"MX": ["10 aspmx.l.google.com."], "NS": ["a.awsdns-1.org."]}}):
            base = "https://web.archive.org/cdx/search/cdx?url=example.org&output=json&fl=timestamp"
            web.add(base + "&limit=1", json.dumps([["timestamp"], ["20100101000000"]]), ctype="application/json")
            web.add(base + "&limit=-1", json.dumps([["timestamp"], ["20260101000000"]]), ctype="application/json")
            web.add(base + "&collapse=timestamp:6&limit=3000", json.dumps([["timestamp"], ["20100101000000"]]), ctype="application/json")
            web.add("https://crt.sh/?q=%25.example.org&output=json",
                    json.dumps([{"name_value": "example.org\nexample-shop.com"}]), ctype="application/json")
            web.add("https://example.org/", OG_PAGE)
            from atlas.modules.domain_module import investigate_domain
            r = investigate_domain("example.org")
        s = r["sections"]
        self.assertEqual(s["web_history"]["first_capture"], "2010-01-01")
        self.assertEqual(s["related_domains"]["domains"][0]["domain"], "example-shop.com")
        self.assertEqual(s["provider_inference"]["email"], ["Google Workspace / Gmail"])
        text = " ".join(f["finding"] for f in r["key_findings"])
        for needle in ("Internet Archive has captures from 2010-01-01", "Possibly related domains", "Provider inference"):
            self.assertIn(needle, text)
        self.assertTrue(all(f["source"] for f in r["key_findings"]))
        self.assertEqual(r["confidence_summary"]["web_history"]["level"], "MEDIUM")


if __name__ == "__main__":
    unittest.main()
