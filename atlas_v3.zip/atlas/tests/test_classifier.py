import unittest
from tests.helpers import ns
from atlas.classifier import TargetType as T, classify, parse_forced_type


class Classifier(unittest.TestCase):
    def check(self, s, typ, norm=None):
        r = classify(s)
        self.assertEqual(r.target_type, typ, s)
        if norm is not None:
            self.assertEqual(r.normalised, norm, s)
        return r

    def test_names_and_orgs(self):
        self.check("Abraham Lincoln", T.PERSON)
        self.check("Tim Cook", T.PERSON, "Tim Cook")
        self.check("Apple Inc", T.ORGANISATION)
        self.check("Bank of America", T.ORGANISATION)
        self.check("Microsoft", T.ORGANISATION)
        self.check("Mary-Jane O'Neil", T.PERSON)

    def test_urls(self):
        r = self.check("https://user:pw@example.com:8443/x", T.URL, "example.com")
        self.assertNotIn("pw", r.original)
        self.check("http://8.8.8.8/path", T.IP, "8.8.8.8")
        self.check("http://[2001:db8::1]/", T.IP, "2001:db8::1")

    def test_ips_and_domains(self):
        self.check("8.8.8.8", T.IP)
        self.check("[2001:db8::1]", T.IP, "2001:db8::1")
        self.check("www.Example.com/a", T.DOMAIN, "example.com")

    def test_quotes_and_empty(self):
        self.check('"Tim Cook"', T.PERSON, "Tim Cook")
        self.check("", T.UNKNOWN)

    def test_force(self):
        self.assertEqual(classify("Tim Cook", parse_forced_type("org")).target_type, T.ORGANISATION)
        self.assertEqual(classify("nonsense", parse_forced_type("ip")).target_type, T.UNKNOWN)
        with self.assertRaises(ValueError):
            parse_forced_type("nonsense")


if __name__ == "__main__":
    unittest.main()
