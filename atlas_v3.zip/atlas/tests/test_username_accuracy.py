import contextlib, io, json, os, re, tempfile, unittest
from unittest import mock
from tests.helpers import FakeWeb, ns, write
from atlas.modules.username_module import investigate_username, run_selftest
from atlas.sources import username_sources as us
from atlas.sources.username_sources import Platform, check_platform, load_platforms, parse_platform, selftest_platform

P = Platform("Alpha", "developer", "https://alpha.example/{}")
CTRL = iter([])


def fixed_controls(*names):
    it = iter(names)
    return mock.patch.object(us, "control_name", side_effect=lambda p=None: next(it))


def html(title="", h1="", body="p"):
    return f"<html><head><title>{title}</title></head><body><h1>{h1}</h1>{body}</body></html>"


class Loader(unittest.TestCase):
    def load(self, rows, as_dict=True):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "p.json"); write(path, json.dumps({"platforms": rows} if as_dict else rows))
            return load_platforms(path)

    def test_valid_entry_and_defaults(self):
        ps, w = self.load([{"name": "Good", "category": "Developer", "url": "https://good.example/{}"}])
        self.assertEqual((len(ps), w), (1, []))
        p = ps[0]
        self.assertEqual((p.kind, p.category, p.absent_codes), ("status", "developer", (404, 410)))

    def test_bad_entries_are_skipped_with_reasons(self):
        rows = [
            {"name": "ok", "category": "x", "url": "https://ok.example/{}"},
            {"name": "http", "category": "x", "url": "http://plain.example/{}"},
            {"name": "noplaceholder", "category": "x", "url": "https://a.example/"},
            {"name": "two", "category": "x", "url": "https://a.example/{}/{}"},
            {"name": "ip", "category": "x", "url": "https://10.0.0.1/{}"},
            {"name": "date", "category": "Dating", "url": "https://d.example/{}"},
            {"name": "adult", "category": "adult", "url": "https://d.example/{}"},
            {"name": "msg", "category": "messaging", "url": "https://d.example/{}"},
            {"name": "m", "category": "x", "url": "https://m.example/{}", "kind": "message"},
            {"name": "j", "category": "x", "url": "https://j.example/{}", "kind": "json"},
            {"name": "re", "category": "x", "url": "https://r.example/{}", "pattern": "("},
            {"name": "kind", "category": "x", "url": "https://k.example/{}", "kind": "execute"},
            {"name": "codes", "category": "x", "url": "https://c.example/{}", "absent_codes": [200]},
            {"name": "pu", "category": "x", "url": "https://p.example/{}", "profile_url": "javascript:{}"},
            {"name": "ok", "category": "x", "url": "https://dup.example/{}"},
            "not an object", {"category": "x"},
        ]
        ps, w = self.load(rows)
        self.assertEqual([p.name for p in ps], ["ok"])
        self.assertEqual(len(w), len(rows) - 1)
        joined = " ".join(w)
        for needle in ("https://", "placeholder", "IP address", "dating", "adult", "messaging", "absent_text", "exists_path",
                       "duplicate"):
            self.assertIn(needle, joined, needle)

    def test_top_level_list_accepted_and_unreadable_files_reported(self):
        ps, w = self.load([{"name": "A", "category": "x", "url": "https://a.example/{}"}], as_dict=False)
        self.assertEqual(len(ps), 1)
        self.assertEqual(load_platforms("/nonexistent/p.json")[0], [])
        with tempfile.TemporaryDirectory() as d:
            bad = os.path.join(d, "b.json"); write(bad, "{not json")
            ps, w = load_platforms(bad); self.assertEqual(ps, []); self.assertTrue(w)
            big = os.path.join(d, "big.json"); write(big, "x" * 1_100_000)
            ps, w = load_platforms(big); self.assertEqual(ps, []); self.assertIn("larger than 1 MB", w[0])
            wrong = os.path.join(d, "w.json"); write(wrong, json.dumps({"platforms": "nope"}))
            self.assertEqual(load_platforms(wrong)[0], [])

    def test_platform_cap(self):
        rows = [{"name": f"P{i}", "category": "x", "url": f"https://p{i}.example/{{}}"} for i in range(350)]
        ps, w = self.load(rows)
        self.assertEqual(len(ps), us.MAX_PLATFORMS); self.assertTrue(any("first 300" in x for x in w))


class ShippedList(unittest.TestCase):
    def test_policy_and_quality(self):
        ps = us.PLATFORMS
        self.assertEqual(us._BUILTIN_WARNINGS, [])
        self.assertGreaterEqual(len(ps), 70)
        names = [p.name for p in ps]; self.assertEqual(len(names), len(set(names)))
        banned = re.compile(r"dating|adult|porn|tinder|grindr|onlyfans|whatsapp|telegram|signal|snapchat|discord|bank|health", re.I)
        for p in ps:
            self.assertTrue(p.url.startswith("https://") and p.url.count("{}") == 1, p.name)
            self.assertNotIn(p.category, us.EXCLUDED_CATEGORIES, p.name)
            self.assertFalse(banned.search(p.name + p.url), p.name)
            if p.known_good and p.pattern:
                self.assertRegex(p.known_good, p.pattern, p.name)
        self.assertGreaterEqual(sum(1 for p in ps if p.known_good), 15)
        blocked = {n for n, _ in us.MANUAL_LINKS}
        self.assertFalse(blocked & set(names))
        from urllib.parse import urlparse
        hosts = {urlparse(p.url.replace("{}", "u")).hostname for p in ps}
        for site in ("instagram.com", "x.com", "twitter.com", "tiktok.com", "facebook.com", "linkedin.com", "reddit.com"):
            self.assertFalse([h for h in hosts if h == site or h.endswith("." + site)], site)

    def test_control_names_fit_every_platform(self):
        for p in us.PLATFORMS:
            for _ in range(5):
                n = us.control_name(p)
                self.assertTrue(re.match(p.pattern or ".", n), (p.name, n))
        self.assertNotEqual(us.control_name(P), us.control_name(P))


class Accuracy(unittest.TestCase):
    def test_soft_404_pages_are_not_matches(self):
        for title, h1 in (("Page not found", ""), ("", "404"), ("Oops – this page doesn't exist", ""), ("No such user", ""),
                          ("Profile unavailable", ""), ("jdoe", "Sorry, we couldn't find that page")):
            with FakeWeb() as web:
                web.add("https://alpha.example/jdoe", html(title, h1))
                r = check_platform(P, "jdoe")
            self.assertEqual(r["status"], "not_found", (title, h1))
            self.assertIn("soft 404", r["detail"])

    def test_normal_pages_are_not_flagged_as_soft_404(self):
        for title in ("jdoe (@jdoe) · Alpha", "Notes and nothing", "Knotted – a knitting site", "Foundation"):
            with FakeWeb() as web, fixed_controls("c1", "c2"):
                web.add("https://alpha.example/jdoe", html(title))
                self.assertEqual(check_platform(P, "jdoe")["status"], "found", title)

    def test_confidence_is_graded_by_evidence(self):
        with FakeWeb() as web, fixed_controls("c1", "c2"):
            web.add("https://alpha.example/jdoe", html("jdoe's profile"))
            r = check_platform(P, "jdoe")
        self.assertEqual((r["existence_confidence"], r["control_check"], r["username_in_page"]), ("HIGH", "passed", True))
        self.assertIn("username appears", r["detail"])
        with FakeWeb() as web, fixed_controls("c1", "c2"):
            web.add("https://alpha.example/jdoe", html("Alpha"))
            r = check_platform(P, "jdoe")
        self.assertEqual((r["existence_confidence"], r["username_in_page"]), ("MEDIUM", False))

    def test_username_in_json_body_counts(self):
        chess = Platform("Chess", "gaming", "https://api.chess.example/player/{}")
        with FakeWeb() as web, fixed_controls("c1", "c2"):
            web.add("https://api.chess.example/player/jdoe", json.dumps({"username": "jdoe"}), ctype="application/json")
            self.assertEqual(check_platform(chess, "jdoe")["existence_confidence"], "HIGH")

    def test_either_control_looking_found_makes_the_platform_unreliable(self):
        with FakeWeb() as web, fixed_controls("c1", "c2"):
            web.add("https://alpha.example/jdoe", html("jdoe"))
            web.add("https://alpha.example/c2", html("anything"))                 # second control ALSO "exists"
            r = check_platform(P, "jdoe")
        self.assertEqual((r["status"], r["control_check"]), ("unreliable", "failed"))

    def test_inconclusive_control_lowers_confidence_but_keeps_the_match(self):
        with FakeWeb() as web, fixed_controls("c1", "c2"):
            web.add("https://alpha.example/jdoe", html("jdoe"))
            web.add("https://alpha.example/c2", "", status=403)
            r = check_platform(P, "jdoe")
        self.assertEqual((r["status"], r["control_check"], r["existence_confidence"]), ("found", "inconclusive", "LOW"))

    def test_two_control_requests_are_made_only_for_matches(self):
        with FakeWeb() as web, fixed_controls("c1", "c2"):
            web.add("https://alpha.example/jdoe", html("jdoe"))
            check_platform(P, "jdoe")
            self.assertEqual(sorted(u.rsplit("/", 1)[1] for _, u in web.requests if "robots" not in u), ["c1", "c2", "jdoe"])
        with FakeWeb() as web:
            check_platform(P, "nobody")
            self.assertEqual([u for _, u in web.requests if "robots" not in u], ["https://alpha.example/nobody"])

    def test_transient_failure_is_retried_but_long_retry_after_is_respected(self):
        with FakeWeb() as web, fixed_controls("c1", "c2"):
            web.sequence("https://alpha.example/jdoe", [(503, {}, b""), (200, {"content-type": "text/html"}, html("jdoe").encode())])
            self.assertEqual(check_platform(P, "jdoe")["status"], "found")
            self.assertEqual(web.sleeps, [1.5])
        with FakeWeb() as web:
            web.sequence("https://alpha.example/jdoe", [(429, {"retry-after": "120"}, b""), (200, {}, b"")])
            self.assertEqual(check_platform(P, "jdoe")["status"], "inconclusive")
            self.assertEqual(web.sleeps, [])

    def test_custom_absent_codes_and_empty_json(self):
        bsky = Platform("Bsky", "social", "https://api.bsky.example/profile?actor={}", kind="json", exists_path=("handle",),
                        absent_codes=(400, 404))
        gitlab = Platform("GL", "developer", "https://gl.example/users?username={}", kind="json", absent_if_empty=True,
                          exists_path=(0, "id"))
        with FakeWeb() as web, fixed_controls("c1", "c2", "c1", "c2"):
            web.add("https://api.bsky.example/profile?actor=ghost", json.dumps({"error": "Profile not found"}), status=400)
            self.assertEqual(check_platform(bsky, "ghost")["status"], "not_found")
            web.add("https://api.bsky.example/profile?actor=jdoe", json.dumps({"handle": "jdoe.bsky.social"}))
            web.add("https://api.bsky.example/profile?actor=c1", "{}", status=400)
            web.add("https://api.bsky.example/profile?actor=c2", "{}", status=400)
            self.assertEqual(check_platform(bsky, "jdoe")["status"], "found")
            web.add("https://gl.example/users?username=ghost", "[]")
            self.assertEqual(check_platform(gitlab, "ghost")["status"], "not_found")
            web.add("https://gl.example/users?username=jdoe", json.dumps([{"id": 5}]))
            web.add("https://gl.example/users?username=c1", "[]"); web.add("https://gl.example/users?username=c2", "[]")
            self.assertEqual(check_platform(gitlab, "jdoe")["status"], "found")

    def test_page_text_is_never_stored(self):
        with FakeWeb() as web, fixed_controls("c1", "c2"):
            web.add("https://alpha.example/jdoe", html("jdoe", "Jane Doe", "bio: lives in Leeds, jane@x.y"))
            blob = json.dumps(check_platform(P, "jdoe"))
        for banned in ("Jane Doe", "Leeds", "jane@x.y"):
            self.assertNotIn(banned, blob)


KG = Platform("Kg", "developer", "https://kg.example/{}", known_good="official")


class SelfTest(unittest.TestCase):
    def verdict(self, p, setup, ctrl="neg"):
        with FakeWeb() as web, fixed_controls(ctrl):
            setup(web)
            return selftest_platform(p)

    def test_healthy(self):
        r = self.verdict(KG, lambda w: w.add("https://kg.example/official", html("official")))
        self.assertEqual((r["verdict"], r["negative"], r["positive"]), ("healthy", "absent", "exists"))

    def test_stale_rule_when_known_good_account_is_reported_absent(self):
        self.assertEqual(self.verdict(KG, lambda w: None)["verdict"], "stale_rule")

    def test_unreliable_when_random_name_exists(self):
        r = self.verdict(KG, lambda w: w.add("https://kg.example/neg", html("anything")))
        self.assertEqual(r["verdict"], "unreliable")

    def test_blocked_and_unreachable(self):
        def robots(w): w.add("https://kg.example/robots.txt", "User-agent: *\nDisallow: /\n", ctype="text/plain")
        self.assertEqual(self.verdict(KG, robots)["verdict"], "blocked_by_robots")
        self.assertEqual(self.verdict(KG, lambda w: w.add("https://kg.example/neg", "", status=403))["verdict"], "unreachable_or_blocked")

    def test_negative_only_when_no_known_good_account(self):
        self.assertEqual(self.verdict(P, lambda w: None)["verdict"], "ok_negative_only")

    def test_positive_inconclusive(self):
        r = self.verdict(KG, lambda w: w.add("https://kg.example/official", "", status=429))
        self.assertEqual(r["verdict"], "positive_inconclusive")

    def test_run_selftest_summary_recommendations_and_offline(self):
        with tempfile.TemporaryDirectory() as d, FakeWeb() as web:
            path = os.path.join(d, "p.json")
            write(path, json.dumps({"platforms": [
                {"name": "Good", "category": "x", "url": "https://good.example/{}", "known_good": "official"},
                {"name": "Stale", "category": "x", "url": "https://stale.example/{}", "known_good": "official"},
                {"name": "Soft", "category": "x", "url": "https://soft.example/{}"},
                {"name": "Broken", "category": "dating", "url": "https://b.example/{}"}]}))
            web.add("https://good.example/official", html("official"))
            web.route("https://soft.example/", html("anything"), ctype="text/html")
            res = run_selftest(platforms_path=path)
        self.assertEqual(res["summary"], {"healthy": 1, "stale_rule": 1, "unreliable": 1})
        self.assertEqual(len(res["recommendations"]), 2)
        self.assertTrue(any("dating" in w for w in res["warnings"]))
        ns.set_offline(True)
        try:
            self.assertEqual(run_selftest()["status"], "offline")
        finally:
            ns.set_offline(False)


class ModuleAndCLI(unittest.TestCase):
    def write_list(self, d, rows):
        path = os.path.join(d, "mine.json"); write(path, json.dumps({"platforms": rows})); return path

    def test_custom_platform_list_end_to_end(self):
        with tempfile.TemporaryDirectory() as d, FakeWeb() as web, fixed_controls("c1", "c2"):
            path = self.write_list(d, [{"name": "Mine", "category": "x", "url": "https://mine.example/{}"},
                                       {"name": "Bad", "category": "adult", "url": "https://bad.example/{}"}])
            web.add("https://mine.example/jdoe", html("jdoe"))
            r = investigate_username("jdoe", platforms_path=path)
        self.assertEqual([a["platform"] for a in r["accounts"]["found"]], ["Mine"])
        self.assertIn("custom list", r["accounts"]["platform_list"])
        self.assertTrue(any("adult" in l for l in r["limitations"]))                  # skipped entry reported
        self.assertFalse([u for _, u in web.requests if "bad.example" in u])

    def test_empty_or_missing_custom_list_is_an_error_not_a_silent_fallback(self):
        with tempfile.TemporaryDirectory() as d, FakeWeb() as web:
            r = investigate_username("jdoe", platforms_path=os.path.join(d, "missing.json"))
            self.assertIn("No usable platforms", r["error"])
            r = investigate_username("jdoe", platforms_path=self.write_list(d, []))
            self.assertIn("No usable platforms", r["error"])
            self.assertEqual(web.requests, [])

    def test_confidence_summary_reflects_best_evidence(self):
        with FakeWeb() as web, fixed_controls("c1", "c2"):
            web.add("https://alpha.example/jdoe", html("jdoe"))
            r = investigate_username("jdoe", platforms=[P])
        self.assertEqual(r["confidence_summary"]["account_existence"]["level"], "HIGH")
        self.assertEqual(r["confidence_summary"]["identity_linkage"]["level"], "UNVERIFIED")

    def test_cli_selftest_and_platforms_option(self):
        import main as m
        def run(argv):
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                try: code = m.main(argv)
                except SystemExit as e: code = e.code
            return code, out.getvalue()
        self.addCleanup(lambda: ns.set_offline(False))
        code, out = run(["selftest", "--offline"]); self.assertEqual(code, 0)
        self.assertIn("Platform rule health check", out); self.assertIn("Offline mode", out)
        with tempfile.TemporaryDirectory() as d, FakeWeb() as web, fixed_controls("c1", "c2"):
            path = self.write_list(d, [{"name": "Mine", "category": "x", "url": "https://mine.example/{}"}])
            web.add("https://mine.example/jdoe", html("jdoe"))
            code, out = run(["username", "jdoe", "--platforms", path, "--no-save", "--no-report"])
        self.assertEqual(code, 0); self.assertIn("https://mine.example/jdoe", out)
        self.assertNotIn("Instagram_", out)


if __name__ == "__main__":
    unittest.main()
