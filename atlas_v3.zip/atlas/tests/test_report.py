import json, os, stat, tempfile, time, unittest
from tests.helpers import FakeWeb, ns, read, write
from atlas import report as R
from atlas.utils import html_safe as hg, retention

EVIL = '<script>alert(1)</script>"><img src=x onerror=alert(2)>'
REPORT = {
    "target": "example.org", "target_type": "DOMAIN", "started_at": "t0", "completed_at": "t1", "offline": False,
    "classification": {"original_input": EVIL, "normalised": "example.org", "type": "DOMAIN", "confidence": 0.9, "notes": EVIL},
    "key_findings": [{"finding": EVIL, "source": "https://example.org/", "confidence": "HIGH"},
                     {"finding": "see [x]", "source": "https://example.org/]", "confidence": "LOW"}],
    "sections": {"dns": {"records": {"A": ["1.1.1.1"]}}, "geo": {"latitude": 1.0, "longitude": 2.0, "postal": "AB1", "country": "GB"}},
    "sources_used": ["https://rdap.org/domain/example.org", "DNS (test)", "javascript:alert(3)"],
    "confidence_summary": {"dns": {"level": "HIGH", "score": 0.9, "note": "n"}},
    "limitations": [EVIL], "legal_notes": ["UK GDPR ..."],
    "search_hints": [{"description": "manual", "url": "https://example.net/search?q=a"}],
}


class Rendering(unittest.TestCase):
    def test_ten_numbered_sections_in_text(self):
        self.assertEqual(len(R.SECTION_TITLES), 10)
        txt = R.render_text_report(REPORT)
        for n, title in enumerate(R.SECTION_TITLES, 1):
            self.assertIn(f"{n}. {title.upper()}", txt)

    def test_removed_sections_are_gone(self):
        txt = R.render_text_report(REPORT).lower()
        for gone in ("publicly available images", "approximate location information", "gallery"):
            self.assertNotIn(gone, txt)

    def test_coordinates_and_postcodes_scrubbed_at_render_time(self):
        txt = R.render_text_report(REPORT)
        for k in ("latitude", "longitude", "postal"):
            self.assertNotIn(k, txt)
        self.assertIn("country", txt)

    def test_html_is_safe(self):
        out = R.render_html_report(REPORT)
        low = out.lower()
        self.assertNotIn("<script", low); self.assertNotIn("<img", low)
        self.assertIn("&lt;script&gt;", out)
        self.assertIn("content-security-policy", low); self.assertIn("default-src 'none'", out)
        self.assertIn('name="referrer" content="no-referrer"', out)
        self.assertNotIn('href="javascript:', low)
        self.assertIn('rel="noopener noreferrer nofollow"', out)
        self.assertNotIn('example.org/]', out)                  # trailing bracket not swallowed into links
        for n, t in enumerate(R.SECTION_TITLES, 1):
            self.assertIn(f"{n}. {t}", out)

    def test_manual_search_hints_listed(self):
        self.assertIn("https://example.net/search?q=a", R.render_text_report(REPORT))

    def test_empty_minimal_report_renders(self):
        R.render_text_report({"target": "x"}); R.render_html_report({"target": "x"})

    def test_safe_link_helper(self):
        self.assertNotIn("<a ", hg.safe_link("javascript:alert(1)"))
        self.assertIn("<a ", hg.safe_link("https://a.example/x"))
        self.assertNotIn("<b>", hg.safe_link("https://a.example/x?q=<b>"))


class Export(unittest.TestCase):
    def test_exports_and_privacy(self):
        with tempfile.TemporaryDirectory() as d:
            paths = R.export_reports(REPORT, os.path.join(d, "out"), html=True)
            self.assertEqual(set(paths), {"json", "txt", "html"})
            self.assertEqual(len({os.path.splitext(os.path.basename(p))[0] for p in paths.values()}), 1)
            data = json.loads(read(paths["json"]))
            for k in ("latitude", "longitude", "postal"):
                self.assertNotIn(f'"{k}"', json.dumps(data))
            self.assertEqual(data["sections"]["geo"]["country"], "GB")
            if os.name == "posix":
                for p in paths.values():
                    self.assertEqual(stat.S_IMODE(os.stat(p).st_mode), 0o600)
                self.assertEqual(stat.S_IMODE(os.stat(os.path.join(d, "out")).st_mode) & 0o077, 0)

    def test_original_does_not_get_mutated(self):
        R.prepare_for_export(REPORT)
        self.assertIn("latitude", json.dumps(REPORT))

    def test_raw_payload_stripped_unless_requested(self):
        rep = {"target": "x", "sections": {"rdap": {"raw_summary": {"a": 1}, "data": {"big": "payload"}}}}
        self.assertNotIn("big", json.dumps(R.prepare_for_export(rep)))
        self.assertIn("big", json.dumps(R.prepare_for_export(rep, include_raw=True)))

    def test_hostile_target_in_filename(self):
        with tempfile.TemporaryDirectory() as d:
            rep = dict(REPORT, target="../../etc/passwd\x00 <x>")
            for p in R.export_reports(rep, d).values():
                self.assertEqual(os.path.dirname(os.path.abspath(p)), os.path.abspath(d))


class Retention(unittest.TestCase):
    def make(self, d, name, age_days=0):
        for ext in (".json", ".txt"):
            p = os.path.join(d, name + ext); write(p, "x")
            t = time.time() - age_days * 86400; os.utime(p, (t, t))

    def test_list_delete_purge(self):
        with tempfile.TemporaryDirectory() as d:
            self.make(d, "atlas_a_20260101T000000Z", 40); self.make(d, "atlas_b_20260102T000000Z", 1)
            write(os.path.join(d, "notes.txt"), "mine")
            self.assertEqual(len(retention.list_reports(d)), 2)
            self.assertEqual(retention.purge_older_than(d, 30), 2)
            self.assertEqual([r["name"] for r in retention.list_reports(d)], ["atlas_b_20260102T000000Z"])
            self.assertEqual(retention.delete_report(d, "atlas_b_20260102T000000Z.json"), 2)
            self.assertTrue(os.path.exists(os.path.join(d, "notes.txt")))

    def test_path_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            sub = os.path.join(d, "reports"); os.mkdir(sub)
            victim = os.path.join(d, "atlas_x_20260101T000000Z.json"); write(victim, "keep")
            for bad in ("../atlas_x_20260101T000000Z", "..", "/etc/passwd", "atlas_x", "*", "atlas_../../x_20260101T000000Z"):
                with self.assertRaises(ValueError, msg=bad):
                    retention.delete_report(sub, bad)
            self.assertTrue(os.path.exists(victim))

    def test_symlink_escape_not_followed(self):
        if os.name != "posix":
            self.skipTest("posix only")
        with tempfile.TemporaryDirectory() as d:
            sub = os.path.join(d, "r"); os.mkdir(sub)
            secret = os.path.join(d, "secret.json"); write(secret, "keep")
            os.symlink(secret, os.path.join(sub, "atlas_s_20260101T000000Z.json"))
            self.assertEqual(retention.delete_report(sub, "atlas_s_20260101T000000Z"), 0)
            self.assertTrue(os.path.exists(secret))

    def test_delete_all_and_missing_dir(self):
        with tempfile.TemporaryDirectory() as d:
            self.make(d, "atlas_a_20260101T000000Z"); self.assertEqual(retention.delete_all(d), 2)
        self.assertEqual(retention.list_reports("/nonexistent/dir"), [])


if __name__ == "__main__":
    unittest.main()
