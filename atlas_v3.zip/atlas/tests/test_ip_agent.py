import contextlib, io, json, os, socket, tempfile, unittest
from unittest import mock
from tests.helpers import FakeWeb, OG_PAGE, PUBLIC_IP, ns, patch_agent_network, read
from atlas.agent import AtlasAgent
from atlas.modules.ip_module import investigate_ip

IPINFO = json.dumps({"ip": "93.184.216.34", "country": "US", "region": "Massachusetts", "city": "Norwood",
                     "loc": "42.19,-71.2", "postal": "02062", "org": "AS15133 Edgecast Hosting Inc", "hostname": "x.cloud.example"})
RDAP = json.dumps({"handle": "NET-93", "name": "EDGECAST-NETBLK", "country": "US", "startAddress": "93.184.216.0",
                   "endAddress": "93.184.223.255", "ipVersion": "v4", "entities": [{"roles": ["abuse"], "vcardArray": [
                       "vcard", [["fn", {}, "text", "Abuse Team"], ["email", {}, "text", "abuse@example.net"],
                                 ["tel", {}, "text", "+1 555 0100"]]]}]})


def ip_web(web, ip="93.184.216.34"):
    web.add(f"https://rdap.org/ip/{ip}", RDAP, ctype="application/rdap+json")
    web.add(f"https://ipinfo.io/{ip}/json", IPINFO, ctype="application/json")


class IPModule(unittest.TestCase):
    def test_special_addresses_make_zero_network_calls(self):
        cases = {"10.0.0.1": "private", "127.0.0.1": "loopback", "169.254.9.9": "link-local", "224.0.0.5": "multicast",
                 "240.1.1.1": "reserved", "0.0.0.0": "unspecified", "::1": "loopback", "fe80::1": "link-local",
                 "ff02::1": "multicast", "100.64.0.1": "shared-address-space", "::ffff:10.0.0.1": "private"}
        with mock.patch.object(ns, "_single_request", side_effect=AssertionError("network used")), \
             mock.patch("socket.getaddrinfo", side_effect=AssertionError("dns used")):
            for ip, cat in cases.items():
                r = investigate_ip(ip)
                self.assertEqual(r["sections"]["basic"]["category"], cat, ip)
                self.assertFalse({"rdap", "geolocation", "reputation"} & set(r["sections"]), ip)
                self.assertTrue(any("skipped" in l for l in r["limitations"]), ip)

    def test_invalid_ip(self):
        self.assertIn("error", investigate_ip("999.1.1.1")["sections"]["basic"])

    def test_public_ipv4_full_findings_and_uncertainty(self):
        with FakeWeb() as web, mock.patch("atlas.sources.reputation.socket.gethostbyname", side_effect=socket.gaierror):
            ip_web(web)
            r = investigate_ip("93.184.216.34")
        self.assertTrue(r["sections"]["rdap"]["success"])
        self.assertTrue(r["sections"]["hosting_indicators"]["likely_hosting_or_datacentre"])
        self.assertIn("not proof", r["sections"]["uncertainty"]["warning"])
        kf = " ".join(f["finding"] for f in r["key_findings"])
        self.assertIn("EDGECAST-NETBLK", kf); self.assertIn("AS15133", kf)
        self.assertTrue(all(f["source"] for f in r["key_findings"]))
        blob = json.dumps(r)
        for banned in ("42.19", "-71.2", "02062", "abuse@example.net", "+1 555 0100"):
            self.assertNotIn(banned, blob)

    def test_ipv6_and_mapped_addresses(self):
        with FakeWeb() as web, mock.patch("atlas.sources.reputation.socket.gethostbyname", side_effect=socket.gaierror):
            ip_web(web, "2606:4700::1111")
            r = investigate_ip("2606:4700::1111")
            self.assertEqual(r["sections"]["basic"]["ip_version"], "IPv6")
            self.assertTrue(r["sections"]["rdap"]["success"])
            ip_web(web, "8.8.8.8")
            self.assertEqual(investigate_ip("::ffff:8.8.8.8")["target"], "8.8.8.8")

    def test_blocklist_refusal_is_not_a_listing(self):
        with FakeWeb() as web, mock.patch("atlas.sources.reputation.socket.gethostbyname", return_value="127.255.255.254"):
            ip_web(web)
            r = investigate_ip("93.184.216.34")
        self.assertTrue(all(f["listed"] is not True for f in r["sections"]["reputation"]["findings"]))
        self.assertIn("no usable answer", r["confidence_summary"]["reputation"]["note"])

    def test_sources_unavailable_degrade_gracefully(self):
        with FakeWeb() as web, mock.patch("atlas.sources.reputation.socket.gethostbyname", side_effect=socket.gaierror):
            r = investigate_ip("93.184.216.34")                      # everything 404
        self.assertFalse(r["sections"]["rdap"]["success"]); self.assertTrue(r["limitations"])

    def test_offline_public_ip(self):
        ns.set_offline(True)
        try:
            r = investigate_ip("8.8.8.8")
        finally:
            ns.set_offline(False)
        self.assertTrue(any("Offline" in l or "offline" in l for l in r["limitations"]))
        self.assertFalse(r["sections"]["rdap"]["success"])


class AgentFlows(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.agent = AtlasAgent(output_dir=self.tmp.name)

    def test_full_ip_report_exports_and_has_no_removed_sections(self):
        with FakeWeb() as web, patch_agent_network():
            ip_web(web)
            r = self.agent.investigate("93.184.216.34", html=True)
        self.assertEqual(set(r["export"]), {"json", "txt", "html"})
        self.assertTrue(all(os.path.exists(p) for p in r["export"].values()))
        for gone in ("images", "location"):
            self.assertNotIn(gone, r)
        self.assertIn("legal_assessment", r); self.assertTrue(r["source_reliability"])

    def test_domain_report(self):
        with FakeWeb() as web, patch_agent_network():
            web.add("https://example.org/", OG_PAGE)
            r = self.agent.investigate("example.org")
        self.assertEqual(r["target_type"], "DOMAIN")
        self.assertIn("web_history", r["sections"])
        self.assertTrue(any("responded" in f["finding"] for f in r["key_findings"]))

    def test_person_report_is_conservative_without_sources(self):
        with FakeWeb() as web, mock.patch("atlas.modules.person_module.wikimedia.lookup_person",
                                          return_value={"found": False, "errors": []}):
            r = self.agent.investigate("Jane Roe")
        self.assertEqual(r["target_type"], "PERSON")
        self.assertEqual(r["professional"]["identity"]["status"], "no_information_located")
        self.assertIn("person_focused_research", r["legal_assessment"]["activity_classification"])
        self.assertNotIn("images", r)

    def test_unsafe_sources_are_rejected_and_reported(self):
        with FakeWeb() as web, mock.patch("atlas.modules.person_module.wikimedia.lookup_person", return_value={"found": False}):
            r = self.agent.investigate("Jane Roe", sources=["file:///etc/passwd", "http://127.0.0.1/x", "https://u:p@a.example/"])
        self.assertEqual(sum("Ignored unsafe" in l for l in r["limitations"]), 3)
        self.assertEqual([x for x in web.requests if "passwd" in x[1] or "127.0.0.1" in x[1]], [])

    def test_unknown_input(self):
        r = self.agent.investigate("")
        self.assertEqual(r["target_type"], "UNKNOWN"); self.assertIn("error", r)
        self.assertEqual(os.listdir(self.tmp.name), [])

    def test_org_flow(self):
        with FakeWeb() as web, patch_agent_network():
            web.add("https://examplecorp.com/", "<html><title>Example Corp – Home</title></html>")
            r = self.agent.investigate("Example Corp")
        self.assertEqual(r["target_type"], "ORGANISATION"); self.assertTrue(r["key_findings"])

    def test_every_type_works_fully_offline_without_network_attempts(self):
        agent = AtlasAgent(output_dir=self.tmp.name, offline=True)
        with mock.patch.object(ns, "_single_request", side_effect=AssertionError("network used")), \
             mock.patch("socket.getaddrinfo", side_effect=AssertionError("dns used")), \
             mock.patch("socket.gethostbyname", side_effect=AssertionError("dns used")), \
             mock.patch("socket.socket", side_effect=AssertionError("socket used")):
            for target in ("8.8.8.8", "example.org", "https://example.org/x", "Example Corp", "Jane Roe", "10.0.0.1", "@jdoe_42"):
                r = agent.investigate(target)
                self.assertTrue(r["offline"], target); self.assertIn("completed_at", r)
        self.addCleanup(lambda: ns.set_offline(False))

    def test_save_disabled_writes_nothing(self):
        AtlasAgent(output_dir=self.tmp.name, save=False).investigate("10.0.0.1")
        self.assertEqual(os.listdir(self.tmp.name), [])


if __name__ == "__main__":
    unittest.main()
