"""Shared test fixtures: a fake web served through ATLAS's real safe_request pipeline."""
import os, sys, socket
from contextlib import ExitStack
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from atlas.utils import network_safety as ns

PUBLIC_IP = "93.184.216.34"


class FakeWeb:
    """
    Maps URL -> (status, headers, body). Anything unmapped is 404; robots.txt defaults to 404 (allow).
    Use as a context manager. `requests` records every URL fetched.
    """
    def __init__(self, pages=None, resolver=None, default=None):
        self.pages = dict(pages or {})
        self.default = default or (404, {"content-type": "text/plain"}, b"")
        self.requests = []
        self.sequences = {}      # url -> list of responses (or Exceptions) consumed in order
        self.routes = []         # (substring, response) checked in order when the exact URL is unknown
        self.resolver = resolver or (lambda host: [PUBLIC_IP])
        self._stack = ExitStack()

    def add(self, url, body="", status=200, ctype="text/html; charset=utf-8", headers=None):
        h = {"content-type": ctype}
        h.update(headers or {})
        self.pages[url] = (status, h, body.encode() if isinstance(body, str) else body)

    def sequence(self, url, items):
        self.sequences[url] = list(items)

    def route(self, substring, body="", status=200, ctype="application/json"):
        self.routes.append((substring, (status, {"content-type": ctype}, body.encode() if isinstance(body, str) else body)))

    def _single(self, url, method, headers, timeout, ips, max_bytes, read_body):
        self.requests.append((method, url))
        seq = self.sequences.get(url)
        if seq:
            item = seq.pop(0) if len(seq) > 1 else seq[0]
            if isinstance(item, Exception):
                raise item
            status, hdrs, body = item
            return ns.SimpleResponse(status, {k.lower(): v for k, v in hdrs.items()}, url, body if read_body else b"")
        if url in self.pages:
            status, hdrs, body = self.pages[url]
        else:
            status, hdrs, body = next((r for sub, r in self.routes if sub in url), self.default)
        r = ns.SimpleResponse(status, dict(hdrs), url, body if read_body else b"")
        return r

    def __enter__(self):
        ns.clear_robots_cache()
        from atlas.sources import web_pages
        web_pages.clear_cache()
        self._stack.enter_context(mock.patch.object(ns, "_single_request", side_effect=self._single))
        self._stack.enter_context(mock.patch.object(ns, "resolve_hostname", side_effect=self.resolver))
        self._stack.enter_context(mock.patch.object(ns, "rate_limit"))
        self.sleeps = []
        self._stack.enter_context(mock.patch.object(ns, "_sleep", side_effect=self.sleeps.append))
        ns.set_offline(False)
        return self

    def __exit__(self, *a):
        self._stack.close()
        ns.set_offline(False)
        ns.clear_robots_cache()


def patch_agent_network():
    """Patch module-level references so full investigations never touch the real network."""
    stack = ExitStack()
    gai = socket.gaierror("blocked in tests")
    stack.enter_context(mock.patch("atlas.sources.reputation.socket.gethostbyname", side_effect=gai))
    stack.enter_context(mock.patch("atlas.modules.domain_module.resolve_hostname", return_value=[PUBLIC_IP]))
    stack.enter_context(mock.patch("atlas.modules.domain_module.get_dns_records",
                                   return_value={"success": True, "method": "test", "records": {"A": [PUBLIC_IP]}}))
    return stack


OG_PAGE = """<html><head><title>Example Org</title>
<meta property="og:title" content="Example Org – Home"><meta property="og:image" content="/img/hero.jpg">
<meta property="og:image:alt" content="Our building"><meta name="twitter:image" content="https://cdn.example.com/t.png">
<link rel="license" href="https://creativecommons.org/licenses/by/4.0/">
<meta name="copyright" content="(c) Example Org">
<script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"Example Org",
"logo":"/logo.png","address":{"@type":"PostalAddress","streetAddress":"1 Secret Street","postalCode":"AB1 2CD",
"addressLocality":"Cambridge","addressCountry":"GB"}}</script></head><body><h1>Example Org</h1></body></html>"""


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def write(path, text="x"):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
