# ATLAS – Passive OSINT Intelligence Agent  (v3.0)

**ATLAS** is a modular, **standard-library-only** Python agent for ethical, passive open-source research. Give it an IP address, a domain or URL,
an organisation, a publicly known person or a username and it produces a sourced, confidence-rated report.

Version 3 is deliberately **leaner and wider**: the VPN manager, image gallery and location module from 2.x were removed (a full 2.1 snapshot
is kept separately), and the effort went into **more public sources**, a **much larger username search**, and **accuracy checks** that tell you
how far to trust each result.

```
    ___   ________  ___    ___   _____
   /   | /_  __/ / / / |  / / | / ___/
  / /| |  / / / / / /| | / /| | \__ \
 / ___ | / / / /_/ / | |/ / | |___/ /
/_/  |_|/_/  \____/  |___/  |_/____/
```

## What it can look up

| Target | Sources (all public, keyless) | Notes |
|--------|-------------------------------|-------|
| **IP address** | RDAP registries, **two** geolocation providers (cross-checked), DNS blocklists | IPv4/IPv6; private/reserved addresses get an explanatory report and **no** network traffic |
| **Domain / URL** | RDAP, DNS (own stdlib client), Certificate Transparency, **Internet Archive history**, **related domains**, **provider inference**, the site itself | robots.txt honoured |
| **Organisation** | **Wikidata** (official website, disambiguation), name-verified website candidates, CT-log domains certified to the name | a site is only "likely official" if its own title/name matches |
| **Public figure** | Wikipedia + **Wikidata** (candidate list, occupation, employer, official site), pages you supply with `--source` | refuses to merge ambiguous identities; confidence never HIGH automatically |
| **Username** | **79 mainstream platforms** (editable JSON list), control-checked | existence only; never identity |

> **Reality check.** No tool can "find everything on the internet": much of the web is behind logins, blocks automated access, or is only reachable
> through search engines that need keys/paid APIs. ATLAS reaches as far as public, permitted, keyless sources go and tells you what it could **not** check.

## Installation

Python **3.9+**. Nothing to install – ATLAS uses only the standard library.

```bash
cd atlas
python3 main.py --help        # Windows: py main.py --help
```

## Usage

```
python main.py                              # interactive shell
atlas> investigate 8.8.8.8
atlas> investigate example.com
atlas> investigate "Example Corp"
atlas> investigate "Jane Roe" --source https://example.org/official-bio
atlas> username jdoe_42                     # also: @jdoe_42, or a bare handle like jdoe_42
atlas> selftest                             # health-check the username platform rules
atlas> report | export html | reports list | reports delete <name|all> | reports purge <days>
atlas> offline on | offline off | help | exit
```

One-shot form (the original CLI still works):

```bash
python main.py investigate 8.8.8.8
python main.py -t example.com --no-report
python main.py investigate Tim Cook --type person          # quotes optional; options may come first or last
python main.py username jdoe_42 --stop-at-first
python main.py username jdoe_42 --platforms my_platforms.json
python main.py selftest
python main.py reports list
python main.py investigate Jane Roe --offline --no-save    # no network, nothing written
```

| Option | Meaning |
|--------|---------|
| `--type TYPE` | force `ip`, `domain`, `url`, `org`, `person`, `username` |
| `--source URL` | an official/public page you supply (repeatable, max 5): confirms an organisation's site or supplies a person's biography page |
| `--platforms FILE` | username scans: use your own platform list (JSON) instead of the built-in one |
| `--stop-at-first` | username scans: stop at the first confirmed match |
| `--html` | also write an HTML report (no scripts, escaped, strict CSP) |
| `--raw` | keep raw source payloads in exports (phone/email/address fields are always redacted) |
| `--no-report`, `--no-save` | don't print the full report / don't write any files |
| `--offline` | disable all network access |
| `--list-reports`, `--delete-reports`, `--purge-older-than DAYS` | retention controls |
| `-o DIR`, `-v` | output directory, debug logging |

## Username search

`username <name>` asks each platform whether a **public profile exists for that exact username**: one request per platform, robots.txt honoured,
no profile content stored, no logins, no spelling variants.

**Accuracy safeguards** (these matter more as the list grows):

1. **Per-platform format check** – a name that is invalid on a platform is never sent there.
2. **Soft-404 detection** – a 200 page whose title/heading says "not found" counts as *absent*.
3. **Two control checks** – when a name looks "found", two random names that cannot exist are tried on the same platform. If either also looks found the platform is reported **unreliable**, not as a match.
4. **Graded confidence** – HIGH (controls passed *and* the username appears in the page title/URL), MEDIUM (controls passed), LOW (controls inconclusive).
5. **Bounded retries** – transient 429/5xx/connection errors are retried once; a long `Retry-After` is respected, never evaded.
6. **Honest outcomes** – found · not found · unreliable · inconclusive · skipped (robots.txt / invalid format) · error; each listed by name.
7. **`selftest`** – health-checks every rule with a random-name negative control and, for 24 platforms, a known-good official account, and flags *stale* or *unreliable* rules so you can fix or remove them.

**Edit the list.** Platforms live in `atlas/data/platforms.json` (79 shipped). Each entry: `name`, `category`, `url` (with one `{}`), `kind` (`status` | `message` | `json`),
optional `profile_url`, `pattern`, `absent_text`, `exists_path`/`absent_path`/`absent_if_empty` (json), `absent_codes`, `known_good`. Use `--platforms FILE` to swap in your own.
ATLAS validates every entry (https only, one placeholder, no IP hosts) and **refuses dating, adult, messaging, health and finance categories** – those entries are skipped and reported.

**Same username ≠ same person.** Usernames are widely reused. Every match is marked identity *UNVERIFIED*; use results as leads, never as identification.
Platforms that block automated access (Instagram, X, TikTok, Facebook, LinkedIn, Reddit, YouTube, Threads, Pinterest) are **not queried**; ATLAS prints their profile URLs for you to open manually.

## Other accuracy checks

- **Geolocation cross-check** – ipinfo.io and ipwho.is (both HTTPS) are compared; agreement on country raises confidence, **disagreement is flagged as unreliable**. The cleartext ip-api.com is used only if both fail.
- **Registry vs geolocation** – the RDAP registry country is compared with the geolocation country and differences are explained (often normal for hosting/CDN networks).
- **Name verification** – a candidate organisation website must identify itself with the organisation's name (whole title segment for one-word names); look-alike or parked domains are labelled unrelated.
- **Wikidata disambiguation** – several people/organisations with the same name produce a candidate list, not a guess.
- **Network retries** – one bounded retry for transient failures across all sources.
- **Confidence everywhere** – every report has per-source reliability ratings, a confidence table and a limitations list.

## Reports

TXT, JSON and optional HTML with 10 sections: Investigation overview · Target classification · Main findings · Network information ·
Professional information · Sources consulted · Source reliability · Confidence assessments · Limitations · Privacy and legal considerations.
Every finding names its source; missing data is reported as missing, never invented. Files are written owner-only; coordinates/postcodes are scrubbed.

## Offline vs online

- **Need internet:** every lookup (RDAP, geolocation, CT logs, DNS records, blocklists, Wikipedia/Wikidata, Internet Archive, websites, username platforms, `--source` pages).
- **Work offline (`--offline`):** classification, private/reserved IP reports, report rendering/export and retention commands. Offline mode opens no sockets and makes no DNS queries.

## Project structure

```
atlas/
├── main.py                      # CLI + interactive shell
├── README.md  SECURITY_AND_LEGAL.md  CHANGELOG.md  requirements.txt (none needed)
├── atlas/
│   ├── agent.py  classifier.py  report.py  ui.py
│   ├── data/platforms.json      # editable username platform list
│   ├── modules/   ip  domain  org  person  username
│   ├── sources/   rdap  dns_lookup  geoip  cert_transparency  reputation  web_presence  web_pages
│   │              wikipedia (wikimedia)  wikidata  wayback  provider_hints  username_sources  page_metadata
│   └── utils/     network_safety  helpers  html_safe  source_reliability  retention
├── tests/                       # unittest, fully offline (183 tests)
├── examples/                    # sample reports
└── reports/                     # your exports (owner-only permissions)
```

## Tests

```bash
python -m unittest discover -s tests -v
```

Fully offline: a fake web layer feeds ATLAS's real request pipeline (with response sequences for retry tests), and a loopback server exercises the real pinned-connection and size-cap code.
Live behaviour of third-party sites cannot be tested offline – run `python main.py selftest` to check the username rules against the real sites.

## Adding sources

1. New module in `atlas/sources/` returning a dict with `queried_at`, `success`, `source`, `errors`.
2. Make every request through `atlas.utils.network_safety.safe_request` (never `urllib` directly); use `respect_robots=True` for HTML pages and `retries=1` for APIs.
3. Call it from the relevant `modules/*.py`, add `key_findings` with sources, and add offline tests with `tests/helpers.FakeWeb`.

Keep sources **passive**: nothing that attempts unauthorised access, credential testing, private-data collection or residential-location discovery.

## Legal & privacy

For legitimate research, defensive security, education and journalism using public sources. Public information is not automatically lawful to collect or use:
legality depends on purpose, the information, how it is processed and the circumstances. Information about identifiable people – including usernames – can be
personal data under UK GDPR / DPA 2018 even when public. Not legal advice. Read **`SECURITY_AND_LEGAL.md`**.
