# ATLAS – Security Restrictions, Privacy & Legal Limitations

ATLAS is a **passive OSINT research tool**. The restrictions below are implemented in code and covered by automated tests, not only stated here.

## 1. What ATLAS will not do

| Prohibited activity | Reason |
|---------------------|--------|
| Unauthorised access to systems; exploitation; attacks | Computer Misuse Act 1990 (UK) and equivalent laws |
| Password guessing, credential stuffing/theft | Same + ethical boundary |
| Bypassing authentication, paywalls, access controls or **robots.txt** | Legal, terms of service, good practice |
| Access to private accounts or non-public databases | Legal and ethical |
| Denial-of-service or resource exhaustion | Illegal and unethical |
| Live tracking of individuals | Privacy / data protection |
| Discovery of private residential locations or home addresses | UK GDPR / DPA 2018, safety |
| Collection of private personal data (personal phones, private accounts, credentials, family details) | UK GDPR / DPA 2018 |
| Linking usernames/accounts to a real-world person; trying username variants; storing profile content | Privacy; shared usernames are common, so attribution is unreliable and harmful when wrong |
| Facial recognition or identifying people from images | Privacy, accuracy, ethics |
| Reading Wikidata/Wikipedia personal properties (birth data, family, residence) | Privacy – only professional facts are requested |

ATLAS also cannot "find everything on the internet": it only uses public, permitted, keyless sources and reports what it could not check.

## 2. Technical safeguards (what the code does)

All outbound traffic passes through `atlas/utils/network_safety.py::safe_request`:

- **SSRF protection:** only `http`/`https`; no embedded credentials; ports limited to 80/443/8080/8443; every address a host resolves to must be globally routable (private, loopback, link-local, multicast, reserved, CGNAT and documentation ranges are refused).
- **DNS-rebinding protection:** the connection is made to the *already validated IP*.
- **Unsafe redirects:** max 5 hops, each re-validated; redirects to `file://` or internal hosts are refused.
- **robots.txt:** honoured for web pages and username platforms. If it cannot be verified (5xx, unreachable, offline) ATLAS treats it as *no automated access*.
- **Rate limiting & limits:** per-host delay, timeouts, 30 s total deadline, 1 MB body cap (200 KB robots.txt, 100 KB for username checks).
- **Bounded retries:** at most the requested number of repeats for connection errors and HTTP 429/502/503/504; a `Retry-After` above 5 s is **respected by not retrying** – ATLAS never works around rate limits.
- **Unsafe HTML rendering:** HTML reports contain **no JavaScript**, use `default-src 'none'`, escape every dynamic value, emit only http(s) links with `rel="noopener noreferrer nofollow"`.
- **Terminal safety:** every printed string has control characters (incl. ESC) stripped before colour is applied, so page content cannot inject terminal escape sequences.
- **Malformed responses:** DNS packets are validated (ID, question, bounds, compression loops); HTML/JSON parse failures never abort a report; platform lists are validated entry by entry.
- **Path traversal:** report names are matched against a strict pattern, resolved inside the reports directory, symlinks are not followed outside it, and only ATLAS-named files are deleted.
- **Sensitive data in reports:** vCard phone/email/address from RDAP are always redacted; latitude/longitude/postcode keys are scrubbed at export and render time; raw payloads omitted unless `--raw`; URL credentials are redacted.
- **Credentials:** ATLAS never asks for, accepts, stores or logs credentials; `--source` URLs containing credentials are rejected.
- **Logging:** WARNING by default; `-v` is opt-in. **Local storage:** owner-only permissions (`0600` files, `0700` directory on POSIX).

## 3. Network endpoints used (what needs the internet)

No API keys, paid services or third-party packages are used. Public endpoints:

| Purpose | Endpoint(s) | Notes |
|---------|-------------|-------|
| IP registration | `rdap.org`, `rdap.arin.net`, `rdap.db.ripe.net`, `rdap.apnic.net`, `rdap.lacnic.net`, `rdap.afrinic.net` | public RDAP |
| Domain registration | `rdap.org`, `rdap.verisign.com` (.com/.net), `rdap.nic.uk` (.uk) | public RDAP |
| Coarse IP geolocation | `ipinfo.io`, `ipwho.is` (both HTTPS, cross-checked); fallback `ip-api.com` (**cleartext HTTP**) | coordinates/postcodes discarded or not requested |
| Subdomains, related domains, organisation certificates | `crt.sh` (`q=` and `O=` searches) | Certificate Transparency; shared CDN certificates excluded from "related" |
| IP reputation | `zen.spamhaus.org`, `bl.spamcop.net` via your system DNS resolver | DNS blocklists |
| DNS records | your system resolvers (`/etc/resolv.conf`) | Windows: A/AAAA via the OS resolver |
| Websites | the investigated site, its `robots.txt` | one page |
| Web history | `web.archive.org` (CDX API) | capture dates only |
| Public figures / organisations | `en.wikipedia.org` REST API, `www.wikidata.org` API | professional facts only |
| Username presence | one public profile/API URL per platform listed in `atlas/data/platforms.json`, plus each host's `robots.txt` | existence only |
| User-supplied pages | URLs you pass with `--source` (max 5) | same safety rules |

`--offline` disables **all** of the above (no sockets, no DNS). Search-engine links printed for people/organisations are for *you* to open; ATLAS never fetches them.

## 4. Username presence checks – boundaries

- **Scope:** whether a public profile page exists for the *exact* username. Page text is read transiently (first 100 KB) only to compute two booleans (soft-404 and username-in-title); **nothing from it is stored**.
- **Platform policy:** mainstream developer, community, creative and gaming platforms. Dating, adult, messaging, health and finance categories are excluded – in the shipped list **and** in any custom `--platforms` file (such entries are skipped and reported). Platforms that restrict automated access are never queried; their URLs are printed for manual use.
- **Accuracy:** per-platform format validation; soft-404 detection; two control checks; graded confidence; `selftest` to find stale rules. Ambiguous results (blocked, rate-limited, redirected) are *inconclusive*, never matches.
- **Identity:** a shared username is not evidence of a shared owner. Every match is identity UNVERIFIED; the warning appears in the terminal, every report and the limitations.
- **Purpose:** appropriate uses include checking your own handle or brand, authorised security assessments and proportionate public-interest research – not locating, monitoring or harassing an individual. Platform terms may restrict automated checks; compliance is your responsibility.

## 5. Privacy defaults

- Person research uses Wikipedia/Wikidata professional facts and pages **you** supply; ambiguous names are listed as candidates, never merged; identity confidence is capped below HIGH.
- IP geolocation is described as an approximate *network* location and cross-checked; disagreement is reported as unreliable.
- **Retention controls:** `reports list|delete <name|all>|purge <days>`, `--list-reports`, `--delete-reports`, `--purge-older-than DAYS`, and `--no-save` to write nothing. Bulk deletion asks for confirmation and refuses in non-interactive sessions.
- Reports from ATLAS 1.0 may contain approximate coordinates/postcodes; delete them if not needed.

## 6. Legal classification guidance (not formal advice)

Every report contains a structured legal assessment:

- **Generally permitted public research** – RDAP, DNS, Certificate Transparency, Internet Archive capture dates, passive observation of publicly reachable pages (robots.txt honoured), DNS-based blocklist queries.
- **Generally permitted with caveats** – approximate geolocation of a public IP (can be personal data in context).
- **Requires careful assessment / a lawful basis** – research focused on a living individual; username presence checks.
- **Potentially restricted or regulated** – bulk/automated scraping of registries or social platforms.
- **Not permitted by the system** – unauthorised access, credential testing, private-data collection, facial recognition.

**Using public information does not automatically make an investigation lawful.** Legality depends on the jurisdiction, the **purpose**, the information involved, how it is collected, stored and used, and the circumstances.

### UK instruments considered

- **UK GDPR and Data Protection Act 2018** – information relating to an identifiable living person is personal data *even if public* (a name with a role, an IP address or a username can qualify). You need a lawful basis, a specific purpose, minimisation, accuracy, storage limitation and security; special-category data has extra protection and is not sought. Consider a DPIA for systematic person-focused work.
- **Computer Misuse Act 1990** – unauthorised access to computer material is an offence. ATLAS only requests publicly reachable resources, but *you* are responsible for how you use results.
- **PECR** – relevant if findings are used for electronic marketing.

## 7. Responsible use

For defensive security research, education, legitimate OSINT and journalistic or academic research using public sources. You are responsible for compliance with applicable law and with the terms of any service you query.

## 8. Reporting issues

If you find a way ATLAS could perform non-passive or non-public research, expose a residential location, attribute accounts to a person, or write outside its reports directory, treat it as a security defect: avoid that path and fix or report it.
