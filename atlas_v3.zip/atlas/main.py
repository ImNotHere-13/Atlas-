#!/usr/bin/env python3
"""
ATLAS – Passive OSINT Intelligence Agent
Entry point, interactive terminal interface and one-shot CLI.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from atlas import ui
from atlas.agent import AtlasAgent
from atlas.classifier import parse_forced_type
from atlas.modules.username_module import run_selftest
from atlas.utils import retention
from atlas.utils.helpers import clean_target


def setup_logging(verbose: bool = False) -> None:
    logging.basicConfig(level=logging.DEBUG if verbose else logging.WARNING,
                        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s", datefmt="%H:%M:%S")


# ---------------------------------------------------------------------------
# Command handlers (shared by interactive mode and one-shot CLI)
# ---------------------------------------------------------------------------

def do_investigate(agent, target, opts, show_report=True, html=False):
    force = parse_forced_type(opts.get("type"))
    report = agent.investigate(target, progress_callback=ui.progress_printer, force_type=force,
                               sources=opts.get("sources"), html=html,
                               stop_at_first=opts.get("stop_at_first", False),
                               platforms_path=opts.get("platforms"))
    if "classification" in report:
        ui.show_classification(report["classification"])
    if "error" in report:
        ui.print_error(f"{report['error']}. {report.get('suggestion', '')}")
        return 1
    ui.show_summary(report)
    if show_report:
        ui.print_report_text(agent.render_last_report())
    return 0


def do_selftest(platforms_path=None):
    res = run_selftest(progress_callback=ui.progress_printer, platforms_path=platforms_path)
    ui.show_selftest(res)
    return 0


def do_reports(agent, args):
    sub = (args[0].lower() if args else "list")
    if sub == "list":
        ui.show_reports(retention.list_reports(agent.output_dir)); return 0
    if sub == "delete" and len(args) >= 2:
        try:
            if args[1].lower() == "all":
                if not ui.ask_confirm(f"Permanently delete ALL stored reports in '{agent.output_dir}'?"):
                    ui.print_info("Cancelled."); return 1
                n = retention.delete_all(agent.output_dir)
            else:
                n = retention.delete_report(agent.output_dir, args[1])
            ui.print_info(f"Deleted {n} file(s)."); return 0
        except ValueError as e:
            ui.print_error(str(e)); return 1
    if sub == "purge" and len(args) >= 2:
        try:
            days = float(args[1])
        except ValueError:
            ui.print_error("Usage: reports purge <days>"); return 1
        ui.print_info(f"Deleted {retention.purge_older_than(agent.output_dir, days)} file(s) older than {days:g} days.")
        return 0
    ui.print_error("Usage: reports list | reports delete <name|all> | reports purge <days>")
    return 1


# ---------------------------------------------------------------------------
# Interactive mode
# ---------------------------------------------------------------------------

def run_interactive(agent: AtlasAgent) -> None:
    ui.print_banner()
    ui.print_help()
    while True:
        try:
            line = input("atlas> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting ATLAS.")
            break
        if not line:
            continue
        toks = ui.split_command(line)
        cmd, rest = toks[0].lower(), toks[1:]
        try:
            if cmd in ("exit", "quit", "q"):
                print("Goodbye."); break
            elif cmd in ("help", "?"):
                ui.print_help()
            elif cmd == "report":
                ui.print_report_text(agent.render_last_report())
            elif cmd == "export":
                if not agent.last_report:
                    ui.print_error("No report to export.")
                else:
                    paths = agent.export_last(html=bool(rest and rest[0].lower() == "html"))
                    ui.print_info("Exported:\n  " + "\n  ".join(paths.values()))
            elif cmd == "reports":
                do_reports(agent, rest)
            elif cmd == "offline":
                on = bool(rest) and rest[0].lower() == "on"
                agent.set_offline(on)
                ui.print_info(f"Offline mode {'ON – no network access' if on else 'OFF'}.")
            elif cmd == "selftest":
                _t, o = ui.parse_target_args(rest)
                do_selftest(o.get("platforms"))
            elif cmd == "username":
                target, opts = ui.parse_target_args(rest)
                if not target:
                    ui.print_error("Usage: username <name> [--stop-at-first]")
                else:
                    opts["type"] = "username"
                    do_investigate(agent, clean_target(target), opts, show_report=False)
            else:
                body = rest if cmd == "investigate" else toks
                target, opts = ui.parse_target_args(body)
                if not target:
                    ui.print_error("Please provide a target after 'investigate'.")
                else:
                    do_investigate(agent, clean_target(target), opts, show_report=False)
        except ValueError as e:
            ui.print_error(str(e))
        except Exception as e:                      # keep the shell alive
            ui.print_error(str(e))
            logging.exception("Command failed")


# ---------------------------------------------------------------------------
# One-shot CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="ATLAS – Passive OSINT Intelligence Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                                   interactive shell
  python main.py investigate 8.8.8.8
  python main.py investigate example.com --html
  python main.py investigate Tim Cook --source https://example.org/about/tim
  python main.py username jdoe_42               which public platforms have this exact username
  python main.py @jdoe_42 --stop-at-first
  python main.py reports list
  python main.py -t 1.1.1.1 --no-report --offline
        """)
    p.add_argument("words", nargs="*", help="[investigate|username|selftest|reports] target or arguments")
    p.add_argument("-t", "--target", dest="target_opt", help="Target to investigate (alternative form)")
    p.add_argument("-o", "--output-dir", default="reports", help="Directory for exported reports (default: reports)")
    p.add_argument("--type", dest="force_type", metavar="TYPE", help="Force type: ip, domain, url, org, person")
    p.add_argument("--source", action="append", default=[], metavar="URL",
                   help="Official/public page you supply as a source (repeatable, max 5)")
    p.add_argument("--platforms", metavar="FILE", help="Username scans: use your own platform list (JSON) instead of the built-in one")
    p.add_argument("--stop-at-first", action="store_true", help="Username scans: stop at the first confirmed match")
    p.add_argument("--html", action="store_true", help="Also write an HTML report")
    p.add_argument("--raw", action="store_true", help="Keep raw source payloads in exports (contacts stay redacted)")
    p.add_argument("--no-report", action="store_true", help="Do not print the full text report")
    p.add_argument("--no-save", action="store_true", help="Do not write any report files")
    p.add_argument("--offline", action="store_true", help="No network access at all")
    p.add_argument("--list-reports", action="store_true", help="List stored reports and exit")
    p.add_argument("--delete-reports", action="store_true", help="Delete ALL stored reports (asks first) and exit")
    p.add_argument("--purge-older-than", type=float, metavar="DAYS", help="Delete stored reports older than DAYS and exit")
    p.add_argument("-v", "--verbose", action="store_true", help="Enable debug logging")
    return p


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_intermixed_args(argv)   # allows options before/between target words
    setup_logging(args.verbose)
    try:
        parse_forced_type(args.force_type)
    except ValueError as e:
        parser.error(str(e))

    agent = AtlasAgent(output_dir=args.output_dir, include_raw=args.raw, offline=args.offline, save=not args.no_save)

    if args.list_reports:
        ui.show_reports(retention.list_reports(args.output_dir)); return 0
    if args.purge_older_than is not None:
        return do_reports(agent, ["purge", str(args.purge_older_than)])
    if args.delete_reports:
        return do_reports(agent, ["delete", "all"])

    words = list(args.words)
    cmd = words[0].lower() if words else ""
    if cmd == "reports":
        return do_reports(agent, words[1:])
    if cmd == "selftest":
        return do_selftest(args.platforms)

    opts = {"type": args.force_type, "sources": args.source, "stop_at_first": args.stop_at_first,
            "platforms": args.platforms}
    if cmd == "username":
        words, opts["type"] = words[1:], "username"
    if cmd == "investigate":
        words = words[1:]
    target = clean_target(args.target_opt or " ".join(words))
    if target:
        ui.print_banner()
        try:
            return do_investigate(agent, target, opts, show_report=not args.no_report,
                                  html=args.html)
        except Exception as e:
            ui.print_error(str(e)); logging.exception("Investigation failed"); return 1
    run_interactive(agent)
    return 0


if __name__ == "__main__":
    sys.exit(main())
