# Example reports

`examples/` holds sample outputs; `reports/` (created at runtime) holds your own exports.

## Original examples (ATLAS 1.0, live data at the time)

`example_ip_8.8.8.8.txt`, `example_domain_example.com.txt`, `example_org_Microsoft.txt`

These predate ATLAS 2/3. Version 1.0 reports could contain approximate coordinates and postcodes from IP geolocation; ATLAS 3 never collects or prints them.
Reports in `reports/` produced by 1.0 were left untouched – delete them with `python main.py reports delete <name>` if you do not need them.

## Offline examples (ATLAS 3.0, generated with `--offline`, no live data)

- `example_offline_private_ip_10.0.0.1.txt` – a private address: classified, no external lookups, why.
- `example_offline_person_Jane_Roe.txt` – a person lookup with nothing verifiable: the conservative "no information located" behaviour.
- `example_offline_username_jdoe_42.txt` – a username scan in offline mode: it says nothing can be concluded, and lists manual-lookup links.
- `example_offline_domain_report.html` – the HTML report format (no scripts, escaped, strict CSP).

Regenerate them with:

```bash
python main.py -t 10.0.0.1 --offline --no-report
python main.py investigate Jane Roe --offline --no-report
python main.py username jdoe_42 --offline --no-report
python main.py example.org --offline --html --no-report
```

Live runs need an internet connection:

```bash
python main.py -t 8.8.8.8
python main.py investigate example.com
python main.py investigate "Example Corp"
python main.py username jdoe_42
python main.py selftest            # check the username platform rules against the real sites
```
